# **InsertLicense** code author="Alexander Broersen"

from mevis import *
from TestSupport import Base, Fields, Logging, ScreenShot
from TestSupport.Macros import *
import os

def GROUP001_BasicTestGroup ():
  return (TEST001_increaseScalarScript, \
          TEST002_increaseVectorScript)

def TEST001_increaseScalarScript ():
  """ -- Increase scalar value by a Matlab script -- """
  Fields.setValue("MatlabScriptWrapper.numberOfScalars", 1)
  Fields.setValue("MatlabScriptWrapper.scalar0", 0.0)
  Fields.setValue("MatlabScriptWrapper.matlabScript", "scalar0 = scalar0+1")
  Fields.touch("MatlabScriptWrapper.update")
  
  EXPECT_EQ(Fields.getValue("MatlabScriptWrapper.scalar0"), 1.0)
  return

def TEST002_increaseVectorScript ():
  """ -- Increase vector value by a Matlab script -- """
  Fields.setValue("MatlabScriptWrapper.numberOfVectors", 1)
  Fields.setValue("MatlabScriptWrapper.vector0", (0.0, 0.0, 0.0, 0.0) )
  Fields.setValue("MatlabScriptWrapper.matlabScript", "vector0 = vector0+1")
  Fields.touch("MatlabScriptWrapper.update")
  
  EXPECT_EQ(Fields.getValue("MatlabScriptWrapper.vector0"), (1.0, 1.0, 1.0, 1.0) )
  return

def TEST003_showWEMScript ():
  """ -- Generate and show WEM by a Matlab script -- """
  Fields.setValue("MatlabScriptWrapper.numberOfOutputBases", 1)
  Fields.setValue("MatlabScriptWrapper.outBaseType0", "WEM")
  Fields.setValue("MatlabScriptWrapper.matlabScript", "outBase0{1}.Vertices = [30 50 50;50 50 50;50 30 50;30 30 50;30 50 30;50 50 30;50 30 30;30 30 30]; outBase0{1}.Faces = [2 6 5;2 5 1;3 7 6;3 6 2;4 8 7;4 7 3;5 8 4;5 4 1;4 3 2;4 2 1;6 7 8;6 8 5]")
  Fields.touch("MatlabScriptWrapper.update")
  
  filename = ScreenShot.createOffscreenScreenShot("SoSeparator.self", "screentest.png")
  Logging.showImage("WEM screenshot", filename)
  Logging.showFile("Link to screenshot file", filename)

def FIELDVALUETEST003_AutomaticTest_1 ():
  return os.path.join(Base.getDataDirectory(), "data.xml")
