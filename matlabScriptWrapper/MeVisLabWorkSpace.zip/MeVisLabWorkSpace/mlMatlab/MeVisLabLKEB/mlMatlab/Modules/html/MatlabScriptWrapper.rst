.. ---- START RST HEADER ----

:ml:mod:`MatlabScriptWrapper`
=============================

.. ml:module:: MatlabScriptWrapper
   :type: MLModule
   :author: Alexander Gryanik, Ola Friman, Markus Harz, Alexander Broersen
   :dll: MLMatlabScriptWrapper
   :genre: Other
   :file: MLMatlabScriptWrapper.def
   :keywords: Matlab scripting wrapper
   :seealso: PythonArithmetic
   :status: work-in-progress

   Execute Matlab script and/or exchange different data-structures.

.. ----  END RST HEADER  ----

Purpose
=======

The **MatlabScriptWrapper** module offers the possibility to execute
`Matlab <http://www.mathworks.com/products/matlab/>`_ scripts within
`MeVisLab <http://www.mevislab.de>`_ and establish a link to a Matlab
console, for example to transfer data between MeVisLab and Matlab.
Note that Matlab must be installed for this module to function.

.. figure:: MatlabScriptWrapper_window.png
   
   The default panel of the MatlabScriptWrapper.

Usage
=====

Currently, three types of data structures can be transferred between MeVisLab and Matlab:

- **Images:**
  Up to three images can be used. Images are stored as up to six dimensional matrices in Matlab.
  Note that MeVisLab and Matlab use different coordinate systems, see below for further information.

- **CurveData (input only) and CurveLists:**
  A `CurveData <http://www.mevislab.de/docs/2.0/MeVisLab/Resources/Documentation/Publish/SDK/ToolBoxReference/MLBasePage.html>`_
  is an object consisting of zero or one X- and any number of Y-data series. A CurveList is an array
  of CurveData objects. In Matlab, a CurveList is represented as a cell array with in each cell a matrix
  with the points of each series of a curve. The first column in the matrix contains the X-values, the
  second column contains the first serie of Y-values, the third column the second serie of Y-values etc..

- **XMarkerLists:**
  An `XMarker <http://www.mevislab.de/docs/2.0/MeVisLab/Resources/Documentation/Publish/SDK/ToolBoxReference/MLBasePage.html>`_
  is an object that contains a point (up to 6-D), a vector (3-D), a type variable (integer) and a name
  (string). An XMarkerList is an array of XMarker objects. In Matlab, an XMarkerList is represented as
  a struct with the following members (where *N* is the number of XMarkers):
  
    *<variablename>*.pos, where pos is an *N* x2, *N* x3, *N* x4, *N* x5 or *N* x6 matrix with the
    position coordinates.

    *<variablename>*.vec, where vec is an *N* x2 or *N* x3 matrix of vectors.

    *<variablename>*.type, where type is an *N* x1 vector of integers.

    *<variablename>*.name, where name is an *N* x1 cell array of strings.

    .. note::
      
      **Important:** the pos matrix determines the number of XMarkers *N*. The vec, type and name arrays must
      have the same number of *N* rows, otherwise will these values not be copied to MeVisLab. See the example
      network for an example.

- **WEMs:**
  A Winged Edge Mesh (`WEM <http://www.mevislab.de/docs/2.0/MeVisLab/Resources/Documentation/Publish/SDK/ToolBoxReference/WEMPage.html>`_)
  is an object that contains a representation of a surface. In Matlab, a WEM is represented as a cell array
  of structures with nodes (markers of vertices with a color, size, and style), faces (with a diffuse color
  and alpha), edges (with a color, size, and style), a description (`Tag <http://www.mathworks.com/help/techdoc/ref/patch_props.html#Tag>`_)
  and a label (`DisplayName <http://www.mathworks.com/help/techdoc/ref/patch_props.html#DisplayName>`_).
  Optionally, if a WEM contains a Look Up Table (`LUT <http://www.mevislab.de/docs/2.0/MeVisLab/Resources/Documentation/Publish/SDK/ToolBoxReference/MLLUTPage.html>`_),
  this data will be put into the `CData <http://www.mathworks.com/help/techdoc/ref/patch_props.html#CData>`_
  field. These structures can be exchanged directly with the `Matlab Patch Properties <http://www.mathworks.com/help/techdoc/ref/patch_props.html>`_.
  See the example network for an example.

- **Mat4Lists (input only):**
  A `Mat4List <http://www.mevislab.de/docs/2.0/MeVisLab/Resources/Documentation/Publish/SDK/ToolBoxReference/mlLinearAlgebraPage.html>`_
  is an object that contains a list of 4x4 matrices. In Matlab, a Mat4List is represented as a cell array
  with in each cell a 4x4 integer matrix.

- **CSOLists (input only):**
  A Contour Segmentation Object (`CSO <http://www.mevislab.de/docs/2.0/MeVisLab/Resources/Documentation/Publish/SDK/ToolBoxReference/CSOPage.html>`_)List
  is an object that contains a list of CSOs. In Matlab, a CSOList is represented as a cell array with in
  each cell an *N* x3 integer matrix with the position coordinates of one CSO.

- **Scalars:**
  Double precision. These can be used both as input and ouput variables. Field notifications will be sent
  in MeVisLab only if a scalar has changed its value after the Matlab script execution.

- **Vectors:**
  Double precision 4-D integer point. These can be used both as input and ouput variables. Field notifications
  will be sent in MeVisLab only if a vector has changed its value after the Matlab script execution.

- **Matrices:**
  Double precision 4x4 integer matrix. These can be used both as input and ouput variables. Field notifications
  will be sent in MeVisLab only if a matrix has changed its value after the Matlab script execution.

- **Strings:**
  These can be used both as input and ouput variables. Field notifications will be sent in MeVisLab only if a
  string has changed its value after the Matlab script execution.

The variable names for the above data structures in the Matlab workspace can be set.

The Matlab script can be written directly in the module GUI, or an external script file (`.m`) can be called.
If you choose to use an existing script, the script in :ml:fld:`matlabScript` will disappear and there is no
posibility to edit a Matlab script file from MeVisLab.

Push the :ml:fld:`update` button to execute the Matlab script, set :ml:fld:`autoUpdate` to update on input
value change, or set :ml:fld:`autoApply` to update on parameter value change.

Use the :ml:fld:`showSessionWindow` checkbox to show or hide the session window.

The :ml:fld:`restartMatlab` button can be used to restart a Matlab session once it is terminated externally.

Details
=======

**Coordinate systems in MeVisLab and Matlab**

In the context of this module, the only coordinate system that is
considered is the discrete voxel index coordinate system, i.e., images
are considered as multidimensional matrices. Both MeVisLab and Matlab
have the origin in the upper left corner and a y-axis that points
"downwards". However, note that MeVisLab starts counting a 0, whereas
Matlab starts counting a 1, i.e., the upper left voxel has the
coordinate ``(0,0)`` in MeVisLab and ``(1,1)`` in Matlab. The major difference
between MeVisLab and Matlab is the indexing order: MeVisLab uses
``[x,y]`` while Matlab uses ``[y,x]`` (i.e., row-column into a matrix). Thus,
an image will appear flipped when exported from MeVisLab and visualized
in Matlab or vice-versa. To correct for this, one can use the
*permute* command in Matlab, for example::

   >> permute(Input0,[2 1])

which swaps the x and y axes. See the example network for an example.

Inputs
------

Up to three 
   .. ml:input:: input0 input1 input2
      :type: Image

and one
   .. ml:input:: inputBase0
      :type: MLBase

for a CurveData, CurveList, XMarkerList, Mat4List, CSOList, or WEM can be attached to the module.
Input to the module from MeVisLab is optional, the output can be generated entirely in Matlab
without input from MeVisLab (see the example network for examples).

Outputs
-------

Up to three
   .. ml:output:: output0 output1 output2
      :type: Image

and one
   .. ml:output:: outputBase0
      :type: MLBase

are present to connect a CurveList, one XMarkerList, or one WEM.
Outputs are only valid if the Matlab script is executed successfully.

Parameters
----------

.. ml:param:: matlabScript
   :type: String

   A field where the Matlab script can be written.

.. ml:param:: useExternalScript
   :type: Bool

   Enables the possibility to use an external Matlab script file (`.m`).

.. ml:param:: matlabScriptPath
   :type: String

   The path and the name of the external Matlab script file (`.m`).

.. ml:param:: autoUpdate
   :type: Bool

   Execute the script automatically on input change (only for input images, CurveData, CurveList,
   XMarkerList, Mat4List, CSOList, and WEM, not for changes in the names).

.. ml:param:: autoApply
   :type: Bool

   Execute the script automatically on parameter change (only for fields, not for changes in the names).

.. ml:param:: restartMatlab
   :type: Trigger

   Restarts the Matlab engine.

.. ml:param:: status
   :type: String

   This field gives information whether the Matlab script was executed correctly or not.

.. ml:param:: progress
   :type: Float

   This field shows the progress during an execution of a Matlab script.

.. ml:param:: showSessionWindow
   :type: Bool

   Show or hide the Matlab session window.

.. ml:param:: update
   :type: Trigger

   Execute the Matlab script.

.. ml:param:: matlabOutput
   :type: String

   Displays the output of executed Matlab script.

.. ml:param:: input/output image curve mat4 cso xmarker wem scalar vector matrix string Names
   :type: String

   The variable names in the Matlab script of the input and output data structures.

.. ml:param:: outBaseType0
   :type: Enum

   :item CurveList: List of CurveData objects
   :item XMarkerList: List of XMarker objects
   :item WEM: A WEM

   The output :ml:mod:`MLBase` types that are supported.

Events & Interaction
====================

An external Matlab script file can be dropped by the mouse in the :ml:fld:`matlabScriptPath` box.

Example
=======

The example network shows a number of different uses of the :ml:mod:`MatlabScriptWrapper` module.

Tips & Tricks
=============

None.

Known Bugs
==========

None.