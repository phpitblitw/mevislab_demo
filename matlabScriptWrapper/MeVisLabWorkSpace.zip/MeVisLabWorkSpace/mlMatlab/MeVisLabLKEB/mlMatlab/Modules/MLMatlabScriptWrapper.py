from mevis import *

def setVisibleInputImages():
  numOfInputImages = ctx.field("numberOfInputImages").value
  for inIndex in range(int(ctx.field("numberOfInputImages").maxValue())):
    ctx.field("input"+str(inIndex)).setHidden( numOfInputImages < inIndex+1 )
    if numOfInputImages < inIndex+1:
      ctx.field("input"+str(inIndex)).disconnectAll()

  ctx.updateLayout()
  return

def setVisibleOutputImages():
  numOfOutputImages = ctx.field("numberOfOutputImages").value
  for outIndex in range(int(ctx.field("numberOfOutputImages").maxValue())):
    ctx.field("output"+str(outIndex)).setHidden( numOfOutputImages < outIndex+1 )
    if numOfOutputImages < outIndex+1:
      ctx.field("output"+str(outIndex)).disconnectAll()

  ctx.updateLayout()
  return

def setVisibleInputBases():
  numOfInputBases = ctx.field("numberOfInputBases").value
  for inIndex in range(int(ctx.field("numberOfInputBases").maxValue())):
    ctx.field("inputBase0").setHidden( numOfInputBases < inIndex+1 )
    if numOfInputBases < inIndex+1:
      ctx.field("inputBase0").disconnectAll()

  ctx.updateLayout()
  return

def setVisibleOutputBases():
  numOfOutputBases = ctx.field("numberOfOutputBases").value
  for outIndex in range(int(ctx.field("numberOfOutputBases").maxValue())):
    ctx.field("outputBase0").setHidden( numOfOutputBases < outIndex+1 )
    if numOfOutputBases < outIndex+1:
      ctx.field("outputBase0").disconnectAll()

  ctx.updateLayout()
  setWEMOutput()
  return

def setWEMOutput():
  ctx.field("outputWEM").setHidden(not ctx.field("outBaseType0").value == "WEM" or
                                    ctx.field("numberOfOutputBases").value == 0)
  if(ctx.field("outputWEM").isHidden()):
    ctx.field("outputWEM").disconnectAll()
  ctx.field("outputBase0").setHidden(ctx.field("outBaseType0").value == "WEM" or
                                     ctx.field("numberOfOutputBases").value == 0)
  if(ctx.field("outputBase0").isHidden()):
    ctx.field("outputBase0").disconnectAll()
  ctx.updateLayout()
  return

def setVisibleScalars():
  numScalars = ctx.field("numberOfScalars").value
  for scalarIndex in range(int(ctx.field("numberOfScalars").maxValue())):
    if numScalars < scalarIndex+1:
      ctx.field("scalarName"+str(scalarIndex)).disconnectAll()
      ctx.field("scalar"+str(scalarIndex)).disconnectAll()

  ctx.updateLayout()
  return

def setVisibleVectors():
  numVectors = ctx.field("numberOfVectors").value
  for vectorIndex in range(int(ctx.field("numberOfVectors").maxValue())):
    if numVectors < vectorIndex+1:
      ctx.field("vectorName"+str(vectorIndex)).disconnectAll()
      ctx.field("vector"+str(vectorIndex)).disconnectAll()

  ctx.updateLayout()
  return

def setVisibleMatrices():
  numMatrices = ctx.field("numberOfMatrices").value
  for matrixIndex in range(int(ctx.field("numberOfMatrices").maxValue())):
    if numMatrices < matrixIndex+1:
      ctx.field("matrixName"+str(matrixIndex)).disconnectAll()
      ctx.field("matrix"+str(matrixIndex)).disconnectAll()

  ctx.updateLayout()
  return

def setVisibleStrings():
  numStrings = ctx.field("numberOfStrings").value
  for stringIndex in range(int(ctx.field("numberOfStrings").maxValue())):
    if numStrings < stringIndex+1:
      ctx.field("stringName"+str(stringIndex)).disconnectAll()
      ctx.field("string"+str(stringIndex)).disconnectAll()

  ctx.updateLayout()
  return