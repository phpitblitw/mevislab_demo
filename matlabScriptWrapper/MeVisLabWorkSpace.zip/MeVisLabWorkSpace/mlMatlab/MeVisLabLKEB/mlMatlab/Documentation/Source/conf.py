# -*- coding: utf-8 -*-
#
# mlMatlab documentation build configuration file
#
# This is a stipped version from the auto-generated conf.py
# created by sphinx-quickstart
import os, sys

MDL_SPHINX_EXT_PATH = os.path.abspath("sphinxext")

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
sys.path.append(MDL_SPHINX_EXT_PATH)

# -- General configuration -----------------------------------------------------

# Add any Sphinx extension module names here, as strings. They can be extensions
# coming with Sphinx (named 'sphinx.ext.*') or your custom ones.
extensions = ['mdlmodule', 'sphinx.ext.graphviz']

# Add any paths that contain templates here, relative to this directory.
templates_path = [MDL_SPHINX_EXT_PATH]

# The suffix of source filenames.
source_suffix = '.rst'

# The master toctree document.
master_doc = 'Documentation/Source/index'

# General information about the project.
project = u'mlMatlab'
copyright = u'LKEB'

# The version info for the project you're documenting, acts as replacement for
# |version| and |release|, also used in various other places throughout the
# built documents.
#
# The short X.Y version.
version = '0.1'
# The full version, including alpha/beta/rc tags.
release = '0.1'

# List of documents that shouldn't be included in the build.
#unused_docs = []

# List of directories, relative to source directory, that shouldn't be searched
# for source files.
exclude_trees = []

# The name of the Pygments (syntax highlighting) style to use.
pygments_style = 'sphinx'

# -- Options for HTML output ---------------------------------------------------

# The theme to use for HTML and HTML Help pages.  Major themes that come with
# Sphinx are currently 'default' and 'sphinxdoc'.
html_theme = 'sphinxdoc'


# -- Options for LaTeX output ----------

latex_documents = [(master_doc, 'documentation.tex', None, None, 'manual', False)]
