from sphinx.builders.html import StandaloneHTMLBuilder

from sphinx.util import SEP, os_path, relative_uri, ensuredir, \
    movefile, ustrftime, copy_static_entry, copyfile

from os import path

class MLHTMLBuilder(StandaloneHTMLBuilder):
    """
    This custom builder places the HTML files for the 
    generated .rst files of the MDL modules back into
    the original source folder while keeping the general
    index and static files in the designated target directory
    which usually is <PackageRoot>/Documentation/html
    """

    name = 'mlhtml'

    def index_page(self, pagename, doctree, title):
        """Modify the pagename for the Modules pages. """
        if pagename.startswith('Modules/'):
            pagename = SEP.join(["..", "..", pagename])
        StandaloneHTMLBuilder.index_page(self, pagename, doctree, title)

    def post_process_images(self, doctree):
        """Make sure that image are correctly linked in the "Modules" pages. """
        original_img_path = self.imgpath.split(SEP)

        # get the original location of the source for this doctree
        doc_source_file = doctree.attributes['source']
        doc_source_dir = path.dirname(doc_source_file)

        src_dir = self.srcdir # <PackageRoot>
        out_dir = self.outdir # <PackageRoot>/Documentation/html

        rel_out_dir = path.relpath(out_dir, src_dir) # Documentation/html
        rel_doc_source_dir = path.relpath(doc_source_dir, src_dir) # e.g. Modules/FooBar/html/

        # handle all documents that are not under the "Documentation" root
        if path.split(rel_doc_source_dir)[0].lower() != 'documentation':
            self.imgpath = SEP.join([
                    path.relpath(src_dir, doc_source_dir).replace(path.sep, SEP),  
                    rel_out_dir.replace(path.sep, SEP), 
                    original_img_path[-1]
                ]) 
        StandaloneHTMLBuilder.post_process_images(self, doctree)

    def get_outfilename(self, pagename):
        """ Overloads the default filename for 'Module' files """
        if pagename.startswith('Modules' + SEP):
            # place the output files back into the source directory
            return path.join(self.srcdir, os_path(pagename) + self.out_suffix)
        return path.join(self.outdir, os_path(pagename) + self.out_suffix)

    def get_relative_uri(self, from_, to, typ=None):
        """
        Overload for the relative uri taking into account the alternative
        location for the 'Module' files.
        """

        # get the normal uri syntax for the from_ and to variable
        from_uri = self.get_target_uri(from_)
        to_uri = self.get_target_uri(to, typ)
        
        # get the relative document paths between the source and the output dir
        out_to_src = path.relpath(self.srcdir, self.outdir).replace(path.sep, SEP)
        src_to_out = path.relpath(self.outdir, self.srcdir).replace(path.sep, SEP)

        isFromModule, isToModule = [x.startswith('Modules' + SEP) for x in  from_, to]
        if isFromModule and not isToModule:
            to_uri = SEP.join([src_to_out, to_uri])
        if not isFromModule and isToModule:
            from_uri = SEP.join([out_to_src, from_uri])
        return relative_uri(from_uri, to_uri)

    @staticmethod
    def on_page_context_created(app, pagename, templatename, context, doctree):
        """
        Overloads the pathto method during the HTML template expansion.
        This is needed for the MDLHTMLBuilder
        """
        builder = app.builder
        if not isinstance(builder, MLHTMLBuilder):
            return

        def pathto(otheruri, resource=False, baseuri=builder.get_target_uri(pagename)):
            rel = builder.get_relative_uri(pagename, otheruri)
            if not resource:
                return rel 
            else:
                return rel[:-len(builder.link_suffix)]
        context['pathto'] = pathto
