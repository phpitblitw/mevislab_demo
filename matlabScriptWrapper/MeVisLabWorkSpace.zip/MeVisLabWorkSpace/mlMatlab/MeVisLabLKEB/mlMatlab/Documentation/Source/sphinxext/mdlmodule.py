"""
Sphinx documentation generation extension for handling MDL modules.

author: Pieter Kitslaar
"""

from docutils import nodes
from docutils.parsers.rst import directives

from sphinx import addnodes
from sphinx.roles import XRefRole
from sphinx.locale import l_, _
from sphinx.domains import Domain, ObjType, Index
from sphinx.directives import ObjectDescription
from sphinx.util.nodes import make_refnode
from sphinx.util.compat import Directive
from sphinx.util.docfields import Field, GroupedField, TypedField
from sphinx.builders.html import StandaloneHTMLBuilder

from MLHTMLBuilder import MLHTMLBuilder

import os
import cPickle

STANDARD_MODULES_FILE = os.path.join(os.path.dirname(__file__), 'MLStandardModules.pickle')
MLStandardModules = {} # default dict when no file could be loaded
with open(STANDARD_MODULES_FILE,'r') as f:
    MLStandardModules = cPickle.load(f)

def findStandardModulePackage(module_name):
    """Returns a tuple with PackageGroup, PackageName for the standard module.
    None if the module could not be found. """
    for package_info, module_set in MLStandardModules.iteritems():
        if module_name in module_set:
            return package_info
    return None

split_by_comma = lambda x: str(x).split(',')
split_by_space = lambda x: str(x).split(' ')
identity = lambda x: x

class ModuleData(dict):
    option_spec = {
            'type': identity, 
            'author': split_by_comma, 
            'dll': identity, 
            'file': identity, 
            'genre': split_by_space, 
            'keywords': split_by_space, 
            'status': identity, 
            'seealso': split_by_space, 
    }

    def asText(self, k):
        modifier = self.option_spec[k]
        v = self[k]
        if v is None:
            return v

        if modifier == split_by_comma:
            return ",".join(map(str, v))
        elif modifier == split_by_space:
            return " ".join(map(str, v))
        return v

    def asList(self, k):
        modifier = self.option_spec[k]
        v = self[k]
        if modifier == identity:
            return [v]
        else:
            return v

def create_table(entries, numcols):
    table = nodes.table()
    tgroup = nodes.tgroup(cols=numcols)
    table += tgroup
    for col_index in range(numcols):
        tgroup += nodes.colspec(colwidth=1*(col_index % 2))
    tbody = nodes.tbody()
    tgroup += tbody
    for row_index in xrange(len(entries)/numcols + 1 ):
        row = nodes.row()
        for col_index in xrange(numcols):
            entry_index = numcols*row_index + col_index
            entry = nodes.entry()
            if entry_index < len(entries):
                entry += entries[entry_index]
            row += entry
        tbody += row
    return table

class MLModule(Directive):
    """ Class defining the `.. ml:module::` directive. """

    has_content = True
    required_arguments = 1
    optional_arguments = 0
    final_argument_whitespace = True

    option_spec = ModuleData.option_spec

    mdl_categories = option_spec.keys()

    def run(self):
        env = self.state.document.settings.env

        # get information about the module 
        modname = self.arguments[0].strip()
        mod_data = ModuleData()
        mod_data['name'] = modname
        for cat in self.mdl_categories:
            mod_data[cat] = self.options.get(cat)
        mod_data['comment'] = "\n".join(self.content) if self.content else 'None'

        env.temp_data['ml:module'] = modname
        env.domaindata['ml']['modules'][modname] = (env.docname, mod_data)

        # define a target node
        rolename = 'mlmodule'
        targetname = '%s-%s' % (rolename, modname)
        targetnode = nodes.target('', '', ids=[targetname], ismod=True)
        self.state.document.note_explicit_target(targetnode)

        # add targetnode to return list
        ret = [targetnode]

        # define the index entry for this module
        indextext = _('%s (%s)') % (modname, mod_data['type'])
        inode = addnodes.index(entries=[('single', indextext, targetname, modname)])
        ret.append(inode)

        # Build nodes for the Module header
        #
        comment = nodes.paragraph()
        comment += nodes.emphasis('', mod_data['comment'])
        ret.append(comment)

        def create_link(content, page, anchor=''):
            if not isinstance(env.app.builder, StandaloneHTMLBuilder):
                return content
            return make_refnode(env.app.builder, env.docname, page, anchor, content)
                
        entries = [] 
        for k in self.mdl_categories:
            #entries.append(nodes.paragraph('', "%s:" % k.title()))
            t = nodes.paragraph() 
            head_text = nodes.Text("%s:" % k.title())
            if k == 'seealso':
                t+= head_text
            else:
                t += create_link(head_text, 'ml-modules-by-%s' % k)
            entries.append(t)
            if k == 'seealso':
                seeAlsoPar = nodes.paragraph()
                for i, mod in enumerate(mod_data['seealso']):
                    if i > 0:
                        seeAlsoPar += nodes.Text(' ') # add space separator
                    ref = addnodes.pending_xref('', refdomain='ml', reftype='mod', reftarget= mod)
                    ref += nodes.Text(mod, mod)
                    seeAlsoPar += ref
                entries.append(seeAlsoPar)
            else:
                items_node = nodes.paragraph()
                for i, item in enumerate(mod_data.asList(k)):
                    if i > 0:
                        items_node += nodes.Text(' ') # add space separator
                    items_node += create_link(nodes.Text(item), 'ml-modules-by-%s' % k, 'cap-%s' % item)
                entries.append( items_node )

        properties = nodes.paragraph()
        properties += create_table(entries, 6)

        ret.append(properties)

        return ret

class MLField(ObjectDescription):
    has_content = True

    interface_group = 'None '

    option_spec = {
        'type': identity
    }

    def handle_signature(self, sig, signode):
        # find the current module
        modname = self.env.temp_data.get('ml:module')
        if not modname:
            raise ValueError('Did not find module')

        fieldname = self.arguments[0].strip()
        fullname = "%s.%s" % (modname, fieldname)

        #signode += addnodes.desc_addname(self.interface_group, self.interface_group)
        signode += addnodes.desc_name(fieldname, fieldname)
        field_type = " (%s)" % self.options.get('type')
        signode += addnodes.desc_annotation(field_type, field_type)
        
        return fieldname, modname 

    def add_target_and_index(self, fld_mod, sig, signode):
        fieldname, modulename = fld_mod
        fullname = "%s.%s" % (modulename, fieldname)

        if fullname not in self.state.document.ids:
            signode['first'] = not self.names
            signode['names'].append(fullname)
            signode['ids'].append(fullname)
            self.state.document.note_explicit_target(signode)

            fields = self.env.domaindata['ml']['fields']
            if fullname in fields:
                self.env.warn(
                    self.env.docname,
                    'duplicate field description of %s, ' % fullname +
                    'other instance in ' +
                    self.env.doc2path(fields[fullname][0]) +
                    ', use :noindex: for one of them',
                    self.lineno)
            fields[fullname] = (self.env.docname, self.objtype)

        index_text = _('%s (%s %s)' % (fieldname, modulename, self.interface_group.strip()))
        self.indexnode['entries'].append((
            'single', index_text, fullname, fullname))

class MLParameter(MLField):
    interface_group = 'parameter '

    doc_field_types = [
        GroupedField('item_value', label=l_('Items'), names=('item',))
    ]

class MLInput(MLField):
    interface_group = 'input '

class MLOutput(MLField):
    interface_group = 'output '


class MLXRefRole(XRefRole):
    def process_link(self, env, refnode, has_explicit_title, title, target):
        refnode['ml:module'] = env.temp_data.get('ml:module')
        if not has_explicit_title:
            title = title.lstrip('.')   # only has a meaning for the target
            target = target.lstrip('~') # only has a meaning for the title
            # if the first character is a tilde, don't display the module/class
            # parts of the contents
            if title[0:1] == '~':
                title = title[1:]
                dot = title.rfind('.')
                if dot != -1:
                    title = title[dot+1:]
        # if the first character is a dot, search more specific namespaces first
        # else search builtins first
        if target[0:1] == '.':
            target = target[1:]
            refnode['refspecific'] = True
        return title, target

class MLBaseModuleIndex(Index):
    """
    Index subclass to provide the MeVisLab module index.
    """

    name = 'mlmodindex'
    localname = l_('MeVisLab Module Index')
    shortname = l_('modules')
    sortby = None 
    
    def generate(self, docnames=None):
        content = {}
        # list of prefixes to ignore
        ignores = self.domain.env.config['modindex_common_prefix']
        ignores = sorted(ignores, key=len, reverse=True)
        # list of all modules, sorted by module name
        modules = sorted(self.domain.data['modules'].iteritems(),
                         key=lambda x: x[0].lower())

        # sort out collapsable modules
        num_toplevels = 0
        for modname, (docname, mod_data) in modules:
            if docnames and docname not in docnames:
                continue

            letter = modname[0].lower()
            if self.sortby:
                letter = mod_data[self.sortby]

            if isinstance(letter, basestring):
                letter = [letter]

            for l in letter:
                # letter should be a 'unicode' string for LaTeX writer 
                # to work
                entries = content.setdefault(unicode(l), [])
                entries.append(
                    [
                        modname, # the name of the index entry to be displayed
                        0, #  0 : normal entry, 1 : entry with sub-entries,  2 : sub-entry
                        docname, # docname where the entry is located
                        'mlmodule-' + modname,  # anchor for the entry within docname
                        '', # extra info for the entry
                        '', # qualifier for the description
                        mod_data.get('comment') 
                    ]
                )

        # apply heuristics when to collapse modindex at page load:
        # only collapse if number of toplevel modules is larger than
        # number of submodules
        collapse = len(modules) - num_toplevels < num_toplevels

        # sort by first letter
        content = sorted(content.iteritems())

        return content, collapse

def newModuleIndex(_name, _localname, _shortname, _sortby):
    class MLModuleIndex(MLBaseModuleIndex):
        name = _name 
        localname = l_(_localname) if _localname else None
        shortname = l_(_shortname) if _shortname else None
        sortby = _sortby 
    return MLModuleIndex

class MeVisLabDomain(Domain):
    """MeVisLab domain"""
    name = 'ml'
    label = 'MeVisLab'
    object_types = {
        'module': ObjType(l_('module'), 'mod', 'module'),
        'field': ObjType(l_('field'), 'fld', 'field'),
    }

    directives = {
        'module': MLModule,
        'input': MLInput,
        'param': MLParameter,
        'output': MLOutput,
    }

    roles = {
        'mod': MLXRefRole(),
        'fld': MLXRefRole(),
    }

    initial_data = {
        'modules': {},
        'fields': {},
    }

    indices = [
        newModuleIndex('modules-by-name', 'Modules by Name', None, None),
        newModuleIndex('modules-by-genre', 'Modules by Genre', None, 'genre'),
        newModuleIndex('modules-by-author', 'Modules by Author', None, 'author'),
        newModuleIndex('modules-by-keywords', 'Modules by Keywords', None, 'keywords'),
        newModuleIndex('modules-by-type', 'Modules by Type', None, 'type'),
        newModuleIndex('modules-by-dll', 'Modules by DLL', None, 'dll'),
        newModuleIndex('modules-by-file', 'Modules by File', None, 'file'),
        newModuleIndex('modules-by-status', 'Modules by Status', None, 'status'),
    ]

    def clear_doc(self, docname):
        for modname, (fn, _) in self.data['modules'].items():
            if fn == docname:
                del self.data['modules'][modname]
        for field, (fn, _) in self.data['fields'].items():
            if fn == docname:
                del self.data['fields'][field]

    def get_objects(self):
        for modname, info in self.data['modules'].iteritems():
            yield (modname, modname, 'module', info[0], 'mlmodule-' + modname, 0)
        for fieldname, info in self.data['fields'].iteritems():
            yield (fieldname, fieldname, 'field', info[0], fieldname, 0)


    def resolve_xref(self, env, fromdocname, builder,
                     type, target, node, contnode):
        if type == 'fld':
            if '.' in target:
                module, target = target.split('.', 1)
            else:
                module = node['ml:module']
            fullname = "%s.%s" % (module, target)
            if fullname in self.data['fields']:
                docname = self.data['fields'][fullname][0]
                return make_refnode(builder, fromdocname, docname, fullname, contnode,
                fullname)
            else:
               print self.data['fields']
               env.warn(fromdocname,
                     'Could not find field %s' % fullname,
                     node.line)

        if type == 'mod':
            modname = target
            if modname in self.data['modules']:
                title = modname
                docname = self.data['modules'][modname][0]
                return make_refnode(builder, fromdocname, docname,
                                    'mlmodule-' + modname, contnode, title)
            
            # find a refernce to a 'Standard MeVisLab module'
            package_info = findStandardModulePackage(modname)
            if package_info:
                print "Found external reference", package_info, modname
                node = nodes.reference('', '', internal=False)
                node['refuri'] = 'http://www.mevislab.de/fileadmin/docs/current/%s/%s/Documentation/Publish/ModuleReference/%sFrame.html' % (
                    package_info[0], package_info[1], modname
                )
                node['reftitle'] = modname
                node.append(contnode)
                return node
                
        return None
            
def setup(app):
  """ Define all the options of this extension. """
  app.connect('html-page-context', MLHTMLBuilder.on_page_context_created)
  app.add_builder(MLHTMLBuilder)
  app.add_domain(MeVisLabDomain)
