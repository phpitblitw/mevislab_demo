// Copyright (c) 2009, Fraunhofer MEVIS Institute for Medical Image Computing
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
// * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
// * Redistributions in binary form must reproduce the above copyright
// notice, this list of conditions and the following disclaimer in the
// documentation and/or other materials provided with the distribution.
// * Neither the name of the Fraunhofer MEVIS nor the
// names of its contributors may be used to endorse or promote products
// derived from this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDER ''AS IS'' AND ANY
// EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE AUTHORS OR THE COPYRIGHT HOLDER BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//----------------------------------------------------------------------------------
//! The ML module class MatlabScriptWrapper.
/*!
// \file    mlMatlabScriptWrapper.cpp
// \author  Alexander Gryanik, Markus Harz, Ola Friman, Felix Ritter, Alexander Broersen
// \date    2009-02-23
//
// Module for executing Matlab scripts in MeVisLab.
*/
//----------------------------------------------------------------------------------


// Local includes
#include "mlMatlabScriptWrapper.h"

// SDK includes
#include <macBundle.h>

// System includes
#include <iostream>
#include <sstream>
#include <sys/stat.h>

ML_START_NAMESPACE

//! Implements code for the runtime type system of the ML
#ifdef WIN32
#pragma warning( push )
#pragma warning( disable : 4702 ) // VC8: unreachable code
ML_MODULE_CLASS_SOURCE(MatlabScriptWrapper, Module);
#pragma warning( pop )
#else
ML_MODULE_CLASS_SOURCE(MatlabScriptWrapper, Module);
#endif


//----------------------------------------------------------------------------------
//! Constructor
//----------------------------------------------------------------------------------
MatlabScriptWrapper::MatlabScriptWrapper (void)
: Module(3, 3)
{
  ML_TRACE_IN("MatlabScriptWrapper::MatlabScriptWrapper()")

  FieldContainer *fields = getFieldContainer();
  ML_CHECK(fields);

  //! Change field values here without calling handleNotification.
  handleNotificationOff();

  (_inputBaseFld  = fields->addBase("inputBase0") )->setBaseValue(NULL);
  (_outputBaseFld = fields->addBase("outputBase0"))->setBaseValue(NULL);
  ML_CHECK_NEW(_outWEM,WEM());
  (_outputWEMFld = fields->addBase("outputWEM"))->setBaseValue(_outWEM);

  //! Add different base types as output.
  const char *const outputBaseTypes[3]={"CurveList", "XMarkerList", "WEM"};
  _outBaseTypeFld = fields->addEnum("outBaseType0", outputBaseTypes, 3);

  //! Use Matlab commands in text field.
  (_matlabScriptFld = fields->addString("matlabScript"))->setStringValue("scalar0 = scalar0+1 %Type your matlab script here.");
  //! Use external Matlab script.
  (_useExternalScriptFld = fields->addBool("useExternalScript"))->setBoolValue(false);
  //! Where will Matlab script be dumped.
  (_matlabScriptPathFld = fields->addString("matlabScriptPath"))->setStringValue("");

  //! Set input and output image names used in Matlab.
  (_inImageNameFld[0]  = fields->addString("inImageName0") )->setStringValue("inImage0");
  (_inImageNameFld[1]  = fields->addString("inImageName1") )->setStringValue("inImage1");
  (_inImageNameFld[2]  = fields->addString("inImageName2") )->setStringValue("inImage2");
  (_outImageNameFld[0] = fields->addString("outImageName0"))->setStringValue("outImage0");
  (_outImageNameFld[1] = fields->addString("outImageName1"))->setStringValue("outImage1");
  (_outImageNameFld[2] = fields->addString("outImageName2"))->setStringValue("outImage2");
  //! Set input Base(List) and output Base(List) names used in Matlab.
  (_inBaseNameFld  = fields->addString("inBaseName0"))->setStringValue("inBase0");
  (_outBaseNameFld = fields->addString("outBaseName0"))->setStringValue("outBase0");

  //! Add update button.
  _calculateFld = fields->addNotify("update");
  //! Use automatic update after change of an input.
  (_autoUpdateFld = fields->addBool("autoUpdate"))->setBoolValue(false);
  //! Use automatic apply after change of a parameter/field.
  (_autoApplyFld = fields->addBool("autoApply"))->setBoolValue(false);
  //! Add restart Matlab button.
  _restartMatlabFld = fields->addNotify("restartMatlab");
  //! Add field for a progress bar
  (_progressField = fields->addProgress("progress"))->setFloatValue(0);
  // Error message.
  (_statusFld = fields->addString("status"))->setStringValue("Ready.");

  // Set number of visible scalar fields.
  (_numOfScalars = fields->addInt("numberOfScalars"))->setIntValue(0);
  // Set scalar name and value fields.
  (_scalarNameFld[0] = fields->addString("scalarName0"))->setStringValue("scalar0");
  (_scalarFld[0] = fields->addDouble("scalar0"))->setDoubleValue(0.0);
  (_scalarNameFld[1] = fields->addString("scalarName1"))->setStringValue("scalar1");
  (_scalarFld[1] = fields->addDouble("scalar1"))->setDoubleValue(0.0);
  (_scalarNameFld[2] = fields->addString("scalarName2"))->setStringValue("scalar2");
  (_scalarFld[2] = fields->addDouble("scalar2"))->setDoubleValue(0.0);
  (_scalarNameFld[3] = fields->addString("scalarName3"))->setStringValue("scalar3");
  (_scalarFld[3] = fields->addDouble("scalar3"))->setDoubleValue(0.0);
  (_scalarNameFld[4] = fields->addString("scalarName4"))->setStringValue("scalar4");
  (_scalarFld[4] = fields->addDouble("scalar4"))->setDoubleValue(0.0);
  (_scalarNameFld[5] = fields->addString("scalarName5"))->setStringValue("scalar5");
  (_scalarFld[5] = fields->addDouble("scalar5"))->setDoubleValue(0.0);

  // Set number of visible string fields.
  (_numOfStrings = fields->addInt("numberOfStrings"))->setIntValue(0);
  // Set string name and value fields.
  (_stringNameFld[0] = fields->addString("stringName0"))->setStringValue("string0");
  (_stringFld[0] = fields->addString("string0"))->setStringValue("");
  (_stringNameFld[1] = fields->addString("stringName1"))->setStringValue("string1");
  (_stringFld[1] = fields->addString("string1"))->setStringValue("");
  (_stringNameFld[2] = fields->addString("stringName2"))->setStringValue("string2");
  (_stringFld[2] = fields->addString("string2"))->setStringValue("");
  (_stringNameFld[3] = fields->addString("stringName3"))->setStringValue("string3");
  (_stringFld[3] = fields->addString("string3"))->setStringValue("");
  (_stringNameFld[4] = fields->addString("stringName4"))->setStringValue("string4");
  (_stringFld[4] = fields->addString("string4"))->setStringValue("");
  (_stringNameFld[5] = fields->addString("stringName5"))->setStringValue("string5");
  (_stringFld[5] = fields->addString("string5"))->setStringValue("");

  // Set number of visible vector fields.
  (_numOfVectors = fields->addInt("numberOfVectors"))->setIntValue(0);
  // Set vector name and value fields.
  (_vectorNameFld[0] = fields->addString("vectorName0"))->setStringValue("vector0");
  (_vectorFld[0] = fields->addVector4("vector0"))->setStringValue("0 0 0 0");
  (_vectorNameFld[1] = fields->addString("vectorName1"))->setStringValue("vector1");
  (_vectorFld[1] = fields->addVector4("vector1"))->setStringValue("0 0 0 0");
  (_vectorNameFld[2] = fields->addString("vectorName2"))->setStringValue("vector2");
  (_vectorFld[2] = fields->addVector4("vector2"))->setStringValue("0 0 0 0");
  (_vectorNameFld[3] = fields->addString("vectorName3"))->setStringValue("vector3");
  (_vectorFld[3] = fields->addVector4("vector3"))->setStringValue("0 0 0 0");
  (_vectorNameFld[4] = fields->addString("vectorName4"))->setStringValue("vector4");
  (_vectorFld[4] = fields->addVector4("vector4"))->setStringValue("0 0 0 0");
  (_vectorNameFld[5] = fields->addString("vectorName5"))->setStringValue("vector5");
  (_vectorFld[5] = fields->addVector4("vector5"))->setStringValue("0 0 0 0");

  // Set number of visible matrix fields.
  (_numOfMatrices = fields->addInt("numberOfMatrices"))->setIntValue(0);
  // Set matrix name and value fields.
  (_matrixNameFld[0] = fields->addString("matrixName0"))->setStringValue("matrix0");
  (_matrixFld[0] = fields->addMatrix("matrix0"))->setStringValue("1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1");
  (_matrixNameFld[1] = fields->addString("matrixName1"))->setStringValue("matrix1");
  (_matrixFld[1] = fields->addMatrix("matrix1"))->setStringValue("1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1");
  (_matrixNameFld[2] = fields->addString("matrixName2"))->setStringValue("matrix2");
  (_matrixFld[2] = fields->addMatrix("matrix2"))->setStringValue("1 0 0 0 0 1 0 0 0 0 1 0 0 0 0 1");

  //! Add field to display Matlab output.
  (_matlabOutputBufferFld = fields->addString("matlabOutput"))->setStringValue("");

#if defined(MACOS)
  if (m_startCmd.empty()) {
    // Try to locate Matlab binary in PATH environment
    const char *pathEnv = getenv("PATH");
    if (pathEnv) {
      std::istringstream pathList(pathEnv);
      while (! pathList.eof()) {
        std::string path;
        std::getline(pathList, path, ':');
        path.append("/matlab");
        struct stat info;
        if (::stat(path.c_str(), &info) == 0) {
          m_startCmd = path;
        }
      }
    }
  }
  
  if (m_startCmd.empty()) {
    // Try to locate Matlab binary via its bundle id
    std::string matlabBundle = macx::Bundle::getBundleDirectory("com.mathworks.StartMATLAB");
    if (! matlabBundle.empty()) {
      std::string path = matlabBundle + "/bin/matlab";
      struct stat info;
      if (::stat(path.c_str(), &info) == 0) {
        m_startCmd = path;
      }
    }
  }
  
  if (! m_startCmd.empty()) {
    std::cout << "Found Matlab binary at: " << m_startCmd.c_str() << std::endl;
  }
#endif

  m_pEngine = engOpen( (m_startCmd.empty()) ? NULL : m_startCmd.c_str() );

  if ( !_checkMatlabIsStarted() ) {
    std::cerr << "MatlabScriptWrapper(): Error: Matlab Engine not found. A Matlab installation is required." << std::endl;
    std::cerr << "Additional Hints:" << std::endl;
    std::cerr << "-(1) On Windows, only ONE Matlab COM server must be registered." << std::endl;
    std::cerr << "---- Execute '>> matlab /regserver' on a command line in MATLAB/R2007b/bin/win32" << std::endl;
    std::cerr << "-(2) On Mac OS X, it is currently required to set the environment variable" << std::endl;
    std::cerr << "---- DYLD_LIBRARY_PATH to /Applications/MATLAB_R2010a.app/bin/maci64 before" << std::endl;
    std::cerr << "---- MeVisLab is started." << std::endl;

    (_showSessionWindowFld = fields->addBool("showSessionWindow"))->setBoolValue(false);
    _statusFld->setStringValue("Cannot find Matlab engine!");
  } else {
    //! Show the Matlab session window.
    bool vis;
    engGetVisible(m_pEngine, &vis);
    (_showSessionWindowFld = fields->addBool("showSessionWindow"))->setBoolValue(vis);
  }

  //! Reactivate calls of handleNotification on field changes.
  handleNotificationOn();
}


//----------------------------------------------------------------------------------
//! Destructor
//----------------------------------------------------------------------------------
MatlabScriptWrapper::~MatlabScriptWrapper()
{
  ML_TRACE_IN("MatlabScriptWrapper::~MatlabScriptWrapper()");

  if(_outWEM != NULL) {
    _outWEM->removeAll();
  }
  // Only remove reference to Matlab engine if this process is already stopped
  // to reduce startup-time for Matlab and keep variables in the workspace.
  if(!_checkMatlabIsStarted()) {
    engClose(m_pEngine);
  }

  ML_DELETE(_outWEM);
}


//----------------------------------------------------------------------------------
//! Handle field changes of the field \c field.
//----------------------------------------------------------------------------------
void MatlabScriptWrapper::handleNotification (Field* field)
{
  ML_TRACE_IN("MatlabScriptWrapper::handleNotification()");

  if(_progressField == field) {
    return;
  }

  if(field == _restartMatlabFld) {
    if(!_checkMatlabIsStarted()) {
      // Start Matlab if it's not started.
      m_pEngine = engOpen( (m_startCmd.empty()) ? NULL : m_startCmd.c_str() );
      // If Matlab engine is started, make session window (in)visible.
      if(_checkMatlabIsStarted()) {
        engSetVisible(m_pEngine,_showSessionWindowFld->getBoolValue());
      } else {
        _statusFld->setStringValue("Cannot find Matlab engine!");
      }
    } else {
      _statusFld->setStringValue("Matlab is already started");
    }
  }

  if( (field == _showSessionWindowFld) && _checkMatlabIsStarted() ) {
    if(_showSessionWindowFld->isOn()) {
      engSetVisible(m_pEngine, true);
    } else {
      engSetVisible(m_pEngine, false);
    }
  }

  // Calculate output on: - an update initiated by a user,
  //                      - change of an input if Auto update is enabled,
  //                      - change of a field if Auto apply is enabled.
  if( (field == _calculateFld) ||
      (_autoUpdateFld->isOn() && ((field == getInputImageField(0))||(field == getInputImageField(1))||
                                  (field == getInputImageField(2))||(field == _inputBaseFld)) ) ||
      (_autoApplyFld->isOn()  && ((field == _scalarFld[0])||(field == _scalarFld[1])||(field == _scalarFld[2])||
                                  (field == _scalarFld[3])||(field == _scalarFld[4])||(field == _scalarFld[5])||
                                  (field == _vectorFld[0])||(field == _vectorFld[1])||(field == _vectorFld[2])||
                                  (field == _vectorFld[3])||(field == _vectorFld[4])||(field == _vectorFld[5])||
                                  (field == _matrixFld[0])||(field == _matrixFld[1])||(field == _matrixFld[2])||
                                  (field == _matrixFld[3])||(field == _matrixFld[4])||(field == _matrixFld[5])||
                                  (field == _stringFld[0])||(field == _stringFld[1])||(field == _stringFld[2])||
                                  (field == _stringFld[3])||(field == _stringFld[4])||(field == _stringFld[5])) )
    ) {
    _process();
  }
}


//----------------------------------------------------------------------------------
//! The process method is called by the parent class.
//----------------------------------------------------------------------------------
void MatlabScriptWrapper::_process()
{
  ML_TRACE_IN("MatlabScriptWrapper::process()")

  _progressField->setFloatValue(0.1);
  // Check if Matlab is started.
  if(!_checkMatlabIsStarted()) {
    _statusFld->setStringValue("Cannot find Matlab engine!");
    return;
  }

  // Get script to evaluate
  std::string evaluateString = "";
  bool validScriptString = true;
  if(_useExternalScriptFld->isOn()) { // Get script from .m-file
    validScriptString = _loadMatlabScriptFromFile(evaluateString);
  } else {
    evaluateString = _matlabScriptFld->getStringValue();
  }

  _progressField->setFloatValue(0.2);
  // Execute Matlab script only when the string is valid
  if(validScriptString) {
    _progressField->setFloatValue(0.3);
    // Copy AB:added extra input Base objects
    Base* inputBase = _inputBaseFld->getBaseValue();
    if( inputBase != NULL ) {
      // Check if a valid Base object is attached to the input.
      if( _inputBaseFld->isValidValue() && (ML_BASE_IS_A(inputBase,CurveData)||ML_BASE_IS_A(inputBase,CurveList)) ) {
        // Copy input CurveData or CurveList to Matlab.
        _copyInputCurveToMatlab();
      } else if( _inputBaseFld->isValidValue() && ML_BASE_IS_A(inputBase, XMarkerList) ) {
        // Copy input XMarkerList to Matlab.
        _copyInputXMarkerToMatlab();
      } else if( _inputBaseFld->isValidValue() && ML_BASE_IS_A(inputBase, Mat4List) ) {
        // AB:added copy input Mat4List to Matlab.
        _copyInputMat4ListToMatlab();
      } else if( _inputBaseFld->isValidValue() && ML_BASE_IS_A(inputBase, CSOList) ) {
        // AB:added copy input CSOList to Matlab.
        _copyInputCSOListToMatlab();
      } else if( _inputBaseFld->isValidValue() && ML_BASE_IS_A(inputBase, WEM) ) {
        // Copy input WEM to Matlab.
        _copyInputWEMToMatlab();
      } else {
        std::cout << "Input Base type not supported in MatlabScriptWrapper!" << std::endl << std::flush;
      }
    }

    _progressField->setFloatValue(0.4);
    // Copy input image data to Matlab.
    _copyInputImageDataToMatlab();
    // Copy scalar values to Matlab.
    _copyInputScalarsToMatlab();
    // Copy string values to Matlab.
    _copyInputStringsToMatlab();
    // Copy vector values to Matlab.
    _copyInputVectorsToMatlab();
    // Copy matrix values to Matlab.
    _copyInputMatricesToMatlab();

    _progressField->setFloatValue(0.5);
    // Insert at the end of the script variable to proof execution status
    // and run the script in Matlab
    evaluateString += "\nmevmatscr=1;";	// Added ';' to prevent unnecessary output
    _statusFld->setStringValue("Matlab script is executing....");
    
    // Buffer to capture Matlab output
    #define BUFSIZE 5120
    char buffer[BUFSIZE+1];
    buffer[BUFSIZE] = '\0';
    // Start logging Matlab output
    engOutputBuffer(m_pEngine, buffer, BUFSIZE);

    // and run the script in Matlab
    engEvalString(m_pEngine, evaluateString.c_str());

    // Stop logging Matlab output
    engOutputBuffer(m_pEngine, NULL, 0);
    // Use rich text format in output for visibility
    std::string output("<PRE>");
    output.append(buffer);
    _matlabOutputBufferFld->setStringValue(output);

    // If variable mevmatscr exist it means the whole Matlab script was executed.
    mxArray *mtmp = engGetVariable(m_pEngine,"mevmatscr");
    if(mtmp!=NULL) {
      _statusFld->setStringValue("Matlab execution successful!");
      engEvalString(m_pEngine, "clear mevmatscr");
      mxDestroyArray(mtmp); mtmp = NULL;
    } else {
      _statusFld->setStringValue("Matlab script contains errors!");
      mxDestroyArray(mtmp); mtmp = NULL;
      return;
    }

    _progressField->setFloatValue(0.6);
    // Get Base type and copy results from Matlab into MeVisLab
    _outputBaseFld->setBaseValue(NULL);
    switch(OutputBaseType(_outBaseTypeFld->getEnumValue())) {
        case MATLAB_CURVELIST:
          _getCurveDataBackFromMatlab();
          _outputBaseFld->setBaseValue(&_outputCurveList);
          break;
        case MATLAB_XMARKERLIST:
          _getXMarkerBackFromMatlab();
          _outputBaseFld->setBaseValue(&_outputXMarkerList);
          break;
        case MATLAB_WEM:
          _getWEMBackFromMatlab();
          //_outputBaseFld->setBaseValue(&_outWEM);
          break;
        default:
          ML_PRINT_ERROR("MatlabScriptWrapper::handleNotification()",
                         ML_BAD_DATA_TYPE, "Output Base type not implemented.");
    }

    _progressField->setFloatValue(0.7);
    // Get scalars back from Matlab. First store the current scalars so that
    // we can check if they change. A notification is only sent upon change.
    double tmpScalars[6];
    for(int k=0; k<6; ++k) {
      tmpScalars[k] = _scalarFld[k]->getDoubleValue();
    }
    _getScalarsBackFromMatlab();
    for(int k=0; k<6; ++k) {
      if(tmpScalars[k] == _scalarFld[k]->getDoubleValue()) {
        _scalarFld[k]->touch();
      }
    }
    // Get strings back from Matlab. First store the current strings so that
    // we can check if they change. A notification is only sent upon change.
    std::string tmpstrings[6];
    for(int k=0; k<6; ++k) {
      tmpstrings[k] = _stringFld[k]->getStringValue();
    }
    _getStringsBackFromMatlab();
    for(int k=0; k<6; ++k) {
      if(tmpstrings[k] == _stringFld[k]->getStringValue()) {
        _stringFld[k]->touch();
      }
    }

    // Get vectors back from Matlab. First store the current vectors so that
    // we can check if they change. A notification is only sent upon change.
    for(int k=0; k<6; ++k) {
      tmpstrings[k] = _vectorFld[k]->getStringValue();
    }
    _getVectorsBackFromMatlab();
    for(int k=0; k<6; ++k) {
      if(tmpstrings[k] == _vectorFld[k]->getStringValue()) {
        _vectorFld[k]->touch();
      }
    }

    // Get matrices back from Matlab. First store the current matrices so that
    // we can check if they change. A notification is only sent upon change.
    for(int k=0; k<3; ++k) {
      tmpstrings[k] = _matrixFld[k]->getStringValue();
    }
    _getMatricesBackFromMatlab();
    for(int k=0; k<3; ++k) {
      if(tmpstrings[k] == _matrixFld[k]->getStringValue()) {
        _matrixFld[k]->touch();
      }
    }

    // Notify image attachments that are new images calculated so that they
    // update themselves and call the calcOutSubImage()
    _progressField->setFloatValue(0.8);
    getOutputImageField(0)->touch();
    getOutputImageField(1)->touch();
    getOutputImageField(2)->touch();

    _progressField->setFloatValue(0.9);
    // Notify the Base output
    _outputBaseFld->touch();

    // Notify the WEM output
    std::vector<WEMEventContainer>ecList;
    WEMEventContainer ec; 
    ec.notificationType = WEM_NOTIFICATION_FINISHED  |
                          WEM_NOTIFICATION_SELECTION |
                          WEM_NOTIFICATION_REPAINT;
    ecList.push_back(ec);
    _outWEM->notifyObservers(ecList);
    
    _progressField->setFloatValue(1.0);

  } else {
    _matlabOutputBufferFld->setStringValue("");
  }
}


//----------------------------------------------------------------------------------
//! Configures (in)validation handling of inputs which are not connected or up to date.
//----------------------------------------------------------------------------------
Module::INPUT_HANDLE MatlabScriptWrapper::handleInput (int inIndex, INPUT_STATE /*state*/) const
{
  ML_TRACE_IN("MatlabScriptWrapper::handleInput ()");

  // If one of inputs is open we close it artificially by setting the input to a dummy input.
  if((inIndex == 0)||(inIndex == 1)||(inIndex == 2)) {
    return Module::REDIRECT_TO_DUMMY_OP;
  }
  // If any other input is not present or invalid, we cannot do any processing.
  else {
    return Module::INVALIDATE;
  }
}

#if ML_MAJOR_VERSION >= 2
# define __setInputSubImageDataType(__t)  for(int __i=0;__i<3;++__i) {getOutputImage(outIndex)->setInputSubImageDataType(__i,__t);}
#else
# define __setInputSubImageDataType(__t)
#endif

//----------------------------------------------------------------------------------
//! Sets properties of the output image at output \c outIndex.
//----------------------------------------------------------------------------------
void MatlabScriptWrapper::calculateOutputImageProperties (int outIndex)
{
  ML_TRACE_IN("MatlabScriptWrapper::calculateOutputImageProperties ()");

  // Proof if Matlab is started.
  if(!_checkMatlabIsStarted()) {
    std::cerr << "calculateOutputImageProperties(): Cannot find Matlab engine!" << std::endl << std::flush;
    getOutputImage(outIndex)->setInvalid();
    getOutputImage(outIndex)->setStateInfo("Cannot find Matlab engine!", ML_BAD_DATA_TYPE);
    return;
  }

  // Get variable name in the Matlab workspace of the output image
  std::string outname = _outImageNameFld[outIndex]->getStringValue();
  mxArray *m_pImage = engGetVariable(m_pEngine, outname.c_str());

  // If we can find the variable and calculate its size, go on.
  if(m_pImage != NULL) {
    const mwSize m_numDims = mxGetNumberOfDimensions(m_pImage);
    if(m_numDims>6) {
      std::cerr << "calculateOutputImageProperties(): Too many dimensions in Matlab image!" << std::endl << std::flush;
      return;
    }
    ImageVector outExt = ImageVector(1,1,1,1,1,1);
    for (size_t i=0; i<m_numDims; i++) {
      outExt[i] = static_cast<MLint>(mxGetDimensions(m_pImage)[i]);
    }

    // Set page size.
    getOutputImage(outIndex)->setPageExtent(outExt);
    // Set output image size.
    getOutputImage(outIndex)->setImageExtent(outExt);
    // Set AB:added different output image data types.
    switch (mxGetClassID(m_pImage)) {
      case mxDOUBLE_CLASS: getOutputImage(outIndex)->setDataType(MLdoubleType); __setInputSubImageDataType(MLdoubleType); break;
      case mxSINGLE_CLASS: getOutputImage(outIndex)->setDataType(MLfloatType);  __setInputSubImageDataType(MLdoubleType); break;
      case mxINT8_CLASS:   getOutputImage(outIndex)->setDataType(MLint8Type);   __setInputSubImageDataType(MLdoubleType); break;
      case mxUINT8_CLASS:  getOutputImage(outIndex)->setDataType(MLuint8Type);  __setInputSubImageDataType(MLdoubleType); break;
      case mxINT16_CLASS:  getOutputImage(outIndex)->setDataType(MLint16Type);  __setInputSubImageDataType(MLdoubleType); break;
      case mxUINT16_CLASS: getOutputImage(outIndex)->setDataType(MLuint16Type); __setInputSubImageDataType(MLdoubleType); break;
      case mxINT32_CLASS:  getOutputImage(outIndex)->setDataType(MLint32Type);  __setInputSubImageDataType(MLdoubleType); break;
      case mxUINT32_CLASS: getOutputImage(outIndex)->setDataType(MLuint32Type); __setInputSubImageDataType(MLdoubleType); break;
      case mxINT64_CLASS: // AB:Matlab does not (yet) support basic operations on this type
        //getOutImg(outIndex)->setDataType(MLint64Type);
        //break;
      default:
        getOutputImage(outIndex)->setDataType(ML_BAD_DATA_TYPE);
        std::cerr << "calculateOutputImageProperties(): Output type from Matlab not supported" << std::endl << std::flush;
    }
    mxDestroyArray(m_pImage); m_pImage = NULL;

    // Get min and max values in Matlab workspace and set them in MeVisLab
    std::ostringstream minmaxCommand;
    minmaxCommand << "mevtmpminval = min(" << outname << "(:));" << "mevtmpmaxval = max(" << outname << "(:));";
    engEvalString(m_pEngine, minmaxCommand.str().c_str());
    mxArray *minVal = engGetVariable(m_pEngine, "mevtmpminval");
    mxArray *maxVal = engGetVariable(m_pEngine, "mevtmpmaxval");
    // if min and max are not defined, set default values
    if ((minVal==NULL) || (minVal==NULL)) {
      getOutputImage(outIndex)->setMinVoxelValue(0);
      getOutputImage(outIndex)->setMaxVoxelValue(127);
    } else {
      getOutputImage(outIndex)->setMinVoxelValue(mxGetScalar(minVal));
      getOutputImage(outIndex)->setMaxVoxelValue(mxGetScalar(maxVal));
    }
    mxDestroyArray(minVal); minVal = NULL;
    mxDestroyArray(maxVal); maxVal = NULL;
    engEvalString(m_pEngine, "clear mevtmpminval mevtmpmaxval");
  } else {
    getOutputImage(outIndex)->setInvalid();
    getOutputImage(outIndex)->setStateInfo("Cannot set output size; variable not found in Matlab workspace.",ML_BAD_DATA_TYPE);
  }
}

//----------------------------------------------------------------------------------
//! Returns the input image region required to calculate a region of an output image.
//----------------------------------------------------------------------------------
SubImageBox MatlabScriptWrapper::calculateInputSubImageBox (int /*inIndex*/, const SubImageBox &outSubImgBox, int /*outIndex*/)
{
  ML_TRACE_IN("MatlabScriptWrapper::calculateInputSubImageBox ()");

  return outSubImgBox;
}

//----------------------------------------------------------------------------------
//! Type specific page calculation.
//----------------------------------------------------------------------------------
void MatlabScriptWrapper::calculateOutputSubImage (SubImage *outSubImg, int outIndex, SubImage* /*inSubImgs*/)
{
  ML_TRACE_IN("MatlabScriptWrapper::calculateOutputSubImage ()");

  // Check if Matlab is started.
  if(!_checkMatlabIsStarted()) {
    std::cerr << "calculateOutputSubImage(): Cannot find Matlab engine!" << std::endl << std::flush;
    return;
  }

  // Get Matlab image data in column-major order.
  const std::string matlabVariableName = _outImageNameFld[outIndex]->getStringValue();
  mxArray *m_pImage = engGetVariable(m_pEngine, matlabVariableName.c_str());

  if(m_pImage != NULL) {
    // Copy AB:added different types of images from Matlab.
    MLPhysicalDataType outputClass;
    switch (mxGetClassID(m_pImage)) {
      case mxDOUBLE_CLASS: outputClass = MLdoubleType; break;
      case mxSINGLE_CLASS: outputClass = MLfloatType;  break;
      case mxINT8_CLASS:   outputClass = MLint8Type;   break;
      case mxUINT8_CLASS:  outputClass = MLuint8Type;  break;
      case mxINT16_CLASS:  outputClass = MLint16Type;  break;
      case mxUINT16_CLASS: outputClass = MLuint16Type; break;
      case mxINT32_CLASS:  outputClass = MLint32Type;  break;
      case mxUINT32_CLASS: outputClass = MLuint32Type; break;
      case mxINT64_CLASS: // AB:Matlab does not support basic operations on this type
        //outputClass = MLint64Type;
        //break;
      default:
        outputClass = ML_BAD_DATA_TYPE;
        std::cerr << "calculateOutputSubImage(): Output type from Matlab not supported" << std::endl << std::flush;
    }
    SubImage subImgBuf(outSubImg->getBox(), outputClass, mxGetPr(m_pImage));
    outSubImg->copySubImage(subImgBuf);

    mxDestroyArray(m_pImage); m_pImage = NULL;
  } else {
    // Throw error if the variable could not be found in the Matlab workspace.
    // NOTE: This is also checked in calcOutSubImgProps() above, so execution should never enter here.
    std::ostringstream msg;
    msg << "Could not find the variable " << matlabVariableName << " for output number " << outIndex << " in the Matlab workspace.";
    ML_PRINT_ERROR("MatlabScriptWrapper::calculateOutputSubImage()", msg.str().c_str(), "Output will be empty");
  }
}

//////////////////////////////////////////////////////////////////////
// Internal (private) methods.
//////////////////////////////////////////////////////////////////////

//! Loads Matlab script from a file, pastes it into script field and saves user written script.
bool MatlabScriptWrapper::_loadMatlabScriptFromFile(std::string& evaluateString)
{
  // Clear input string
  evaluateString.clear();

  // Temporary string for reading input.
  std::ostringstream tmpString;

  // Update script window if new script chosen.
  std::string pathString = _matlabScriptPathFld->getStringValue();

  ML_TRY {
    if(pathString.empty()) {
      _statusFld->setStringValue("Script path is empty.");
      return false;
    } else {
      // File to open.
      std::ifstream dat;
      dat.open(pathString.c_str());
      if(dat.fail()) {
        // Throw error message if file couldn't be opened.
        _statusFld->setStringValue("Cannot find .m-file!");
        return false;
      }

      // Read script line by line from file.
      std::string line;
      while(!dat.eof()) {
        getline(dat, line);
        tmpString << line << "\n";
      }

      // Close file
      dat.close();

      // Get string
      evaluateString = tmpString.str();
    }
  }
  ML_CATCH_RETHROW;

  return true;
}

//! Check if Matlab is started.
bool MatlabScriptWrapper::_checkMatlabIsStarted()
{
  // Is there an engine at all?
  if(m_pEngine == NULL) {
    return false;
  }

  // Check that it is working properly
  // AB:changed check with useless 'clear command window'-command
  if(0 == engEvalString(m_pEngine, "clc")) {
    return true;
  } else {
    return false;
  }
}

//! Copy input image data to Matlab.
void MatlabScriptWrapper::_copyInputImageDataToMatlab()
{
  for(int i=0; i<3; i++) {
    // Get a valid input if possible. Dummy input is considered invalid.
    PagedImage *inImg = getUpdatedInputImage(i);

    if(!(inImg->isGlobalDummyImage())) {
      // If we get an invalid pointer to the image we abort.
      if(!inImg) {
        ML_PRINT_ERROR("MatlabScriptWrapper::_copyInputImageDataToMatlab()",
                       ML_BAD_INPUT_IMAGE_POINTER, "Could not find input image. Aborting.");
        return;
      }

      // Get input image size in row-major order.
      ImageVector imgSize = inImg->getImageExtent();

      // Declare data pointer here and set it to null. Data will then only
      // be allocated once for the first slice in the getTile() function below.
      void *data = NULL;

      // Get whole image.
      MLErrorCode localErr =
        getTile(inImg,
                SubImageBox(ImageVector(0, 0, 0, 0, 0, 0),
                            ImageVector(imgSize.x-1, imgSize.y-1, imgSize.z-1,imgSize.c-1, imgSize.t-1, imgSize.u-1)),
                inImg->getDataType(),
                &data,
                ScaleShiftData(1, 0));

      // Check and save error code if necessary.
      if(localErr != ML_RESULT_OK) {
        ML_PRINT_ERROR("MatlabScriptWrapper::copyInputImageDataToMatlab()",
                       localErr, "Could not get input image tile. Aborting.");
        return;
      }

      // Need also to have storage for complete output image.
      //MLuint32 inDataSize = inImg->getBoxFromImgExt().getExt().getStrides().u;
      const MLuint inDataSize = imgSize.x*imgSize.y*imgSize.z*imgSize.c*imgSize.t*imgSize.u;

      // Set Matlab image extent.
      const mwSize insizesArray[6] = {imgSize.x, imgSize.y, imgSize.z, imgSize.c, imgSize.t, imgSize.u};

      // Copy different types of images from MeVisLab.
      mxClassID inputClass;
      int elementSize;
      switch (inImg->getDataType()) {
        case MLdoubleType: inputClass = mxDOUBLE_CLASS; elementSize = sizeof(double);   break;
        case MLfloatType:  inputClass = mxSINGLE_CLASS; elementSize = sizeof(float);    break;
        case MLint8Type:   inputClass = mxINT8_CLASS;   elementSize = sizeof(int8_T);   break;
        case MLuint8Type:  inputClass = mxUINT8_CLASS;  elementSize = sizeof(uint8_T);  break;
        case MLint16Type:  inputClass = mxINT16_CLASS;  elementSize = sizeof(int16_T);  break;
        case MLuint16Type: inputClass = mxUINT16_CLASS; elementSize = sizeof(uint16_T); break;
        case MLint32Type:  inputClass = mxINT32_CLASS;  elementSize = sizeof(int32_T);  break;
        case MLuint32Type: inputClass = mxUINT32_CLASS; elementSize = sizeof(uint32_T); break;
        case MLint64Type:  inputClass = mxINT64_CLASS;  elementSize = sizeof(int64_T);  break;
        default:
          inputClass = mxDOUBLE_CLASS;
          elementSize = sizeof(double);
          std::cerr << "_copyInputImageDataToMatlab(): Output type from MeVisLab not supported" << std::endl << std::flush;
      }
      // Create numeric array
      mxArray *m_pImage = mxCreateNumericArray(6, insizesArray, inputClass, mxREAL);
      if(m_pImage == NULL) {
        std::ostringstream msg;
        msg << "Could not allocate matrix for input image " << i << " in Matlab.";
        ML_PRINT_ERROR("MatlabScriptWrapper::copyInputImageDataToMatlab()", msg.str().c_str(), "Matrix will not be created in Matlab.");
      } else {
        // Copy data to Matlab array.
        memcpy((void*)mxGetPr(m_pImage), data, inDataSize*elementSize);

        // Get input names from GUI.
        const std::string inputName = _inImageNameFld[i]->getStringValue();
        // Write data to Matlab.
        int status = engPutVariable(m_pEngine, inputName.c_str(), m_pImage);
        if(status != 0) {
          std::ostringstream msg;
          msg << "Could not put data for image " << i << " in Matlab.";
          ML_PRINT_ERROR("MatlabScriptWrapper::copyInputImageDataToMatlab()", msg.str().c_str(), "Matrix will not be created in Matlab.");
        }

        mxDestroyArray(m_pImage); m_pImage = NULL;
      }
      // Free allocated memory for holding a slice.
      freeTile(data); data = NULL;
    }
  }
}

//! Copy input CurveData or CurveList to Matlab.
void MatlabScriptWrapper::_copyInputCurveToMatlab()
{
  CurveData* inputCurveData = NULL;
  CurveList* inputCurveList = NULL;
  std::size_t numCurves = 0;

  // Get input data.
  if( ML_BASE_IS_A(_inputBaseFld->getBaseValue(), CurveList) ) {
    inputCurveList = mlbase_cast<CurveList*>(_inputBaseFld->getBaseValue());
    numCurves = inputCurveList->getNumCurves();
    if(numCurves) {
      inputCurveData = inputCurveList->getCurveData(0);
    }
  } else {
    inputCurveData = mlbase_cast<CurveData*>(_inputBaseFld->getBaseValue());
    numCurves = 1;
  }

  mxArray *cellArray = mxCreateCellMatrix(1,numCurves);
  mxArray *matArray;
  for(size_t i=0; i<numCurves; i++) {
    const std::size_t numPoints = inputCurveData->getPoints();
    const std::size_t numSeries = inputCurveData->getNumSeries();
    const mwSize dims[2] = {numPoints,numSeries+1};

    // Create matrix with series and points for each curve-data in a cell
    matArray = mxCreateNumericArray(2, dims, mxDOUBLE_CLASS, mxREAL);
    // If both arrays are created
    if(cellArray && matArray){
      double *arrayPtr = (double *)mxGetData(matArray);
      for(std::size_t k=0; k<numPoints; ++k) {
        // The X - values
        arrayPtr[k] = inputCurveData->getXValue(k);
      }
      for(std::size_t j=0; j<numSeries; ++j) {
        for(std::size_t k=0; k<numPoints; ++k) {
          // The Y - values for each series
          arrayPtr[k+numPoints*(j+1)] = inputCurveData->getYValue(j,k);
        }
      }
      // Put array in a cell
      mxSetCell(cellArray, i, mxDuplicateArray(matArray));
      if(inputCurveList) {
        inputCurveData = inputCurveList->getCurveData(i+1);
      }
    }
    mxDestroyArray(matArray); matArray = NULL;
  }

  // Write CurveData or CurveList into Matlab cell array with input name from GUI.
  engPutVariable(m_pEngine, _inBaseNameFld->getStringValue().c_str(), cellArray);

  mxDestroyArray(cellArray); cellArray = NULL;
}

//! Gets structure from Matlab and copies results into output CurveData.
void MatlabScriptWrapper::_getCurveDataBackFromMatlab()
{
  // Clear _outputCurveData and preserve curve properties.
  _outputCurveList.clear();

  // Get name from GUI.
  std::string outCurveStr = _outBaseNameFld->getStringValue();
  // Internal temp variable with the number of Curves in Matlab.
  mxArray *m_curveList = engGetVariable(m_pEngine, outCurveStr.c_str());

  if((m_curveList!=NULL && mxGetClassID(m_curveList)==mxCELL_CLASS)) {
    CurveData* curve = NULL;
    const size_t curves = mxGetN(m_curveList);  // Number of matrices in Matlab cell
    for(size_t i=0; i<curves; i++) {
      ML_CHECK_NEW(curve,CurveData);

      mxArray *m_curve = mxGetCell(m_curveList,i);
      if((m_curve && !mxIsEmpty(m_curve) && mxGetClassID(m_curve)==mxDOUBLE_CLASS)) {
        const size_t points = mxGetM(m_curve);  // Number of rows in Matlab matrix
        const size_t series = mxGetN(m_curve);  // Number of columns in Matlab matrix
        curve->resizeX(points);                 // Initialize the X - values with zeros
        // Initialize the remaining columns with zeros as series of Y - values
        for(size_t serie=0; serie<series-1; serie++) {
          curve->resizeY(serie,points);
        }
        double *dataPoints = static_cast<double*>(mxGetPr(m_curve));
        // For each point.
        for(size_t point=0; point<points; point++) {
          // Set the X - values
          curve->setXValue(dataPoints[point], point);
        }
        // For each serie
        for(size_t serie=0; serie<series-1; serie++) {
          for(size_t point=0; point<points; point++) {
            // Set the Y - values
            curve->setYValue(dataPoints[point+points*(serie+1)], serie, point);
          }
        }
      }
      // Append CurveData to CurvList.
      _outputCurveList.getCurveList().push_back(curve);
    }
  }
  mxDestroyArray(m_curveList); m_curveList = NULL;
}

//! Copy input XMarkerList to Matlab.
void MatlabScriptWrapper::_copyInputXMarkerToMatlab()
{
  // Get input list.
  XMarkerList inputXMarkerList = *((XMarkerList*)_inputBaseFld->getBaseValue());

  // Get input list name from GUI.
  std::string inXMarkerStr = _inBaseNameFld->getStringValue();
  // Strings to evaluate.
  std::ostringstream setPos, setVec, setType, setName;
  setPos <<inXMarkerStr.c_str()<< ".pos=[";
  setVec <<inXMarkerStr.c_str()<< ".vec=[";
  setType<<inXMarkerStr.c_str()<<".type=[";
  setName<<inXMarkerStr.c_str()<<".name={";

  // Get XMarkerList size and go through all list step by step.
  const size_t listSize = inputXMarkerList.size();
  for(size_t i = 0; i < listSize; i++) {
    XMarker marker = inputXMarkerList[i];

    // Write pos, vec and type to strings.
    setPos <<std::dec<<marker.x() <<","<<std::dec<<marker.y() <<","<< std::dec<<marker.z() <<","
           <<std::dec<<marker.c() <<","<<std::dec<<marker.t() <<","<< std::dec<<marker.u() <<";";
    setVec <<std::dec<<marker.vx()<<","<<std::dec<<marker.vy()<<","<< std::dec<<marker.vz()<<";";
    setType<<std::dec<<marker.type<<";";
    setName<< "'" << (marker.name() ? marker.name() : "") << "';";
  }
  setPos <<"]";
  setVec <<"]";
  setType<<"]";
  setName<<"}";

  // Put XMarkerList into Matlab structure.
  std::ostringstream all;
  all << setPos.str() << "\n" << setVec.str() << "\n" << setType.str() << "\n" << setName.str() << "\n";
  mxArray *m_X = mxCreateString(all.str().c_str());
  if(m_X) {
    if(engPutVariable(m_pEngine, "copyInputXMarkerToMatlab", m_X) == 0) {
      engEvalString(m_pEngine, "eval(copyInputXMarkerToMatlab); clear copyInputXMarkerToMatlab;");
    }
  }
  mxDestroyArray(m_X); m_X = NULL;
}

//! Gets structure from Matlab and copies results into output XMarkerList.
void MatlabScriptWrapper::_getXMarkerBackFromMatlab()
{
  // Clear _outputXMarkerList.
  _outputXMarkerList.clearList();

  // Get names from GUI.
  std::string outXMarkerStr = _outBaseNameFld->getStringValue();
  // Compose temp string to execute in Matlab.
  std::ostringstream executeStr;
  // Internal temp variable will be used in Matlab.
  executeStr << "tmpOutXMarkerListPos=" << outXMarkerStr << ".pos";
  engEvalString(m_pEngine, executeStr.str().c_str());
  // Get array from Matlab.
  mxArray *m_pos = engGetVariable(m_pEngine, "tmpOutXMarkerListPos");
  // Delete temp data.
  engEvalString(m_pEngine, "clear tmpOutXMarkerListPos");
  // Clear temp string.
  executeStr.str("");

  executeStr << "tmpOutXMarkerListVec=" << outXMarkerStr << ".vec";
  engEvalString(m_pEngine, executeStr.str().c_str());
  mxArray *m_vec = engGetVariable(m_pEngine, "tmpOutXMarkerListVec");
  engEvalString(m_pEngine, "clear tmpOutXMarkerListVec");
  executeStr.str("");

  executeStr << "tmpOutXMarkerListType=" << outXMarkerStr << ".type";
  engEvalString(m_pEngine, executeStr.str().c_str());
  mxArray *m_type = engGetVariable(m_pEngine, "tmpOutXMarkerListType");
  engEvalString(m_pEngine, "clear tmpOutXMarkerListType");
  executeStr.str("");

  executeStr << "tmpOutXMarkerListName=" << outXMarkerStr << ".name";
  engEvalString(m_pEngine, executeStr.str().c_str());
  mxArray *m_names = engGetVariable(m_pEngine, "tmpOutXMarkerListName");
  engEvalString(m_pEngine, "clear tmpOutXMarkerListName");

  // Get data from Matlab array.
  if((m_pos  && !mxIsEmpty(m_pos) && mxGetClassID(m_pos) ==mxDOUBLE_CLASS) &&
     (m_vec  && !mxIsEmpty(m_vec) && mxGetClassID(m_vec) ==mxDOUBLE_CLASS) &&
     (m_type && !mxIsEmpty(m_type)&& mxGetClassID(m_type)==mxDOUBLE_CLASS)) {
    double *dataPos  = static_cast<double*>(mxGetPr(m_pos));
    double *dataVec  = static_cast<double*>(mxGetPr(m_vec));
    double *dataType = static_cast<double*>(mxGetPr(m_type));

    // Copy Matlab data to XMarker if it's not empty.
    if(dataPos!=NULL) {
      // Get rows numbers.
      const size_t rows = mxGetM(m_pos);    // Number of markers
      const size_t cols = mxGetN(m_pos);    // Number of dimensions (max 6)

      for(size_t i=0; i<rows; i++) {
        // Fill marker with zeros.
        XMarker outMarker(Vector3(0));

        // Write Matlab points to marker and prevent writing more than 6 dimensions.
        for(size_t j=0; j<cols && cols<=6; j++) {
          outMarker.pos[j] = dataPos[i + j*rows];
        }

        // Write Matlab vector to marker only if number of vectors are equal to points.
        if(dataVec!=NULL && rows==mxGetM(m_vec)) {
          // Prevent writing more than 3 dimensions.
          for(size_t j=0; j<mxGetN(m_vec) && mxGetN(m_vec)<=3; j++) {
            outMarker.vec[j] = dataVec[i + j*rows];
          }
        }

        // Write Matlab type vec to marker only if number of vectors are equal to points.
        if(dataType!=NULL && rows==mxGetM(m_type)) {
          outMarker.type = static_cast<MLint>(dataType[i]);
        }

        // Write Matlab name to marker.
        if(m_names && !mxIsEmpty(m_names) && mxGetClassID(m_names)==mxCELL_CLASS) {
          // Set name only if number of name are equal to points.
          if(rows==mxGetM(m_names)) {
            mxArray *m_name = mxGetCell(m_names,i);
            if(m_name && !mxIsEmpty(m_name) && mxGetClassID(m_name)==mxCHAR_CLASS) {
              int tempsize = 0;
              char *dataName = NULL;
              tempsize = mxGetN(m_name)+1;
              ML_CHECK_NEW(dataName,char[tempsize]);
              mxGetString(m_name,dataName,tempsize);
              outMarker.setName(dataName);
            }
          }
        }
        
        // Append XMarker to XMarkerList with new Id.
        outMarker.setId(_outputXMarkerList.newId());
        _outputXMarkerList.push_back(outMarker);
      }

      // Destroy arrays.
      mxDestroyArray(m_pos);   m_pos = NULL;
      mxDestroyArray(m_vec);   m_vec = NULL;
      mxDestroyArray(m_type);  m_type = NULL;
      mxDestroyArray(m_names); m_names = NULL;
    }
  }
}

//! Copy input Mat4List to Matlab.
void MatlabScriptWrapper::_copyInputMat4ListToMatlab()
{
  // Set dimensions for a 4x4 matrix
  double matrix[16];
  const mwSize dims[2] = {4,4};
  const size_t matSize = 16*sizeof(double);

  // Get input list.
  Mat4List* inputMat4List = mlbase_cast<Mat4List*>(_inputBaseFld->getBaseValue());
  const unsigned int listSize = inputMat4List->getSize();

  // Create list of cells for each array
  mxArray *cellArray = mxCreateCellMatrix(1,listSize);
  mxArray *matArray;
  for(unsigned int matIdx=0; matIdx<listSize; ++matIdx) {
    // Create double matrix for each cell
    matArray = mxCreateNumericArray(2, dims, mxDOUBLE_CLASS, mxREAL);
    // If both arrays are created
    if(cellArray && matArray){
      // Put Mat4 values in array
      inputMat4List->at(matIdx).getValues(matrix);
      // Copy data to Matlab array.
      memcpy((void*)mxGetPr(matArray), matrix, matSize);
      // Put array in a cell
      mxSetCell(cellArray, matIdx, mxDuplicateArray(matArray));
    }
    mxDestroyArray(matArray); matArray = NULL;
  }

  // Write Mat4List into Matlab cell array with input list name from GUI.
  engPutVariable(m_pEngine, _inBaseNameFld->getStringValue().c_str(), cellArray);

  mxDestroyArray(cellArray); cellArray = NULL;
}

//! Copy input CSOList to Matlab.
void MatlabScriptWrapper::_copyInputCSOListToMatlab()
{
  // Get input list.
  CSOList* inputCSOList = mlbase_cast<CSOList*>(_inputBaseFld->getBaseValue());
  unsigned int numCSOs = inputCSOList->numCSO();

  // Create list of cells for each array
  mxArray *cellArray = mxCreateCellMatrix(1,numCSOs);
  mxArray *matArray;
  for(unsigned int csoIdx=0; csoIdx<numCSOs; ++csoIdx) {
    CSO* contour = inputCSOList->getCSOAt(csoIdx);
    const unsigned int numPoints = contour->numSeedPoints();
    const mwSize dims[2] = {3,numPoints};

    // Create double 3xnumberOfPointsInContour matrix for each cell
    matArray = mxCreateNumericArray(2, dims, mxDOUBLE_CLASS, mxREAL);
    if(cellArray && matArray) {
      double *arrayPtr = (double *)mxGetData(matArray);
      for(unsigned int pointIdx=0; pointIdx<numPoints; ++pointIdx) {
        const Vector3& position = contour->getSeedPointAt(pointIdx)->worldPosition;
        arrayPtr[3*pointIdx]   = position[0];
        arrayPtr[3*pointIdx+1] = position[1];
        arrayPtr[3*pointIdx+2] = position[2];
      }
    }
    // Put array in a cell
    mxSetCell(cellArray, csoIdx, mxDuplicateArray(matArray));
    mxDestroyArray(matArray); matArray = NULL;
  }

  // Write CSOList into Matlab cell array with input list name from GUI.
  engPutVariable(m_pEngine, _inBaseNameFld->getStringValue().c_str(), cellArray);

  mxDestroyArray(cellArray); cellArray = NULL;
}

//! Copy input WEM to Matlab.
void MatlabScriptWrapper::_copyInputWEMToMatlab()
{
  // Get input WEM.
  WEM *inputWEM = mlbase_cast<WEM*>(_inputBaseFld->getBaseValue());
  
  if(inputWEM->getNumWEMPatches() > 0) {
    unsigned int i = 0, j = 0, k = 0, totalNumNodes = 0;

    for(i=0; i<inputWEM->getNumWEMPatches(); i++) {
      totalNumNodes += inputWEM->getWEMPatchAt(i)->getNumNodes();
    }

    if(totalNumNodes > 0) {
      std::string patchName = _inBaseNameFld->getStringValue();
      std::ostringstream executeStr;

      // Clear previous cell of patches
      executeStr << "clear " << patchName << ";";
      engEvalString(m_pEngine, executeStr.str().c_str());
      // Clear temp string.
      executeStr.str("");

      WEMPatch *patch = NULL;
      WEMNode *node = NULL;
      WEMFace *face = NULL;
      mxArray *vertexArray, *faceArray, *cdataVector;

      // Loop over all patches
      for(i=0; i<inputWEM->getNumWEMPatches(); i++) {
        std::ostringstream createVertices, createFaces, createCData;

        patch = inputWEM->getWEMPatchAt(i);
        // Get number of nodes(/vertices) and faces.
        const unsigned int numNodes     = patch->getNumNodes();
        const unsigned int numFaces     = patch->getNumFaces();
        const unsigned int numFaceNodes = patch->getFaceAt(0)->getNumNodes();

        const mwSize vertexDims[2] = {3           ,numNodes};
        const mwSize   faceDims[2] = {numFaceNodes,numFaces};

        vertexArray = mxCreateNumericArray(2, vertexDims, mxDOUBLE_CLASS, mxREAL);
        faceArray =   mxCreateNumericArray(2,   faceDims, mxDOUBLE_CLASS, mxREAL);
        if(vertexArray && faceArray) {
          double *vertexArrayPtr = (double *)mxGetData(vertexArray);

          // Loop over all nodes
          for(j=0; j<numNodes; j++) {
            // Get node from WEM and get its coordinates.
            node = patch->getNodeAt(j);
            if(node != NULL) {
              const Vector3 &nodePos = node->getPosition();
#if ML_MAJOR_VERSION >= 2
              vertexArrayPtr[3*j]   = nodePos._buffer[0];
              vertexArrayPtr[3*j+1] = nodePos._buffer[1];
              vertexArrayPtr[3*j+2] = nodePos._buffer[2];
#else
              vertexArrayPtr[3*j]   = nodePos.X();
              vertexArrayPtr[3*j+1] = nodePos.Y();
              vertexArrayPtr[3*j+2] = nodePos.Z();
#endif
            }
          }
          createVertices  << patchName << "vertices";
          engPutVariable(m_pEngine, createVertices.str().c_str(), vertexArray);
          
          double *faceArrayPtr = (double *)mxGetData(faceArray);

          // Loop over all faces
          for(j=0; j<numFaces; j++) {
            face = patch->getFaceAt(j);
            if( (face!=NULL) && (face->getNumNodes()>2) ) {
              for(k=0; k<face->getNumNodes(); k++) {
                // Get node from face and get its coordinates.
                node = face->getNodeAt(k);
                if(node != NULL) {
                  faceArrayPtr[numFaceNodes*j+k] = face->getNodeAt(k)->getEntryNumber();
                }
              }
            }
          }
          createFaces << patchName << "faces";
          engPutVariable(m_pEngine, createFaces.str().c_str(), faceArray);
        }
        mxDestroyArray(vertexArray); vertexArray = NULL;
        mxDestroyArray(faceArray);     faceArray = NULL;

        createCData << patchName << "cdata";

        // Get LUT primitive value list
        WEMPrimitiveValueList *lut = NULL;
        lut = patch->getPrimitiveValueList("LUT");
        if(lut->isValid()) {
          const unsigned int numLUT = lut->getNumValues();
          // Maybe add lut->getDataType();
          cdataVector = mxCreateNumericMatrix(numLUT, 1, mxDOUBLE_CLASS, mxREAL);
          double *cdataVectorPtr = (double *)mxGetData(cdataVector);

          // Loop over all LUT data
          for(j=0; j<numLUT; j++) {
            cdataVectorPtr[j] = lut->getValue(j);
          }
          engPutVariable(m_pEngine, createCData.str().c_str(), cdataVector);
          mxDestroyArray(cdataVector); cdataVector = NULL;
        } else {
          createCData.str("[]");
        }

        std::ostringstream faceColor;
        if(patch->getDrawFaces()) {
          const Vector3& faceDiffuseColor = patch->getFaceDiffuseColor();
          faceColor << "["<<faceDiffuseColor[0]<<" "<<faceDiffuseColor[1]<<" "<<faceDiffuseColor[2]<<"]";
        } else {
          faceColor << "'none'";
        }
        const Vector3& vertexColor = patch->getNodeColor();
        const Vector3& edgeColor   = patch->getEdgeColor();

        // Face numbering starts with '1' in Matlab instead of '0' in MeVisLab
        // Each handle to a patch is stored in the vector with the Input Base name
        executeStr <<patchName<<"{"<<i+1<<"}.Faces = " << createFaces.str() << "'+1; "
                   <<patchName<<"{"<<i+1<<"}.Vertices = " << createVertices.str() << "'; "
                   <<patchName<<"{"<<i+1<<"}.FaceVertexCData = " << createCData.str() << "; "
                   <<patchName<<"{"<<i+1<<"}.FaceColor = " << faceColor.str() << "; "
                   <<patchName<<"{"<<i+1<<"}.MarkerEdgeColor = ["<<vertexColor[0]<<" "<<vertexColor[1]<<" "<<vertexColor[2]<<"]; "
                   <<patchName<<"{"<<i+1<<"}.EdgeColor = ["<<edgeColor[0]<<" "<<edgeColor[1]<<" "<<edgeColor[2]<<"]; "
                   <<patchName<<"{"<<i+1<<"}.FaceAlpha = " << patch->getFaceAlphaValue() << "; "
                   <<patchName<<"{"<<i+1<<"}.MarkerSize = " << patch->getPointSize() << "; "
                   <<patchName<<"{"<<i+1<<"}.Marker = " << (patch->getDrawNodes() ? "'o'" : "'none'") << "; "
                   <<patchName<<"{"<<i+1<<"}.LineStyle = " << (patch->getDrawEdges() ? "'-'" : "'none'") << "; "
                   <<patchName<<"{"<<i+1<<"}.LineWidth = " << patch->getLineWidth() << "; "
                   <<patchName<<"{"<<i+1<<"}.DisplayName = '" << patch->getLabel() << "'; "
                   <<patchName<<"{"<<i+1<<"}.Tag = '" << patch->getDescription() << "'; "
                   << "clear " << createFaces.str() << " " << createVertices.str() << " " << createCData.str() << ";";

        engEvalString(m_pEngine, executeStr.str().c_str());
      } // for all patches
    }
  }
}

//! Gets structure from Matlab and copies results into output WEM.
void MatlabScriptWrapper::_getWEMBackFromMatlab()
{
  // Clear _outWEM.
  _outWEM->removeAll();

  // Get names from GUI.
  std::string outWEMStr = _outBaseNameFld->getStringValue();
  // Internal temp variable with the number of patches in Matlab.
  mxArray *m_patchList = engGetVariable(m_pEngine, outWEMStr.c_str());
  if(m_patchList!=NULL) {
    const size_t patches = mxGetN(m_patchList); // Number of patches in Matlab variable
    for(size_t i=1; i<=patches; i++) {
      // Compose temp string to execute in Matlab.
      std::ostringstream executeStr;

      // Internal temp variable with vertices will be used in Matlab.
      executeStr << "tmpOutWEMVertices = " << outWEMStr << "{" << i << "}.Vertices';";
      engEvalString(m_pEngine, executeStr.str().c_str());
      // Get array from Matlab.
      mxArray *m_vertices = engGetVariable(m_pEngine, "tmpOutWEMVertices");
      // Delete temp data.
      engEvalString(m_pEngine, "clear tmpOutWEMVertices");
      // Clear temp string.
      executeStr.str("");

      // Internal temp variable with faces will be used in Matlab.
      executeStr << "tmpOutWEMFaces = " << outWEMStr << "{" << i << "}.Faces';";
      engEvalString(m_pEngine, executeStr.str().c_str());
      // Get faces from Matlab.
      mxArray *m_faces = engGetVariable(m_pEngine, "tmpOutWEMFaces");
      // Delete temp data.
      engEvalString(m_pEngine, "clear tmpOutWEMFaces");
      // Clear temp string.
      executeStr.str("");

      size_t rows = 0;                            // Set default to use PolygonPatch type
      WEMPatch* wemPatch = NULL;
      if((m_vertices && !mxIsEmpty(m_vertices) && mxGetClassID(m_vertices)==mxDOUBLE_CLASS) &&
         (m_faces    && !mxIsEmpty(m_faces)    && mxGetClassID(m_faces)==mxDOUBLE_CLASS)) {
        WEMNode *node = NULL;
        double *vertices = static_cast<double*>(mxGetPr(m_vertices));
        double *faces = static_cast<double*>(mxGetPr(m_faces));
        if(faces!=NULL) {
          rows = mxGetM(m_faces);                 // Number of vertices per face
        }
        if(vertices!=NULL) {
          const size_t cols = mxGetN(m_vertices); // Number of unique vertices
          switch(rows) {
            case 3:  ML_CHECK_NEW(wemPatch, WEMTrianglePatch); break;
            case 4:  ML_CHECK_NEW(wemPatch, WEMQuadPatch); break;
            default: ML_CHECK_NEW(wemPatch, WEMPolygonPatch);
          }
          for(size_t j=0; j<cols; j++) {
            node = wemPatch->addNode();
            if(node!=NULL) {
              if(mxGetM(m_vertices)==3) {         // 3D point
                node->setPosition(static_cast<double>(vertices[0 + j*3]),
                                  static_cast<double>(vertices[1 + j*3]),
                                  static_cast<double>(vertices[2 + j*3]));
              } else {                            // 2D point
                node->setPosition(static_cast<double>(vertices[0 + j*2]),
                                  static_cast<double>(vertices[1 + j*2]),
                                  0);
              }
            }
          }
        }
        if(rows>2) {                              // Can a face be created?
          WEMFace *newFace = NULL;
          const size_t cols = mxGetN(m_faces);    // Number of faces
          for(int h=0; h<cols; h++) {
            // Nodes already exists, get if from WEM node array.
            // And add the node to the face and vice versa.
            newFace = wemPatch->addFace();
            if(newFace!=NULL) {
              for(int j=0; j<rows; j++) {
                node = wemPatch->getNodeAt(static_cast<unsigned int>(faces[j + h*rows]-1));
                if(rows==3 || rows==4) {
                  newFace->setNode(j,node);
                } else {                          // Use addNode to increase the number of nodes in a Polygon
                  static_cast<WEMPolygon*>(newFace)->addNode(node);
                }
                node->addFace(newFace);
              }
            }
          }
        }
      }
      mxDestroyArray(m_vertices); m_vertices = NULL;
      mxDestroyArray(m_faces);    m_faces = NULL;

      if(wemPatch!=NULL) {
        // Add the patch with default attributes in order to set the attributes from Matlab
        _outWEM->addWEMPatch(wemPatch);

        // Temp variable with standard patch properties will be used in Matlab.
        executeStr << "tmpOutWEMproperties = " << outWEMStr << "{" << i << "};";
        engEvalString(m_pEngine, executeStr.str().c_str());
        // Get (cell)array from Matlab.
        mxArray *m_properties = engGetVariable(m_pEngine, "tmpOutWEMproperties");
        // Delete temp data.
        engEvalString(m_pEngine, "clear tmpOutWEMproperties");
        // Clear temp string.
        executeStr.str("");

        mxArray *m_property;
        int tempsize = 0;
        char *fieldVal = NULL;

        if(m_properties && !mxIsEmpty(m_properties) && mxIsStruct(m_properties)) {
          m_property = mxGetField(m_properties,0,"FaceColor");
          if(m_property!=NULL) {
            if(mxGetClassID(m_property)==mxDOUBLE_CLASS && mxGetN(m_property)==3) {
              double *color = static_cast<double*>(mxGetPr(m_property));
              if(mxGetN(m_property)==3) {
                wemPatch->setFaceDiffuseColor(Vector3(color[0],color[1],color[2]));
              }
            } else if(mxGetClassID(m_property)==mxCHAR_CLASS) {
              tempsize = mxGetN(m_property)+1;
              ML_CHECK_NEW(fieldVal,char[tempsize]);
              mxGetString(m_property,fieldVal,tempsize);
              wemPatch->setDrawFaces(strcmp(fieldVal,"none")!=0);
            }
          }
          m_property = mxGetField(m_properties,0,"MarkerEdgeColor");
          if(m_property!=NULL && mxGetClassID(m_property)==mxDOUBLE_CLASS && mxGetN(m_property)==3) {
            double *color = static_cast<double*>(mxGetPr(m_property));
            if(mxGetN(m_property)==3) {
              wemPatch->setNodeColor(Vector3(color[0],color[1],color[2]));
            }
          }
          m_property = mxGetField(m_properties,0,"EdgeColor");
          if(m_property!=NULL && mxGetClassID(m_property)==mxDOUBLE_CLASS && mxGetN(m_property)==3) {
            double *color = static_cast<double*>(mxGetPr(m_property));
            if(mxGetN(m_property)==3) {
              wemPatch->setEdgeColor(Vector3(color[0],color[1],color[2]));
            }
          }
          m_property = mxGetField(m_properties,0,"FaceAlpha");
          if(m_property!=NULL && mxGetClassID(m_property)==mxDOUBLE_CLASS && mxGetN(m_property)==1) {
            double *alpha = static_cast<double*>(mxGetPr(m_property));
            if(mxGetN(m_property)==1) {
              wemPatch->setFaceAlphaValue(alpha[0]);
            }
          }
          m_property = mxGetField(m_properties,0,"MarkerSize");
          if(m_property!=NULL && mxGetClassID(m_property)==mxDOUBLE_CLASS && mxGetN(m_property)==1) {
            double *size = static_cast<double*>(mxGetPr(m_property));
            if(mxGetN(m_property)==1) {
              wemPatch->setPointSize(size[0]);
            }
          }
          m_property = mxGetField(m_properties,0,"LineWidth");
          if(m_property!=NULL && mxGetClassID(m_property)==mxDOUBLE_CLASS && mxGetN(m_property)==1) {
            double *width = static_cast<double*>(mxGetPr(m_property));
            if(mxGetN(m_property)==1) {
              wemPatch->setLineWidth(width[0]);
            }
          }
          m_property = mxGetField(m_properties,0,"LineStyle");
          if(m_property!=NULL && mxGetClassID(m_property)==mxCHAR_CLASS) {
            tempsize = mxGetN(m_property)+1;
            ML_CHECK_NEW(fieldVal,char[tempsize]);
            mxGetString(m_property,fieldVal,tempsize);
            wemPatch->setDrawEdges(strcmp(fieldVal,"none")!=0);
          }
          m_property = mxGetField(m_properties,0,"Marker");
          if(m_property!=NULL && mxGetClassID(m_property)==mxCHAR_CLASS) {
            tempsize = mxGetN(m_property)+1;
            ML_CHECK_NEW(fieldVal,char[tempsize]);
            mxGetString(m_property,fieldVal,tempsize);
            wemPatch->setDrawNodes(strcmp(fieldVal,"none")!=0);
          }
          m_property = mxGetField(m_properties,0,"DisplayName");
          if(m_property!=NULL && mxGetClassID(m_property)==mxCHAR_CLASS) {
            tempsize = mxGetN(m_property)+1;
            ML_CHECK_NEW(fieldVal,char[tempsize]);
            mxGetString(m_property,fieldVal,tempsize);
            wemPatch->setLabel(fieldVal);
            ML_DELETE(fieldVal);
          }
          m_property = mxGetField(m_properties,0,"Tag");
          if(m_property!=NULL && mxGetClassID(m_property)==mxCHAR_CLASS) {
            tempsize = mxGetN(m_property)+1;
            ML_CHECK_NEW(fieldVal,char[tempsize]);
            mxGetString(m_property,fieldVal,tempsize);
            wemPatch->setDescription(fieldVal);
            ML_DELETE(fieldVal);
          }
        }
        mxDestroyArray(m_properties); m_properties = NULL;

        //if (_generateEdgesFld->getBoolValue()) {
        wemPatch->buildEdgeConnectivity();
        //}
        // Calculate normals.
        wemPatch->computeNormals();
      }
    }
  }
  mxDestroyArray(m_patchList); m_patchList = NULL;
}

//! Copies scalar values to Matlab.
void MatlabScriptWrapper::_copyInputScalarsToMatlab()
{
  // Compose string that contains input scalars.
  std::ostringstream execute;
  // Put only input scalars into Matlab.
  for(MLint i=0; i<_numOfScalars->getIntValue(); i++) {
    execute<<_scalarNameFld[i]->getStringValue()<<"="<<(_scalarFld[i]->getDoubleValue())<<"\n";
  }
  // Execute string and write input scalars into Matlab.
  engEvalString(m_pEngine, execute.str().c_str());
}

//! Copies scalar values from Matlab.
void MatlabScriptWrapper::_getScalarsBackFromMatlab()
{
  mxArray *temp = NULL;
  // Get only output scalars.
  for(MLint i=0; i<6; i++) {
    temp = engGetVariable(m_pEngine, (_scalarNameFld[i]->getStringValue()).c_str());
    if(temp!=NULL) {
      if(mxGetClassID(temp)==mxDOUBLE_CLASS) {
        double *fieldVal = static_cast<double*>(mxGetPr(temp));
        _scalarFld[i]->setDoubleValue(fieldVal[0]);
      } else {
        std::cerr << "_getVectorsBackFromMatlab(): Output type from Matlab not supported" << std::endl << std::flush;
      }
    }
  }
  mxDestroyArray(temp); temp = NULL;
}

//! Copies string values to Matlab.
void MatlabScriptWrapper::_copyInputStringsToMatlab()
{
  // Compose string that contains input scalars.
  std::ostringstream execute;
  // Put only input scalars into Matlab.
  for(MLint i=0; i<_numOfStrings->getIntValue(); i++) {
    execute<<_stringNameFld[i]->getStringValue()<<"='"<<(_stringFld[i]->getStringValue())<<"'\n";
  }
  // Execute string and write input scalars into Matlab.
  engEvalString(m_pEngine, execute.str().c_str());
}

//! Copies string values from Matlab.
void MatlabScriptWrapper::_getStringsBackFromMatlab()
{
  // Internal loop.
  mxArray *temp = NULL;
  int tempsize = 0;
  char *fieldVal = NULL;
  // Get only output scalars.
  for(MLint i=0; i<6; i++) {
    temp = engGetVariable(m_pEngine, (_stringNameFld[i]->getStringValue()).c_str());
    if(temp!=NULL) {
      tempsize = mxGetN(temp)+1;
      ML_CHECK_NEW(fieldVal,char[tempsize]);
      mxGetString(temp,fieldVal,tempsize);
      _stringFld[i]->setStringValue(fieldVal);
      ML_DELETE(fieldVal);
    }
  }
  mxDestroyArray(temp); temp = NULL;
}

//! Copy input vectors to Matlab.
void MatlabScriptWrapper::_copyInputVectorsToMatlab()
{
  // Compose string that contains input vectors.
  std::ostringstream execute;
  // Put only input vectors into Matlab.
  for(MLint i=0; i<_numOfVectors->getIntValue(); i++) {
    execute<<_vectorNameFld[i]->getStringValue()<<"=[";

    Vector4 vec = _vectorFld[i]->getVector4Value();
    execute<<vec[0]<<","<<vec[1]<<","<<vec[2]<<","<<vec[3];
    execute<<"];";
  }
  // Execute string and write input vectors into Matlab.
  engEvalString(m_pEngine, execute.str().c_str());
}

//! Copies vector values from Matlab.
void MatlabScriptWrapper::_getVectorsBackFromMatlab()
{
  // Internal loop.
  mxArray *temp = NULL;
  // Get only output vectors.
  for(MLint i=0; i<6; i++) {
    temp = engGetVariable(m_pEngine, (_vectorNameFld[i]->getStringValue()).c_str());
    if(temp!=NULL) {
      if(mxGetClassID(temp)==mxDOUBLE_CLASS) {
        double *fieldVal = static_cast<double*>(mxGetPr(temp));
        if(mxGetM(temp)==1 && mxGetN(temp)==4) {
          _vectorFld[i]->setVector4Value(Vector4(fieldVal[0],fieldVal[1],fieldVal[2],fieldVal[3]));
        } else {
          std::cerr << "_getVectorsBackFromMatlab(): Incorrect vector size" << std::endl << std::flush;
        }
      } else {
        std::cerr << "_getVectorsBackFromMatlab(): Output type from Matlab not supported" << std::endl << std::flush;
      }
    }
  }
  mxDestroyArray(temp); temp = NULL;
}

//! Copy input matrices to Matlab.
void MatlabScriptWrapper::_copyInputMatricesToMatlab()
{
  // Compose string that contains input matrices.
  std::ostringstream execute;
  // Put only input matrices into Matlab.
  for(MLint i=0; i<_numOfMatrices->getIntValue(); i++) {
    execute<<_matrixNameFld[i]->getStringValue()<<"=[";

    Matrix4 mat = _matrixFld[i]->getMatrixValue();
    execute<<mat[0][0]<<","<<mat[0][1]<<","<<mat[0][2]<<","<<mat[0][3]<<";";
    execute<<mat[1][0]<<","<<mat[1][1]<<","<<mat[1][2]<<","<<mat[1][3]<<";";
    execute<<mat[2][0]<<","<<mat[2][1]<<","<<mat[2][2]<<","<<mat[2][3]<<";";
    execute<<mat[3][0]<<","<<mat[3][1]<<","<<mat[3][2]<<","<<mat[3][3];
    execute<<"];";
  }
  // Execute string and write input matrices into Matlab.
  engEvalString(m_pEngine, execute.str().c_str());
}

//! Copies matrix values from Matlab.
void MatlabScriptWrapper::_getMatricesBackFromMatlab()
{
  // Internal loop.
  mxArray *temp = NULL;
  // Get only output matrices.
  for(MLint i=0; i<3; i++) {
    temp = engGetVariable(m_pEngine, (_matrixNameFld[i]->getStringValue()).c_str());
    if(temp!=NULL) {
      if(mxGetClassID(temp)==mxDOUBLE_CLASS) {
        double *fieldVal = static_cast<double*>(mxGetPr(temp));
        if(mxGetM(temp)==4 && mxGetN(temp)==4) {
          _matrixFld[i]->setMatrixValue(Matrix4(fieldVal[0],fieldVal[4], fieldVal[8],fieldVal[12],
                                                fieldVal[1],fieldVal[5], fieldVal[9],fieldVal[13],
                                                fieldVal[2],fieldVal[6],fieldVal[10],fieldVal[14],
                                                fieldVal[3],fieldVal[7],fieldVal[11],fieldVal[15]));
        } else {
          std::cerr << "_getMatricesBackFromMatlab(): Incorrect matrix size" << std::endl << std::flush;
        }
      } else {
        std::cerr << "_getMatricesBackFromMatlab(): Output type from Matlab not supported" << std::endl << std::flush;
      }
    }
  }
  mxDestroyArray(temp); temp = NULL;
}

ML_END_NAMESPACE

