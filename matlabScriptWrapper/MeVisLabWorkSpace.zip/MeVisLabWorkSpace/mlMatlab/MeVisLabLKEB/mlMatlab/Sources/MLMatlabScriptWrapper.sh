#!/bin/bash
python $MLAB_ROOT/MeVis/Foundation/BuildTools/Scripts/createProject.py MLMatlabScriptWrapper