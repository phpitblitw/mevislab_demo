Readme for MatlabScriptWrapper

The MatlabScriptWrapper.zip contains the original sources from MeVisLab in-house modules obtained at the Advanced MeVisLab Developers Workshop 2009 by Pieter Kitslaar.

Some early modifications to the original version include:
- option to show or hide Matlab engine session window
- view the output of a Matlab session in an additional tab
- create Visual Studio project files with CMake

