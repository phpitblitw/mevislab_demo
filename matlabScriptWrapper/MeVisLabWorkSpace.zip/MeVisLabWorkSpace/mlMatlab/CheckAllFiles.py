#!/usr/bin/python

import sys

# Injected reference to the GetScript directory
GETSCRIPT_DIR = "E:\\Project\\LKEB\\pyLKEB\\Tools\\GetScript\\GUI\\.."
sys.path.insert(0, GETSCRIPT_DIR)

import CheckAllFiles

if __name__ == "__main__":
    CheckAllFiles.main()
