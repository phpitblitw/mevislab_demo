"""
Sphinx documentation generation extension for handling CMAKE syntax.

author: Pieter Kitslaar
"""

from docutils import nodes
from docutils.parsers.rst import directives

import re
from sphinx import addnodes
from sphinx.roles import XRefRole
from sphinx.locale import l_, _
from sphinx.domains import Domain, ObjType, Index
from sphinx.directives import ObjectDescription
from sphinx.util.nodes import make_refnode
from sphinx.util.compat import Directive
from sphinx.util.docfields import Field, GroupedField, TypedField
from sphinx.builders.html import StandaloneHTMLBuilder

import os
import cPickle

# import the internal cmake commands for linking
import cmake_internals


identity = lambda x: x

# REs for a callable (e.g. MACRO, FUNCTION) signatures
callable_sig_re = re.compile(
    r'''([\w]+) \s*     # thing name
        (?: \((.*)\) )?    # optionally arguments
    ''', re.VERBOSE)

class CMakeObject(ObjectDescription):
    object_type_name = None
    object_dict_name = None

    def register_object(self, object_name, signode):
        if object_name not in self.state.document.ids:
            signode['first'] = not self.names
            signode['names'].append(object_name)
            signode['ids'].append(object_name)
            self.state.document.note_explicit_target(signode)

            objects_dict = self.env.domaindata['cmake'][self.object_dict_name]
            if object_name in objects_dict:
                self.env.warn(
                    self.env.docname,
                    'duplicate object description of %s, ' % object_name +
                    'other instance in ' +
                    self.env.doc2path(objects_dict[object_name][0]) +
                    ', use :noindex: for one of them',
                    self.lineno)
            objects_dict[object_name] = (self.env.docname, self.objtype)

class CMakeCallableObject(CMakeObject):
    has_content = True
    option_spec = {
        'deprecated': directives.flag
    }

    def handle_signature(self, sig, signode):
        info = callable_sig_re.split(self.arguments[0].strip())
        callablename = info[1]
        arguments = info[2]

        type_name = "%s " % self.object_type_name
        signode += addnodes.desc_type(type_name, type_name)
        signode += addnodes.desc_name(callablename, callablename)
        arguments = "(%s)" % arguments
        if 'deprecated' in self.options:
            arguments += ' DEPRECATED'
        signode += addnodes.desc_annotation(arguments, arguments)
        
        return callablename

    def add_target_and_index(self, callableinfo, sig, signode):
        callablename = callableinfo
        self.register_object(callablename, signode) 

        index_text = _('%s (%s)' % (callablename, self.object_type_name.title(), ))
        self.indexnode['entries'].append((
            'single', index_text, callablename, callablename))

class CMakeMacro(CMakeCallableObject):
    object_type_name = 'macro'
    object_dict_name = 'macros'

class CMakeFunction(CMakeCallableObject):
    object_type_name = 'function'
    object_dict_name = 'functions'

class CMakeVariable(CMakeObject):
    object_type_name = 'variable'
    object_dict_name = 'functions'

    has_content = True
    option_spec = {
        'deprecated': directives.flag
    }

    def handle_signature(self, sig, signode):
        var_name = self.arguments[0].strip()

        signode += addnodes.desc_type('variable ', 'variable ')
        signode += addnodes.desc_name(var_name, var_name)
        if 'deprecated' in self.options:
            arguments = ' DEPRECATED'
            signode += addnodes.desc_annotation(arguments, arguments)
        
        return var_name

    def add_target_and_index(self, callableinfo, sig, signode):
        var_name = callableinfo
        self.register_object(var_name, signode)

        index_text = _('%s (%s)' % (var_name, 'variable', ))
        self.indexnode['entries'].append((
            'single', index_text, var_name, var_name))



#class MLBaseModuleIndex(Index):
#    """
#    Index subclass to provide the MeVisLab module index.
#    """
#
#    name = 'mlmodindex'
#    localname = l_('MeVisLab Module Index')
#    shortname = l_('modules')
#    sortby = None 
#    
#    def generate(self, docnames=None):
#        content = {}
#        # list of prefixes to ignore
#        ignores = self.domain.env.config['modindex_common_prefix']
#        ignores = sorted(ignores, key=len, reverse=True)
#        # list of all modules, sorted by module name
#        modules = sorted(self.domain.data['modules'].iteritems(),
#                         key=lambda x: x[0].lower())
#
#        # sort out collapsable modules
#        num_toplevels = 0
#        for modname, (docname, mod_data) in modules:
#            if docnames and docname not in docnames:
#                continue
#
#            letter = modname[0].lower()
#            if self.sortby:
#                letter = mod_data[self.sortby]
#
#            if isinstance(letter, basestring):
#                letter = [letter]
#
#            for l in letter:
#                # letter should be a 'unicode' string for LaTeX writer 
#                # to work
#                entries = content.setdefault(unicode(l), [])
#                entries.append(
#                    [
#                        modname, # the name of the index entry to be displayed
#                        0, #  0 : normal entry, 1 : entry with sub-entries,  2 : sub-entry
#                        docname, # docname where the entry is located
#                        'mlmodule-' + modname,  # anchor for the entry within docname
#                        '', # extra info for the entry
#                        '', # qualifier for the description
#                        mod_data.get('comment') 
#                    ]
#                )
#
#        # apply heuristics when to collapse modindex at page load:
#        # only collapse if number of toplevel modules is larger than
#        # number of submodules
#        collapse = len(modules) - num_toplevels < num_toplevels
#
#        # sort by first letter
#        content = sorted(content.iteritems())
#
#        return content, collapse

#def newModuleIndex(_name, _localname, _shortname, _sortby):
#    class MLModuleIndex(MLBaseModuleIndex):
#        name = _name 
#        localname = l_(_localname) if _localname else None
#        shortname = l_(_shortname) if _shortname else None
#        sortby = _sortby 
#    return MLModuleIndex

class CMakeDomain(Domain):
    """CMake domain"""
    name = 'cmake'
    label = 'CMake'
    object_types = {
        'macro': ObjType(l_('macro'), 'mac', 'macro'),
        'function': ObjType(l_('function'), 'func', 'function'),
        'variable': ObjType(l_('variable'), 'var', 'variable'),
    }

    directives = {
        'macro': CMakeMacro,
        'function': CMakeFunction,
        'variable': CMakeVariable,
    }

    roles = {
        'mac' : XRefRole(),
        'func': XRefRole(),
        'var' : XRefRole(),
        'com' : XRefRole(),
    }

    initial_data = {
        'macros': {},
        'functions': {},
        'variables': {},
    }

    #indices = [
    #    newModuleIndex('modules-by-name', 'Modules by Name', None, None),
    #    newModuleIndex('modules-by-genre', 'Modules by Genre', None, 'genre'),
    #    newModuleIndex('modules-by-author', 'Modules by Author', None, 'author'),
    #    newModuleIndex('modules-by-keywords', 'Modules by Keywords', None, 'keywords'),
    #    newModuleIndex('modules-by-type', 'Modules by Type', None, 'type'),
    #    newModuleIndex('modules-by-dll', 'Modules by DLL', None, 'dll'),
    #    newModuleIndex('modules-by-file', 'Modules by File', None, 'file'),
    #    newModuleIndex('modules-by-status', 'Modules by Status', None, 'status'),
    #]

    def clear_doc(self, docname):
        for object_group in ('macros', 'functions', 'variables'):
            for object_name, (fn, _) in self.data[object_group].items():
                if fn == docname:
                    del self.data[object_group][object_name]

    def get_objects(self):
        for object_group, name_0, name_1 in (
            ('macros', 'macro', 'cmakemacro-'),
            ('functions', 'function', 'cmakefunction-'),
            ('variables', 'variable', 'cmakevariable-')
        ):
            for object_name, info in self.data[object_group].iteritems():
                yield (object_name, object_name, name_0, info[0], name_1 + object_name, 0)


    def resolve_xref(self, env, fromdocname, builder,
                     type, target, node, contnode):
        if type == 'mac':
                macroname = target
                docname = self.data['macros'][macroname][0]
                return make_refnode(builder, fromdocname, docname, macroname, contnode,
                macroname)

        if type == 'func':
                funcname = target
                docname = self.data['functions'][funcname][0]
                return make_refnode(builder, fromdocname, docname, funcname, contnode,
                funcname)

        if type == 'var':
                var_name = target
                docname = self.data['variables'][var_name][0]
                return make_refnode(builder, fromdocname, docname, var_name, contnode,
                var_name)

        if type == 'com':
                command_name = target.lower()
                if command_name in cmake_internals.cmake_commands: 
                    print command_name 
                    node = nodes.reference('', '', internal=False)
                    node['refuri'] = 'http://www.cmake.org/cmake/help/cmake-2-8-docs.html#command:%s' % command_name
                    node['reftitle'] = command_name
                    node.append(contnode)
                    return node
        return None
            
def setup(app):
  """ Define all the options of this extension. """
  app.add_domain(CMakeDomain)


if __name__ == "__main__":

    test1 = "LkebUnzip(filename blah doei)"
    print macro_sig_re.split(test1.strip())

    test1 = "LkebUnzip()"
    print macro_sig_re.split(test1.strip())
