.. Understanding SBR and CMake documentation master file, created by
   sphinx-quickstart on Tue Jul 06 14:26:07 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: links.txt

Understanding CMake
===================

This documentation is explains the way CMake_ is used to build projects at the LKEB.  
It covers some basic CMake principles and some of the extension (macros, function and modules)
created and used at the LKEB.

CMake
-----

CMake_ is an open source cross platform build system created by KitWare_ 

.. _KitWare: http://www.kitware.com



Contents:

.. toctree::
   :maxdepth: 3

   introduction
   general
   thirdparty

    
.. Indices and tables
.. ==================
.. 
.. * :ref:`genindex`
.. * :ref:`search`
.. 
