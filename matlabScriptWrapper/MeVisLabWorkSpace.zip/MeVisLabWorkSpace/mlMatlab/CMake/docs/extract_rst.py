import os
import sys

ignore_dirs = '.svn', 'docs'
valid_extensions = '.txt', '.cmake'
comment_prefix = '#:'
len_comment_prefix = len(comment_prefix)

def get_all_files():
    """Returns all files used to extract the RST content."""
    for root, dirs, files in os.walk('..'):
        for ignore_dir in ignore_dirs:
            if ignore_dir in dirs:
                dirs.remove(ignore_dir)
        for f in files:
            if f.endswith(valid_extensions):
                yield os.path.join(root, f)

def consecutive_lines(line_list):
    """Returns batches of consecutive lines from the line_list argument."""
    current_lines = []
    for l in line_list:
        if not current_lines or l[0] - current_lines[-1][0] == 1:
            current_lines.append(l)
        else:
            yield current_lines[:]
            current_lines = [l]
    if current_lines:
        yield current_lines
        

if __name__ == "__main__":
    file_comments = {}
    for file_name in get_all_files():
        with open(file_name, 'r') as f:
            for line_number, line in enumerate(f):
                if line.startswith(comment_prefix):
                    file_comments.setdefault(file_name, []).append((line_number+1, line[:-1]))

    
    for file_name, lines in file_comments.items():
        base_name = os.path.basename(file_name)
        #output_title = '%s' % base_name
        #output = [output_title, "="*len(output_title), ''] 
        output = []
        lines.sort()
        for consec_lines in consecutive_lines(lines):
            header_line = "File: %s (lines %i to %i)" % (
                os.path.basename(file_name), 
                consec_lines[0][0], 
                consec_lines[-1][0]) 

            header_decoration = '#'*len(header_line)
            output.append(".. %s" % header_decoration)
            output.append(".. %s" % header_line)
            output.append(".. %s" % header_decoration)
            output.append("")
            for l in consec_lines:
                output.append(l[1][len_comment_prefix+1:])
            output.append("")
            output.append("")

        output_filename = os.path.join('extracted', "%s.rst" % base_name.replace('.','_'))
        with open(output_filename, 'w') as f:
            f.write("\n".join(output))
