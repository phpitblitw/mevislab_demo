import re
import os
import sys
from xml.sax.saxutils import escape
from xml.sax.saxutils import unescape

# File entry conversions
re_file = re.compile('(.*<File RelativePath=")(.*)(".*)')
def _convertFile(_line, _path):
    m = re_file.match(_line)
    if m:
        new_file_name = os.path.abspath( os.path.join(_path, m.group(2)) )
        if not os.path.exists(new_file_name):
            print "Converting path: %s to %s which is a non-existing file!" % (m.group(2), new_file_name)
        return  "%s%s%s\n" % (m.group(1), new_file_name, m.group(3))
    else:
        return _line

# Include directory conversions
re_include = re.compile('(.*AdditionalIncludeDirectories=")(.*)(".*)')
def _relDirToAbs(_dir, _path):
    if os.path.isabs(_dir):
        return _dir
    else:
        new_dir = os.path.abspath(os.path.join(_path, _dir) )
        if os.path.exists(new_dir):
            return new_dir
        else:
            print "Not converting include directory: %s since %s does not exists!" % (_dir, new_dir)
            return new_dir

def _convertIncludeDirectories(_line, _path):
    m = re_include.match(_line)
    if m:
        converted_directories = []
        for d in (unescape(x, {"&quot;": ''}) for x in m.group(2).split(',')):
            converted_directories.append(_relDirToAbs(d, _path))
        new_include_directories = ",".join( "&quot;%s&quot;" % x for x in converted_directories)
        return "%s%s%s\n" % (m.group(1), new_include_directories, m.group(3))
    return _line

# Command line
re_commandline = re.compile('(.*CommandLine=")(.*)(".*)')
lib_patterns = ['../../../lib', '../../lib', '../lib']
def _convertCommandLine(_line, _path):
    m = re_commandline.match(_line)
    if m:
        # clear the output build command for the .pro file
        if m.group(2).startswith('set MLAB_COMPILER_VERSION'):
            return "%s%s%s\n" % (m.group(1), "", m.group(3))
        else:         
            # These search and replaces convert the Post-Build steps to copy the
            # .dll files to the lib folder in the source directory.
            new_line = _line
            for pattern in lib_patterns:
                new_line = new_line.replace(pattern, os.path.abspath(os.path.join(_path, pattern) ) )
            return new_line
    return _line

def convert(_fileIn, _fileOut, _basePath):
    f_in = open(_fileIn, 'r')
    f_out = open(_fileOut, 'w')
    try:
        for line in f_in:
            new_line = line
            new_line = _convertFile(new_line, _basePath)
            new_line = _convertIncludeDirectories(new_line, _basePath)
            new_line = _convertCommandLine(new_line, _basePath)
            f_out.write(new_line)
    finally:
        f_in.close()
        f_out.close()



if __name__ == "__main__":
    if len(sys.argv) > 3:
        base_path = sys.argv[3]
    else:
        base_path = os.getcwd()
    convert(sys.argv[1], sys.argv[2], base_path)
    
