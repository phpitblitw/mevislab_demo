#!/usr/bin/python
from __future__ import with_statement

"""
VCProjToCMakeLists

This script takes as input a .vcproj file and outputs CMake commands 
defined in the CMakeDefines.in file in the LkebBase folder.

The commands are used to add all the files defined in the .vcproj with 
their folder structure to the CMakeLists.txt file

Author: Pieter Kitslaar
"""

from xml.sax import make_parser
from xml.sax.handler import ContentHandler 
import os
import sys
import re
from optparse import OptionParser


def GetSubstitudeIncludeDir(_originalInclude):
		return _originalInclude

def GetSubstitudeLibraryName(_originalLib):
		return [_originalLib]


class ProjectFile:
	def __init__(self):
		self.FileName = ""
		self.ExcludeFromBuild = False
		self.FileExists = True
		self.ShouldBeMOCed = False
		self.MOCOutputFile = ""
	
	def GetCMakeFileString(self):
		returnString = self.FileName
		returnString = '"%s"' % returnString.replace('\\','/')
		if not self.FileExists:
			returnString = "#" + returnString + " FILE DOES NOT EXISTS"
		elif self.ExcludeFromBuild:
			returnString = "#" + returnString + " FILE EXCLUDED FROM BUILD"

		return returnString



class ProjectConfiguration:
	def __init__(self):
		self.PreProcessorDefines = []
		self.IncludeDirectories = []
		self.LinkLibraries = []
		self.LinkDirectories = []
		self.ConfigurationType = "LIB"
	
	def SetConfigurationTypeToApplication(self):
		self.ConfigurationType = "APP"
	
	def SetConfigurationTypeToLibrary(self):
		self.ConfigurationType = "LIB"
	
	def IsApplication(self):
		return self.ConfigurationType == "APP"

	def IsLibrary(self):
		return self.ConfigurationType == "LIB"



class Project:
	def __init__(self):
		self.ProjectName = ""
		self.Configurations = {}
		self.FilesNotInGroup = []
		self.GroupFiles = {}
		self.FilesToBeMOCed = []

	def PrintSelf(self):
		print "ProjectName:", self.ProjectName

		print "Configurations (total %i):" % len(self.Configurations)	
	
		for configuration in self.Configurations.keys():
			
			indent = 2
			print " "*indent, "Configuration: ", configuration	
			currentConfiguration = self.Configurations[configuration]

			indent = 4
			print " "*indent, "Type: %s" % currentConfiguration.ConfigurationType

			print " "*indent, "IncludeDirectories (total %i):" % len(currentConfiguration.IncludeDirectories)
			for dir in currentConfiguration.IncludeDirectories:
				print " "*(indent + 1), dir

			print " "*indent, "LinkDirectories (total %i):" % len(currentConfiguration.LinkDirectories)
			for d in currentConfiguration.LinkDirectories:
				print " "*(indent + 1), d

			print " "*indent, "LinkLibraries (total %i):" % len(currentConfiguration.LinkLibraries)
			for lib in currentConfiguration.LinkLibraries:
				print " "*(indent + 1), lib

			print " "*indent, "PreProcessorDefines (total %i):" % len(currentConfiguration.PreProcessorDefines)
			for define in currentConfiguration.PreProcessorDefines:
				print " "*(indent + 1), define
		print

		print "Files Not In A Group (total %i):" % len(self.FilesNotInGroup)
		for file in self.FilesNotInGroup:
			print " "*4, file.GetCMakeFileString()
		print 

		print "File Groups (total %i):" % len(self.GroupFiles)
		for group in self.GroupFiles.keys():
			print " ", group, ":"
			for file in self.GroupFiles[group]:
				print " "*4, file.GetCMakeFileString()
			print
		print

		print "Files to be MOCed (total %i):" % len(self.FilesToBeMOCed)
		maxLenFileName = 0
		for file in self.FilesToBeMOCed:
			if len(file.GetCMakeFileString()) > maxLenFileName:
				maxLenFileName = len(file.GetCMakeFileString())

		for file in self.FilesToBeMOCed:
			print " "*4, file.GetCMakeFileString().ljust(maxLenFileName + 1), " --> ", file.MOCOutputFile
		print
				
		
		

class VCProjectHandler(ContentHandler):
	def __init__(self):
		self.project = Project()
		self.currentFile = ProjectFile()
		self.currentConfigurationName = ""
		self.inConfiguration = 0
		self.inFiles = 0
		self.currentFilterNamePath = []
		self.inFileConfiguration = 0

	def startElement(self, name, attrs):
#		print name
		if name == "VisualStudioProject":
			self.project.ProjectName = attrs.get('Name',"")
		if name == "Configuration":
			cfg_name = attrs.get('Name',"")
			self.currentConfigurationName = cfg_name.split('|')[0].upper() 
			newConfiguration = ProjectConfiguration()

			# Is it a application or a library
			configurationType = attrs.get('ConfigurationType',"")
			if configurationType == "1":
				newConfiguration.SetConfigurationTypeToApplication()
			elif configurationType == "2":
				newConfiguration.SetConfigurationTypeToLibrary()

			self.project.Configurations[self.currentConfigurationName] = newConfiguration
			self.inConfiguration = 1 
		

		if name == "Tool" and self.inConfiguration: # the tool name is also in the Files section
			currentConfiguration = self.project.Configurations[self.currentConfigurationName]
			toolNameAttribute = attrs.get('Name',"")
		
			if toolNameAttribute == "VCCLCompilerTool":
				# Process Include Dirs
				includeDirString = attrs.get('AdditionalIncludeDirectories',"")

				# this regular expression holds all the characters that should be used to split the line
				includeSplitter = re.compile('[,;]')
				for dir in includeSplitter.split(includeDirString):
					# replace all the '(' and ')' characters
					# with '{' and '}' 
					# This will make it easier to use the enviroment 
					# variables als CMake variables
					newDir = dir.strip('"')
					#newDir = newDir.replace('$','')
					#newDir = newDir.replace('(','')
					#newDir = newDir.replace(')','')
					if newDir == "" or newDir ==".":
						continue
					newDir = GetSubstitudeIncludeDir(newDir)
					#newDir = newDir.replace('(','{')
					#newDir = newDir.replace(')','}')
					newDir = newDir.replace('\\','/')
					newDir = GetSubstitudeIncludeDir(newDir)
					#newDir = "${%s}" % newDir
					# strip quotes
					newDir = newDir.strip('"')
					currentConfiguration.IncludeDirectories.append(newDir)
				
				# Process preprocessor defines
				preprocessorDefinesString = attrs.get('PreprocessorDefinitions',"")
				defineSplitter = re.compile('[,;]')
				for define in defineSplitter.split(preprocessorDefinesString):
					currentConfiguration.PreProcessorDefines.append(define)

			if toolNameAttribute == "VCLinkerTool":
				# Process link libraries
				linkLibrariesString = attrs.get('AdditionalDependencies',"")
				for lib in linkLibrariesString.split():
					newLib = lib
					#newLib = newLib.replace('(','{')
					#newLib = newLib.replace(')','}')
					newLib = newLib.split('.lib')[0]
					newLibs = GetSubstitudeLibraryName(newLib)
					currentConfiguration.LinkLibraries.extend(newLibs)

				linkDirectoriesString = attrs.get('AdditionalLibraryDirectories')
				for d in linkDirectoriesString.split(','):
					link_dir = d.strip('"')
					link_dir = os.path.normpath(link_dir).replace('\\','/')
					currentConfiguration.LinkDirectories.append(link_dir)

		if name == "Files":
			self.inFiles = 1

		if name == "Filter" and self.inFiles:
			self.currentFilterNamePath.append(attrs.get('Name',"").replace('&','&amp\;'))
			

		if name == "File":
			self.currentFile = ProjectFile()
			self.currentFile.FileName = attrs.get('RelativePath',"").strip('.\\')

			# use the global variable parseFileDirectory to get the absolute path
			# to the filename to see if it exists
			absoluteFileName = os.path.join(parseFileDirectory,self.currentFile.FileName)
			if not os.path.exists(absoluteFileName):
				self.currentFile.FileExists = False

		if name == "FileConfiguration":
			self.inFileConfiguration = 1
			if attrs.get('ExcludedFromBuild',"") == 'TRUE':
				self.currentFile.ExcludeFromBuild = True

		if name == "Tool" and self.inFileConfiguration:
			toolName = attrs.get('Name',"")
			if toolName == "VCCustomBuildTool":
				# assume that file should be MOCed using Qt moc command
				# if the CommandLine contains the word 'moc' 
				commandLineString = attrs.get('CommandLine',"")
				if commandLineString.find('moc') != -1:
					# assume the file needs to be MOced
					self.currentFile.ShouldBeMOCed = True

					outputString = attrs.get('Outputs',"")

					mocOutputFileName = outputString
					mocOutputFileName = mocOutputFileName.replace('$(InputDir)','')
					mocOutputFileName = mocOutputFileName.replace('$(InputName)',self.currentFile.FileName.split('.')[0])
					mocOutputFileName = mocOutputFileName.strip('\\')

					self.currentFile.MOCOutputFile = mocOutputFileName



	
	def endElement(self, name):
		if name == "Configuration":
			self.currentConfigurationName = ""
			self.inConfiguration = 0

		if name == "Files":
			self.inFiles = 0

		if name == "Filter" and self.inFiles:
			self.currentFilterNamePath.pop()

		if name == "File":

			if len(self.currentFilterNamePath):
				groupString = self.currentFilterNamePath[0]
				for name in self.currentFilterNamePath[1:]:
					groupString += "\\\\\\\\%s" % name

				if not groupString in self.project.GroupFiles.keys():
					self.project.GroupFiles[groupString] = []

				self.project.GroupFiles[groupString].append(self.currentFile)
			else:
				self.project.FilesNotInGroup.append(self.currentFile)

			if self.currentFile.ShouldBeMOCed:
				self.project.FilesToBeMOCed.append(self.currentFile)

		if name == "FileConfiguration":
			self.inFileConfiguration = 0



	def characters (self, ch):
		pass

def PrintSOURCES(project):
	# Added the files that don't belong to a group
	print "# set group name to \" \" to place files in the root folder of the project"
	addFilesToGroupString = "ADD_FILES_TO_GROUP(\" \""
	print addFilesToGroupString
	for file in project.FilesNotInGroup:
		print " "*len(addFilesToGroupString), file.GetCMakeFileString()
	print ")"
	print
	print "# Use 4 backslashes \"\\\\\\\\\" to indicate subfolder relations"
	print "# Use \"&amp\;\" instead of \"&\" in group names"
	print 

	# Now loop over all the groups
	for groupName in project.GroupFiles.keys():
		addFilesToGroupString = "ADD_FILES_TO_GROUP(\"%s\"" % groupName
		print addFilesToGroupString
		for file in project.GroupFiles[groupName]:
			print " "*len(addFilesToGroupString), 
			if file.ExcludeFromBuild:
				print "#",
			print file.GetCMakeFileString()
		print ")"
		print
	print

	# skip next section if no files should be moced
	if not len(project.FilesToBeMOCed):
		return

	print "# define the files to be moced"
	mocClassesString = "SET(%s_MOC_CLASSES" % project.ProjectName.upper()
	print mocClassesString
	for file in project.FilesToBeMOCed:
		print " "*len(mocClassesString), file.GetCMakeFileString()
	print ")"
	print

	print "# setup the moc commands for these files"
	print "LKEB_QT3_WRAP_CPP(%s_MOC_SOURCES ${%s_MOC_CLASSES})" % (project.ProjectName.upper(), project.ProjectName.upper())
	print "ADD_FILES_TO_GROUP(\"moc\" ${%s_MOC_SOURCES})" % project.ProjectName.upper()
	print


def PrintCMakeListsFromProject(project):
	print "# CMakeLists.txt created using vcproj2cmakelists.py"
	print
	print "Project(%s)" % project.ProjectName
	print
	#print "# Define the directory of the files as the project name dir for other projects"
	#print "SET(%s %s)" % (project.ProjectName.upper() + "DIR", "CMAKE_CURRENT_SOURCE_DIR")
	#print

	# look for the settings of the Debug configuration
	if "Debug" in project.Configurations.keys():
		firstConfigurationName = "Debug"
	else:
		firstConfigurationName = project.Configurations.keys()[0]
	configuration = project.Configurations[firstConfigurationName]

	# check for needed LkebUse* macros
	if "${VTK_LIBRARIES}" in configuration.LinkLibraries:
		print "FIND_PACKAGE(VTK REQUIRED) ",
		print "# load the VTK4 stuff"

	if "${QT_LIBRARIES}" in configuration.LinkLibraries:
		print "LkebUseQt3() ",
		print "# load the QT3 stuff"
	
	if "${ITK_LIBRARIES}" in configuration.LinkLibraries: 
		print "LkebUseItk3() ",
		print "# load the Itk3 stuff"
	if "${DCMTK_LIBRARIES}" in configuration.LinkLibraries: 
		print "LkebUseDcmTk() ",
		print "# load the DcmTk stuff"
	print
	

	

	PrintSOURCES(project)	
	
	# add the library or executable command
	# the SOURCES variable keeps a list of the previous added sources
	# using the ADD_FILES_TO_GROUP calls
	if configuration.IsLibrary():
		print "# This command defines that we want to build a library"
		print "ADD_LIBRARY(%s ${SOURCES})" % project.ProjectName
	elif configuration.IsApplication():
		print "# This command defines that we want to build an executable "
		print "ADD_EXECUTABLE(%s ${SOURCES})" % project.ProjectName
	
	print "LKEB_TARGET_NAME(%s) # add \"Static\" and \"_d\" to output names" % project.ProjectName

	if not configuration.IsApplication():
		print "ENABLE_DLL_EXPORT(%s_EXPORTS)" % project.ProjectName.upper()
	print

	# Add the include directories
	print "# Define include directories"
	includeDirectoriesString = "INCLUDE_DIRECTORIES("
	print includeDirectoriesString
	for dir in configuration.IncludeDirectories:
		print " "*len(includeDirectoriesString), dir
	print ")"
	print


	# Add the link libraries
	print "# Define the link libraries"
	linkLibrariesString = "TARGET_LINK_LIBRARIES(%s" % project.ProjectName
	print linkLibrariesString
	for lib in configuration.LinkLibraries:
		print " "*len(linkLibrariesString), lib
	print ")"
	print

def PrintCMakeVariablesFromProject(_project):
	# Print the found headers and sources
	# Collect all files
	allFiles = _project.FilesNotInGroup[:]
	for files in _project.GroupFiles.values():
		allFiles.extend(files)
	allFileNames = [f.GetCMakeFileString() for f in allFiles]

	print "# Header and source files"
	print "SET(ML_SOURCES\n%s\n)" % '\n'.join(allFileNames)
	print

	# Print the obtained configurations
	print "# The found configurations in the vcproj file."
	print "# Usually these are just DEBUG and RELEASE."
	print "SET(ML_CONFIGS %s)" % " ".join(_project.Configurations.keys())
	print

	# print all the configuration options
	for cfg_name, cfg_obj in _project.Configurations.items():
		# Print the pre-processor defines
		print "# Pre-processor defines for configuration: %s" % cfg_name
		print "SET(ML_DEFINES_%s\n%s\n)" % (cfg_name, "\n".join("%s" % define for define in cfg_obj.PreProcessorDefines))
		print

		# Print the include directories
		print "# Include directories for configuration: %s" % cfg_name
		print "SET(ML_INCLUDE_DIRECTORIES_%s\n%s\n)" % (cfg_name, "\n".join('"%s"' % dir for dir in cfg_obj.IncludeDirectories))
		print 

		# Print the link directories
		print "# Link directores for configuration: %s" % cfg_name
		print "SET(ML_LINK_DIRECTORIES_%s\n%s\n)" % (cfg_name, "\n".join('"%s"' % dir for dir in cfg_obj.LinkDirectories))
		print

		# Print the link libraries
		print "# Link libraries for configuraton: %s" % cfg_name
		print "SET(ML_LINK_LIBRARIES_%s\n%s\n)" % (cfg_name, "\n".join(cfg_obj.LinkLibraries))
		print


		pass


if __name__ == "__main__":
	# setup default usage string
	usage = "Usage: %prog [options] <filename>\n"
	
	# create the options parser and fill with valid options
	parser = OptionParser(usage)
	#parser.add_option("-s", "--sources-only", dest="OnlySources", action="store_true", help="Only print the sources files part of the CMakeLists.txt")
	parser.add_option("-o", "--output-file", dest="OutputFile", help="Set the output filename.")
	parser.add_option("-d", "--debug-output", dest="DebugOutput", action="store_true")
	parser.add_option("-c", "--cmake-variables-output", dest="CMakeVariables", action="store_true", help="Print CMake variables")

	(options, args) = parser.parse_args()

	if len(args) < 1:
		parser.print_help()
		sys.exit(1)

	vcProjFile = sys.argv[1]
	if not os.path.exists(vcProjFile):
		print "Error: File %s not found !" % vcProjFile
		sys.exit(1)
	
	parseFileDirectory = os.path.dirname(vcProjFile) # Global variable that sets the directory of the file that we are parsing
	with open(vcProjFile,'r') as f:
		parser = make_parser()
		handler = VCProjectHandler()
		parser.setContentHandler(handler)
		parser.parse(f)

	if options.DebugOutput:
		handler.project.PrintSelf()
		sys.exit(0)

	# see if we want the output to be redirected to a file
	if options.OutputFile:
		f = open(options.OutputFile, 'w')
		sys.stdout = f

	#if options.OnlySources:
	#	PrintSOURCES(handler.project)
	if options.CMakeVariables:
		PrintCMakeVariablesFromProject(handler.project)
	else:
		PrintCMakeListsFromProject(handler.project)
	
	if options.OutputFile:
		sys.stdout.close()
		sys.stdout = sys.__stdout__
		f.close()

	

	




	

	
