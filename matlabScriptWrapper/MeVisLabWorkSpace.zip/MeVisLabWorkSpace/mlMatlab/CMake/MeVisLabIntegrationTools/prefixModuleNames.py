import os
import sys
import re
import optparse

m = re.compile('(MLModule|MacroModule|InventorModule) ([^ {]*) *{')

def GetDefFiles(_dir = None):
    d = _dir or '.'
    files = []
    for dir_name, sub_dirs, file_names in os.walk(d):
        for f in file_names:
            if f.endswith('.def'):
                files.append(os.path.join(dir_name, f))
    return map(os.path.abspath, files)

def Modules(_fileName, _conversionDict = None):
    f = open(_fileName, 'r')
    groups = []
    output_lines = []
    for l in f:
        r = m.match(l)
        if r:
            m_type, m_name = r.groups()
            if _conversionDict and m_name in _conversionDict:
                new_name = _conversionDict[m_name]
            else:
                new_name = PrefixedName(m_type, m_name)
            if new_name != m_name:
                groups.append((m_type, m_name, new_name))
            output_lines.append('%s %s {\n' % (m_type, new_name) )
            if m_type != 'MacroModule':
                output_lines.append('  class = %s\n' % m_name)
            output_lines.append('  deprecatedName = %s\n' % m_name)
        else:
            output_lines.append(l)
    f.close()
    return groups, output_lines

def PrefixedName(_type, _name):
    lower_name = _name.lower()
    base_name = _name
    if lower_name.startswith('lkeb'):
        base_name = _name[4:]
    return "LKEB%s" % base_name

if __name__ == "__main__":
    parser = optparse.OptionParser()

    parser.add_option("-s", "--save", dest="SaveNameConversions", help="Filename to dump the initial name conversions to. Does not write .def files.")
    parser.add_option("-l", "--load", dest="LoadNameConversions", help="Filename to load the name conversions from.")
    parser.add_option("-w", "--write", dest="WriteNewFiles", action="store_true", help="Only when this option is enabled are the .def files overwritten.")

    opts, args = parser.parse_args()

    root = os.getcwd()
    if len(args) > 0:
        root = os.path.abspath(sys.argv[1])

    module_database = {}
    files = GetDefFiles(root)


    conversion_dict = {}
    if opts.LoadNameConversions:
        f = open(opts.LoadNameConversions, 'r')
        for l in f:
            if not l.startswith('#') and len(l) > 1:
                old_name, new_name = l.strip().split(' ',1)
                conversion_dict[old_name] = new_name

    # look for duplicate new_names
    new_names = conversion_dict.values()
    unique_new_names = set(new_names)
    if len(unique_new_names) != len(new_names):
        print "Found duplicate module names!"
        sys.exit(1)

    updated_files = []
    for f in files:
        module_database[f], new_file_content = Modules(f, conversion_dict)
        if opts.WriteNewFiles and module_database[f]:
            new_file_name = "%s.new" % f
            new_f = open(new_file_name, 'w')
            new_f.write("".join(new_file_content))
            new_f.close()

            old_name = "%s.old" % f
            if os.path.exists(old_name):
                os.remove(old_name)
            os.rename(f, old_name)
            os.rename(new_file_name, f)
            
            updated_files.append(f)

    if opts.SaveNameConversions:
        f = open(opts.SaveNameConversions, 'w')
        for fileName in sorted(module_database.keys()):
            f.write("# %s\n" % fileName)
            for mod in sorted(module_database[fileName]):
                f.write("%s %s\n" % (mod[1], mod[2]))
            f.write("\n")
        f.close()


    updated_modules = [l for f, l in module_database.items() if f in updated_files]
    num_modules = sum( map( len, updated_modules) )
    print "Updated %i modules in %i files." % (num_modules, len(updated_files))

        

    
    
            
