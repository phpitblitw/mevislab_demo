from __future__ import with_statement

import os
import sys
import optparse
import re
import subprocess
import string



def GetPrefFile(_dir, debug_mode = False):
    """ Returns the name of the preference file. """
    root = _dir if _dir else os.getcwd()
    postfix = 'Debug' if debug_mode else 'Release'
    return os.path.abspath(os.path.join(root, 'ML_%s.pref' % postfix) )


def ParsePrefFile(_file):
    """Parse the pref file and return a dict with key = (package_group, package_name) and value = directory."""
    package_dict = {} # define the return dict
    re_key_value = re.compile('(\w+) = (.+)$') # create the regular expression to find the PathRoot and Path settings
    current_root = os.getcwd() # set the current working directory as the current_root

    # open the file
    with open(_file,'r') as f:
        
        # search each line
        for line in f:
            m = re_key_value.search(line)
            if m:
                m_g = m.groups()

                # set the current root
                if m_g[0] == 'PathRoot':
                    # remove quotes
                    current_root = os.path.abspath( m_g[1].replace('"','') )
                
                if m_g[0] == 'Path':
                    # convert slashes and remove quotes
                    p = m_g[1].replace('\\','/').replace('"','')
                    (package_group, package_name) = p.split('/',1) # split at the '/' delimiter
                    package_dir = os.path.join(current_root, package_group, package_name)

                    # add the the dictionary
                    package_dict[(package_group, package_name)] = package_dir

    return package_dict

def FindInstallers(_package_root):
    """ Search a package structure for installers."""
    installers = []

    installers_dir = os.path.join(_package_root, 'Configuration', 'Installers')
    if os.path.exists(installers_dir):
        for dirpath, dirnames, filenames in os.walk(installers_dir):
            for file in filenames:
                if file.endswith('.mlinstall'):
                    base_name =  os.path.splitext(file)[0] 
                    install_file = os.path.join(_package_root, dirpath, file) 
                    installers.append((base_name, install_file))

    return installers

def FindInstalledPackages():
    """Returns a dictionary with all the MeVisLab packages found by the MeVisLabPackageScanner."""

    # run the MeVisLabPackageScanner program
    mevis_package_scanner = os.path.join(os.environ.get('MLAB_ROOT'), 'MeVisLab', 'IDE', 'bin', 'MeVisLabPackageScanner.exe')
    p = subprocess.Popen([mevis_package_scanner, '-ignoreprefs', '-info'], stdout=subprocess.PIPE, stderr = subprocess.PIPE)
    std_out, std_err = p.communicate()

    # parse the output to find all the packages
    all_packages = {}
    current_package = None
    for l in std_out.split('\n'):
        stripped = l.strip()
        if not stripped:
            break
        k, v = stripped.split(':',1)
        if k.lower() == 'package':
            current_package = v.strip()
            continue
        
        if not current_package:
            raise ValueError("No package found in MeVisLabPackageScanner output!")
        all_packages.setdefault(current_package, {})[k] = v.strip()

    return all_packages
    
                

def main():
    # create the parser
    parser = optparse.OptionParser()

    # add the allowed options
    parser.add_option("-r", "--root-dir", dest="RootDirectory", help="Root directory to run from.")
    parser.add_option("-d", "--debug-mode", action="store_true", dest="DebugMode", help="Use debug preferences.")
    parser.add_option("-i", "--install-script", dest="InstallScript", help="Define the install script to run.")
    parser.add_option("-l", "--log-file", dest="LogFile", help="Write the output to a log file.")
    parser.add_option("-v", "--verbose", dest="Verbose", action="store_true", help="Verbose output.")
    parser.add_option("-n", "--dry-run", action="store_true", dest="dryrun", help="Don't execute build process")

    # parse the command line arguments
    (options, args) = parser.parse_args()

    # Get the preference file
    pref_file = GetPrefFile(options.RootDirectory,options.DebugMode)

    # get the mevislab_install_path variable from the MLStart_Release.py file
    sys.path.append(os.path.dirname(pref_file))
    from MLStart_Release import mevis_install_path  

    # set the MLAB_ROOT to point to the correct MeVisLab install (as found by CMake)
    os.environ['MLAB_ROOT'] = os.path.join(mevis_install_path, 'Packages')

    # find the MLAB_COMPILER_VERSION in the BuildTools\win32\deploy directory
    deploy_dir = os.path.join(mevis_install_path, 'Packages', 'MeVis', 'Foundation', 'BuildTools', 'win32', 'deploy')
    os.environ['MLAB_COMPILER_VERSION'] = os.listdir(deploy_dir)[0]

    # we set the MLAB_BOOTSTRAP variable so the MeVisLabPackageScanner.exe is not
    # used to override the enivronment when 'assembleInstaller.py' is called
    # from the 'buildInstaller.py' script
    os.environ['MLAB_BOOTSTRAP'] = 'TRUE'

    # See we use the MLAB_BOOTSTRAP method we have to make sure we supply the paths to
    # the standard installed MeVisLab packages ourself.
    installed_packages = FindInstalledPackages()

    # parse the Preferences file
    packages = ParsePrefFile(pref_file)

    pref_package_names = set(map(string.lower, ["%s/%s" % p_info for p_info in packages.keys()]) )

    for p_name, p_info in installed_packages.items():
        if p_name.lower() in pref_package_names:
            print "!! Using package info from Preference file for: %s" % p_name
        else:
            #print "Settings environment for: %s" % p_name
            os.environ["MLAB_%s_%s" % tuple(p_name.split('/',1))] = p_info['Path']

    install_file_to_run = options.InstallScript


    if not install_file_to_run:
        # collect all the installers in all packages
        found_installers = []
        for package_info, package_dir in packages.items():
            installers = FindInstallers(package_dir)
            for installer in installers:
                found_installers.append( {'PackageGroup': package_info[0], 'PackageName': package_info[1], 'PackageRoot': package_dir, 'InstallerName': installer[0], 'InstallerScript': installer[1]} )

        #
        if not len(found_installers):
            print "Could not find any installers."
            sys.exit(0)

        title =  "%s %-30s %-30s" % ('Index', 'Package', 'Installer')
        print title
        print "="*len(title)
        for i, fi in enumerate(found_installers):
            print "[%3i]" % i,
            package_name = str("%s/%s" % (fi['PackageGroup'], fi['PackageName'])).ljust(30)[:30]
            installer_name = str(fi['InstallerName']).ljust(30)[:30]
            print "%s %s" % (package_name, installer_name)
        print 

        while True:
            s = raw_input("Choose installer to run. ([q] to quit): ")
            if s == 'q':
                break
            if s.isdigit():
                index = eval(s)
                if index >= 0 and index < len(found_installers):
                    install_file_to_run = found_installers[index]['InstallerScript']
                    break

    if install_file_to_run:
        if not os.path.exists(install_file_to_run):
            raise RuntimeError('Could not find file: %s' % install_file_to_run)
        
        # Set the environment variables from the packages
        for p_info, p_dir in packages.items():
            os.environ["MLAB_%s_%s" % (p_info[0], p_info[1])] = p_dir
        
        # get the directory of the batch file
        install_dir = os.path.dirname(install_file_to_run)

        f = None
        if options.LogFile:
            f = open(options.LogFile, 'w')

        try:
            # run the script
            mevis_script = os.path.join(os.environ.get('MLAB_ROOT'), 'MeVis', 'Foundation', 'BuildTools', 'Scripts', 'buildInstaller.py')
            cmd = [sys.executable, mevis_script, install_file_to_run]
            if options.Verbose:
                cmd.append("-v")
            if options.dryrun:
                cmd.append("-n")
            p = subprocess.Popen(cmd, cwd=install_dir, stdout=subprocess.PIPE, stderr = subprocess.STDOUT)
            while True:
              out = p.stdout.readline(1)
              if out == '' and p.poll() != None:
                break
              sys.stdout.write(out)  
              sys.stdout.flush()
          
              if f:
                f.write(out)
        except RuntimeError, e:
            print e
        finally:
            if f:
                f.close()
         
         


if __name__ == "__main__":
    main(sys.argv[1:])
                







    
    
