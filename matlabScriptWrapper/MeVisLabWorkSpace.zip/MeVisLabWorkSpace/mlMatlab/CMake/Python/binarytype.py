from __future__ import with_statement 
import struct

IMAGE_FILE_MACHINE_I386=332
IMAGE_FILE_MACHINE_IA64=512
IMAGE_FILE_MACHINE_AMD64=34404

def getBinaryType(_file):
    with open(_file, "rb") as f:
        s=f.read(2)
        if s!="MZ":
           return None 

        f.seek(60)
        s=f.read(4)
        header_offset=struct.unpack("<L", s)[0]
        f.seek(header_offset+4)
        s=f.read(2)
        machine=struct.unpack("<H", s)[0]

        if machine==IMAGE_FILE_MACHINE_I386:
            return "IA-32"
        elif machine==IMAGE_FILE_MACHINE_IA64:
            return "IA-64"
        elif machine==IMAGE_FILE_MACHINE_AMD64:
            return "AMD64"
        else:
            return None


if __name__ == "__main__":
    import sys
    sys.stdout.write(getBinaryType(sys.argv[1]))
