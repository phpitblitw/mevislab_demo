""" untar.py
    Version: 1.1

    Extract a tar to the directory provided
    It first creates the directory structure to house the files
    then it extracts the files to it.

    unzip.py -z c:\testfile.zip -o c:\testoutput

    By Pieter Kitslaar
"""

import os
import sys
import tarfile
from shared_utils import mkdir


def non_existing_filter(root_dir, members):
    for tarinfo in members:
        full_path = os.path.join(root_dir, tarinfo.name)
        if os.path.exists(full_path):
            continue
        yield tarinfo

def main():
    tar = tarfile.open(sys.argv[1])
    try:
        root_dir = sys.argv[2]
        tar.extractall(path=root_dir, members=non_existing_filter(root_dir, tar))
    finally:
        tar.close()
    
if __name__ == '__main__': 
	main()
