import datetime

s = datetime.date.today()
a = str(s.year)
if s.month < 10:
  a += '0'
a += str(s.month)
if s.day < 10:
  a += '0'
a += str(s.day)

print a