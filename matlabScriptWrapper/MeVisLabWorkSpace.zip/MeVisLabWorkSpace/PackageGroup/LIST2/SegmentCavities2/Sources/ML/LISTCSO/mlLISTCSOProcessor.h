//----------------------------------------------------------------------------------
//! The ML module class LISTCSOProcessor.
/*!
// \file    mlLISTCSOProcessor.h
// \author  gyyang
// \date    2011-06-28
//
// 
*/
//----------------------------------------------------------------------------------


#ifndef __mlLISTCSOProcessor_H
#define __mlLISTCSOProcessor_H


// Local includes
#include "LISTCSOSystem.h"
#include "CSOProcessor/CSOProcessor.h"
#include "mlVector2.h"

// ML includes
#include <mlModuleIncludes.h>

ML_START_NAMESPACE


//! Enumeration of filtering modes.
enum MonotonicFilterModes {
  MonotonicFilterX = 0, //!< Monotonic filtering of X values
  MonotonicFilterY = 1, //!< Monotonic filtering of Y values
};


//! 
class LISTCSO_EXPORT LISTCSOProcessor : public CSOProcessor
{
public:

  //! Constructor.
  LISTCSOProcessor ();

    //! Processes the interaction events and interpolates
  //! the contours accordingly.
  virtual bool process(CSOList* csoList, Vector3& currentHitPoint, int hitMode, CSO* recentlySelectedCSO, CSOSeedPoint*  recentlySelectedSeedPoint, CSOPathPoints* recentlySelectedPathPoints, SoView2D* view2d, View2DSliceList* slicelist, View2DEvent* ec,  View2DEventPhase phase, CSOBoundingBox slabBB, int timepointindex, bool deleteSeedPoint);

  //! Returns if the processor need the current
  //! memory image for interpolation.
  virtual bool needsMemoryImage();

  //! Returns if the processor is currently generating a new contour.
  virtual bool isCurrentlyGenerating();

  //! Returns if the processor is currently editing an existing contour.
  virtual bool isCurrentlyEditing();

  //! Returns if the processor could close an open CSO by the processor's rules.
  virtual bool couldCloseCSO();

  //! Sets back internal interaction state.
  virtual void resetInteractionState();

  //! Triggers the setting of the processors default mouse cursor.
  virtual void triggerSetMouseCursor(SoView2D* view2d, bool shouldSetMouseCursor);

protected:

  //! Standard destructor.
  virtual ~LISTCSOProcessor();

  //! Initialize module after loading
  virtual void activateAttachments();

  //! Called when input changes.
  virtual void handleNotification(Field* field);

private:

  /* FIELDS */

  //! Discard intersectin contours
  BoolField* _discardIntersectingContoursFld;

  //! Enable monotonic filtering.
  BoolField* _monotonicFilteringFld;

  //! Set the monotonic filtering mode.
  EnumField* _monotonicFilterModeFld;

  /* MEMBER VARIABLES */

  //! A pointer to the CSOList.
  CSOList* _csoList;

  //! The current hit point in world coordinates.
  Vector3 _currentHitPointWorld;

  //! A pointer to the main modification contour.
  CSO* _mainModificatorCSO;

  //! Is this processor currently editing?
  bool _isCurrentlyEditing;

  //! A pointer to the open contour that was recently selected to edit
  CSO* _contourToModify;

  /* METHODS */

  //! Obtain the point indices in the _originalPoints vector closest to the start- and endpoints of the _modifyPoints vector.
  //! Returns true is the closest indices cross the zero boundary
  bool FindClosestStartEndIndices( const std::vector<Vector3> &_modifyPoints, const std::vector<Vector3> &_originalPoints, int& _closestIndexStart, int& _closestIndexEnd, std::set<int>& _allIndices );

  //! Project the points in the vector on the z-plane using the given _rotationCenter and _rotation matrix
  void ProjectPointsForward( std::vector<Vector3> &_points, const Vector3& _rotationCenter, Rotation &_rotation );

  //! Project the points in the vector from the z-plane back using using the given _rotationCenter and _rotation matrix and the original z-coordinate.
  //! This requires the conjugate version of the rotation matrix used for the Forward projection.
  void ProjectPointsBackwards( std::vector<Vector3> &_points, const float _originalZValue, const Vector3& _rotationCenter, Rotation &_rotation );

  bool LISTCSOProcessor::ContoursIntersect(const std::vector<Vector3> &_points1, const std::vector<Vector3> &_points2);

  //! Apply monotonic filtering to the points for the given mode
  void MonotonicFilter(View2DSliceList* slicelist, std::vector<Vector3>& points, MonotonicFilterModes _mode);

  //! Fill values in the matrix from the WorldToVoxelMatrix from the slicelist.
  void FillWorldToVoxelMatrixFromSliceList( View2DSliceList* slicelist, Matrix4& matrix );

  //! Computes the screen position in pixels of a world points and the current mouse cursor position (sliceList).
  void _getScreenPosition(View2DSliceList* slicelist, const Vector3& worldPos1, Vector2f& devPos1);

  //! Computes the squared screen distance in pixels of a given point and the current mouse cursor position.
  float _getScreenDistance(View2DSliceList* slicelist, const Vector3& worldPos1, const Vector3& worldPos2);


  // Implements interface for the runtime type system of the ML.
  ML_MODULE_CLASS_HEADER(LISTCSOProcessor)
};


ML_END_NAMESPACE

#endif // __mlLISTCSOProcessor_H

