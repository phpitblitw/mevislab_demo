//----------------------------------------------------------------------------------
//! Project global and OS specific declarations.
/*!
// \file    LISTCSOSystem.h
// \author  gyyang
// \date    2011-06-28
*/
//----------------------------------------------------------------------------------


#ifndef __LISTCSOSystem_H
#define __LISTCSOSystem_H


// DLL export macro definition
#ifdef WIN32
#ifdef LISTCSO_EXPORTS
// Use the LISTCSO_EXPORT macro to export classes and functions
#define LISTCSO_EXPORT __declspec(dllexport)
#else
// If included by external modules, exported symbols are declared as import symbols
#define LISTCSO_EXPORT __declspec(dllimport)
#endif

#else
// No export declarations are necessary for non-Windows systems
#define LISTCSO_EXPORT
#endif


#endif // __LISTCSOSystem_H


