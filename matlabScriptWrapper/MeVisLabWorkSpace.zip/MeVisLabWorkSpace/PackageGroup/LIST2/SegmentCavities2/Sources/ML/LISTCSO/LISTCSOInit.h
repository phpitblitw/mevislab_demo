//----------------------------------------------------------------------------------
//! Dynamic library and runtime type system initialization.
/*!
// \file    LISTCSOInit.h
// \author  gyyang
// \date    2011-06-28
*/
//----------------------------------------------------------------------------------


#ifndef __LISTCSOInit_H
#define __LISTCSOInit_H


ML_START_NAMESPACE

//! Calls init functions of all modules to add their types to the runtime type
//! system of the ML.
int LISTCSOInit ();

ML_END_NAMESPACE

#endif // __LISTCSOInit_H


