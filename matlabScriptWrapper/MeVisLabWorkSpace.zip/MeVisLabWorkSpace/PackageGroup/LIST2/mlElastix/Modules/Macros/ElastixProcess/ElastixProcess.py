from mevis import *
import os
import tempfile

compiler_to_folder = {'VC9': 'win32', 'VC9_64': 'win64'}
unexpanded_bin_folder = '$(MLAB_MeVisLabLKEB_mlElastix)/bin/%s' % compiler_to_folder[MLAB.compilerInfo()]
bin_folder = 'E:/Project2/PackageGroup/LIST/mlElastix/bin/win64' #ctx.expandFilename(unexpanded_bin_folder)

elastix_prog = os.path.join(bin_folder, 'elastix.exe')
transformix_prog = os.path.join(bin_folder, 'transformix.exe')

def setProcess(proc):
  globals()['current_process'] = proc

def getProcess():
  return globals().get('current_process')

def load_parameters():
  ctx.field("parameters").value = MLABFileManager.readStringFromFile(ctx.field("parameters_file").value)

def save_parameters():
  MLABFileManager.writeStringToFile(ctx.field("parameters_file").value, ctx.field("parameters").value)

linesInLog = []

def clear_log():
  global linesInLog
  del linesInLog[:]
  ctx.field("init_log").touch()
  
def init_log():
  global linesInLog
  ctx.control("log_window").setText("\n".join(linesInLog))
  if linesInLog:
    ctx.control("log_window").setCursorPosition(len(linesInLog),0)
  
def append_log(f):
  global linesInLog
  logCtrl = ctx.control("log_window")
  text = f.value
  if logCtrl and text:
    logCtrl.appendText(text)
    logCtrl.setCursorPosition(len(linesInLog), 0)
  
def doLog(text):
  global linesInLog
  linesInLog.extend([l for l in text.split('\n')])
  ctx.field("append_log").value = text
    
def onAffineStdOut(p):
  doLog(p.readStdOut())
  
def onAffineStdErr(p):
  doLog(p.readStdErr())
  
def onLaunched():
  doLog("Starting %s..." % get_mode_name())
  
def get_expected_result_file_names():
  output_dir = ctx.field("output_directory").value
  
  return {
    'result_image': os.path.join(output_dir, 'result.0.mhd'),
    'result_transformation': os.path.join(output_dir, 'TransformParameters.0.txt'),
    'result_log': os.path.join(output_dir, 'elastix.log'),
  }

def clean_expected_result_files():
  for _, filename in get_expected_result_file_names().items():
    if os.path.exists(filename):
      os.remove(filename)
  
def onExited(p):
  exitStatus = p.exitStatus()
  doLog("%s finished with code: %s" % (get_mode_name(), exitStatus) )
  setProcess(None)
  
  for field_name, file_name in get_expected_result_file_names().items():
    if os.path.exists(file_name):
      ctx.field(field_name).value = file_name
    else:
      ctx.field(field_name).value = ""

def get_prog():
  if ctx.field("mode").value == "Elastix":
    return elastix_prog
  else:
    return transformix_prog

def get_mode_name():
  return ctx.field("mode").value

def isElastix():
  return ctx.field("mode").value == "Elastix"

def isTransformix():
  return ctx.field("mode").value == "Transformix"

def setElastixParameters(p):
   p.append("-f")
   p.append(ctx.field("fixed_image_file").value)
   
   if ctx.field("use_fixed_image_mask").value:
     p.append("-fMask")
     p.append(ctx.field("fixed_image_mask_file").value)
   
   p.append("-m")
   p.append(ctx.field("moving_image_file").value)
   
   if ctx.field("use_moving_image_mask").value:
     p.append("-mMask")
     p.append(ctx.field("moving_image_mask_file").value)
   
   p.append("-out")
   p.append(ctx.field("output_directory").value)
   
   if ctx.field("use_initial_transform").value:
     p.append("-t0")
     p.append(ctx.field("initial_transform").value)
   
   p.append("-p")
   p.append(ctx.field("parameters_file").value)
   
def setTransformixParameters(p):
   p.append("-in")
   p.append(ctx.field("moving_image_file").value)
   
   p.append("-out")
   p.append(ctx.field("output_directory").value)
   
   p.append("-tp")
   p.append(ctx.field("initial_transform").value)
    
def compute(): 
   clean_expected_result_files()
   
   proc = MLAB.newProcess()   
   
   binary = get_prog()
   proc.setStdOutHandler(ctx, "onAffineStdOut")
   proc.setStdErrHandler(ctx, "onAffineStdErr")
   proc.setLaunchFinishedHandler(ctx, "onLaunched")
   proc.setExitedHandler(ctx, "onExited")

   p = []   
   if isElastix():
     setElastixParameters(p)
   else:
     setTransformixParameters(p)

   proc.setWorkDir(os.path.dirname(binary));
   proc.addArgument(binary)
   for arg in p:
     proc.addArgument(arg)      
   
   setProcess(proc)
   proc.run()
   
def cancel():
  p, _ = getProcess()
  if p:
    p.kill()        

def loadParametersFromFile():
  pass
