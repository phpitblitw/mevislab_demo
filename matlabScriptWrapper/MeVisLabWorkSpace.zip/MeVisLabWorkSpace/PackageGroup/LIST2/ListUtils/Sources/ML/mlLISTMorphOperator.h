/*
// -----------------------------------------------------------------------
// 
// Copyright (c) 2001-2010, MeVis Medical Solutions AG, Bremen, Germany
// 
// This file is an example code file distributed with the MeVisLab SDK 
// software from MeVis Medical Solutions AG. The contents of this example 
// file may be used, distributed and modified without limitations.
// 
// THIS FILE IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT IT IS 
// PROVIDED 'AS-IS' FOR USE AT OWN RISK, WITHOUT ANY EXPRESSED OR IMPLIED 
// WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR 
// FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL MEVIS MEDICAL 
// SOLUTIONS AG OR THE AUTHORS BE HELD LIABLE FOR ANY DAMAGES ARISING FROM 
// THE USE OF THIS FILE.
// 
*/
//----------------------------------------------------------------------------------
//! This is an example module to demonstrate how to
//! process all pages of one or more images.
//!
//! \file    mlProcessAllPagesExample.h
//! \author  Wolf Spindler
//! \date    2003-08-29
//!
//! This module demonstrates how one or more (input) images
//! can be scanned sequentially using the
//! \code
//
//    processAllPages(outIndex)
//
//  \endcode
//! method of the ML class Module.
//!
//! That method starts the normal page based image processing
//! for all input or output pages of the module (which is usually
//! done only on demand).
//!
//! Internally all pages of the output image with index \c outIndex
//! are requested like from a connected module.
//! So a normal image processing takes place with the following changes:
//! - If \c outIndex is -1 then a temporary output image with index
//!   \c outIndex is created. The properties for the temporary output image
//!   are copied from the input image \c inIndex. If \c outIndex is positive
//!   it must specify a legal module output index. \c inIndex must be -1 in
//!   that case.
//! - If \c outIndex is negative then in \c calculateOutputSubImage the output 
//!   subimages must NOT be written since not data is collected for them
//!   to improve performance for pure input scan algorithms.
//! - The output index \c outIndex is passed to \c calculateOutputSubImage (even
//!   if it's negative). On negative values you can see that the output
//!   must not be written.
//!    
//! The return value will ML_RESULT_OK on successful operation, otherwise
//! a code describing the error.
//!
//! For a more detailed documentation of standard module methods please 
//! refer to mlAddExample.h or to a newly created BASIC_ADD module.
//!
//! Note: This module does not handle data types larger than MLdouble correctly.
//! 
//----------------------------------------------------------------------------------
#ifndef __mlLISTMorphOperator_H
#define __mlLISTMorphOperator_H

// Include system dependencies.
#ifndef    __LISTUtilsSystem_H
#include "LISTUtilsSystem.h"
#endif

// Include module programming stuff from ML
#ifndef __mlModuleIncludes_H
#include <mlModuleIncludes.h>
#endif

// ML code should be completely written in namespace ml.
ML_START_NAMESPACE

  //---------------------------------------------------------------------------------
  //! Shows how input image(s) can be scanned sequentially (page by page).
  //---------------------------------------------------------------------------------
  class LISTUTILS_EXPORT LISTMorphOperator : public Module{

  public: 
    //! Constructor. Creates "processPages", "numVoxels", "voxelSum" and "status" fields.
    LISTMorphOperator();

   ~LISTMorphOperator();

    //! \name Access method(s) to the field(s). Refer to their documentation for more infos.
    //@{
    inline NotifyField &getProcessIn0PagesFld() { return *_processIn0PagesFld; }
    inline NotifyField &getProcessOutPagesFld() { return *_processOutPagesFld; }
    inline DoubleField &getVoxelSumFld()        { return *_voxelSumFld;        }
    inline IntField    &getNumVoxelFld()        { return *_numVoxelFld;        }
    inline StringField &getStatusFld()          { return *_statusFld;          }
    inline DoubleField &getMinFld()             { return *_minFld;             }
    inline DoubleField &getMaxFld()             { return *_maxFld;             }
    //@}

  protected:
    //! Clears results on input changes and starts scanning on "processPages" activation.
    virtual void handleNotification(Field* field);

    //! Reset field values after module load or clone to be sure that no old stuff is loaded.
    virtual void activateAttachments();

    //! Specify the properties of the output image
    void calculateOutputImageProperties(int outIndex, PagedImage* outImage);

    //! Needs to be specified since it's overloaded by using the macro CALC_OUTSUBIMAGE*_CPP.
    virtual void calculateOutputSubImage(SubImage *outSubImg, int outIndex, SubImage *inSubImgs);

    //! Implements the data type specific analysis of the input pages whose properties/extents
    //! were specified in \c calculateInputSubImageBox().
    template <typename DATATYPE> 
      void calculateOutputSubImage(TSubImage<DATATYPE> *outSubImg, int outIndex,
                           TSubImage<DATATYPE> *inSubImg0,
                           TSubImage<DATATYPE> *inSubImg1);


  private:
    //! Reset fields to default (i.e. invalid) information. \c message then will
    //! be shown as status string in the status field.
    void _resetFieldInfos(std::string message);

    //! A notify field (a button) to start the processing of all pages of temporary output -1
    //! whose properties have been inherited from input 0.
    NotifyField *_processIn0PagesFld;

    //! A notify field (a button) to start the processing of all pages of output 0.
    NotifyField *_processOutPagesFld;

    //! The field collecting the sum of all voxels from input 0 whose
    //! corresponding voxels from input 1 are non zero. The default of this
    //! read-only field is 0.
    DoubleField *_voxelSumFld;

    //! Shows the number of voxels summed up in \c _voxelSumFld. The default
    //! of this read-only field is 0.
    IntField    *_numVoxelFld;

    //! Information about result shown in fields _voxelSumFld and _numVoxelFld.
    //! The default of this read only field is "Result is invalid".
    StringField *_statusFld;

    //! The field containing the input image minimum after scanning.
    //! The default of this read-only field is maximum of double type
    //! which also indicates an invalid value.
    DoubleField *_minFld;

    //! The field containing the input image maximum after scanning.
    //! The default of this read-only field is minimum of double type
    //! which also indicates an invalid value.
    DoubleField *_maxFld;

	SubImage m_outputImg;
    //! Implements the runtime type interface of this module.
    ML_MODULE_CLASS_HEADER(LISTMorphOperator);
  };

ML_END_NAMESPACE



#endif // 





