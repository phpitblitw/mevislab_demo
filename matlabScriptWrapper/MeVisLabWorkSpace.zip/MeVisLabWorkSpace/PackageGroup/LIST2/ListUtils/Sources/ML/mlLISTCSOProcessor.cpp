//----------------------------------------------------------------------------------
//! The ML module class LISTCSOProcessor.
/*!
// \file    mlLISTCSOProcessor.cpp
// \author  gyyang
// \date    2011-06-28
//
// 
*/
//----------------------------------------------------------------------------------

// Local includes
#include "mlLISTCSOProcessor.h"
#include "SoView2D.h"

#include <mlRotation.h>

#include <CSOTools/CSOMath.h>
#include <CSOTools/CSOGeneratePathPoints.h>


ML_START_NAMESPACE

//! Implements code for the runtime type system of the ML
ML_MODULE_CLASS_SOURCE(LISTCSOProcessor, CSOProcessor);

//----------------------------------------------------------------------------------
//! Constructor
//----------------------------------------------------------------------------------
LISTCSOProcessor::LISTCSOProcessor() : CSOProcessor("CSOModifyProcessor", 0)
{
	ML_TRACE_IN("CSOModifyProcessor::CSOModifyProcessor()");

	reinterpret_cast<CSOProcessorData*>(_outProcessDataFld->getBaseValue())->setProcessor(this);
	_processorMode = PROCESSOR_MODE_MODIFICATOR;

	//////////////////////////////////////////////////////////////////////////

	handleNotificationOff();

	FieldContainer* fieldC = getFieldContainer();
	ML_CHECK(fieldC);

	// Monotonic filtering
	_monotonicFilteringFld = fieldC->addBool("filteringOn");
	_monotonicFilteringFld->setBoolValue(false);

	// Monotonic filtering mode
	static const char* filterModes[2] = {"X", "Y"};
	_monotonicFilterModeFld = fieldC->addEnum("filterMode", filterModes, 2);

	// Discard intersecting contours
	_discardIntersectingContoursFld = fieldC->addBool("discardIntersectingContours");
	_discardIntersectingContoursFld->setBoolValue(false);

	_mainModificatorCSO   = NULL;
	_csoList              = NULL;

	_isCurrentlyEditing = false;
	_contourToModify = NULL;

	resetInteractionState();

	_markerModeFld->setEnumValue(MARKER_DISPLAY_MODE_NONE);

	handleNotificationOn();
}

//////////////////////////////////////////////////////////////////////////

LISTCSOProcessor::~LISTCSOProcessor()
{
	ML_TRACE_IN("LISTCSOProcessor::~LISTCSOProcessor()");
}

//////////////////////////////////////////////////////////////////////////

void LISTCSOProcessor::handleNotification(Field* field)
{
	ML_TRACE_IN("void LISTCSOProcessor::handleNotification(Field* field)");

	CSOProcessor::handleNotification(field);
}

//////////////////////////////////////////////////////////////////////////

void LISTCSOProcessor::activateAttachments()
{
	ML_TRACE_IN("void LISTCSOProcessor::activateAttachments()");

	CSOProcessor::activateAttachments();
}

//////////////////////////////////////////////////////////////////////////

bool LISTCSOProcessor::process(CSOList*  csoList,
										  Vector3&   currentHitPoint,
										  int            /*hitMode*/,
										  CSO*           /*recentlySelectedCSO*/,
										  CSOSeedPoint*  /*recentlySelectedSeedPoint*/,
										  CSOPathPoints* /*recentlySelectedPathPoints*/,
										  SoView2D*      /*view2d*/,
										  View2DSliceList* slicelist,
										  View2DEvent*   /*ec*/,
										  View2DEventPhase phase,
										  CSOBoundingBox /*slabBB*/,
										  int /*timepointindex*/,
										  bool /*deleteSeedPoint*/)
{
	ML_TRACE_IN("bool LISTCSOProcessor::process()");

	bool hasDoneSomething = false;
	int notificationFlag = CSOList::NOTIFICATION_NONE;

	_csoList   = csoList;
	_currentHitPointWorld = currentHitPoint;

	if (phase == EVENT_START){ // Start of the interaction

		// Check if the selected CSO is a open contour.
		if(_csoList->getSelectedCSOAt(0) /*&& !_csoList->getSelectedCSOAt(0)->isClosed()*/) {
			_contourToModify = _csoList->getSelectedCSOAt(0);
			if(_contourToModify->getEditableState()) {
				_isCurrentlyEditing = true;

				// start temporary CSO (that is deleted afterwards)
				_mainModificatorCSO = _addCSO(_csoList, "", false); // no undo/redo

				// set default parameters, hide them on the panel
				_mainModificatorCSO->setMarkerMode(MARKER_DISPLAY_MODE_NONE);
				_mainModificatorCSO->setColor(_contourToModify->getColor());

				_mainModificatorCSO->appendSeedPoint()->worldPosition = _currentHitPointWorld;
				_mainModificatorCSO->appendSeedPoint()->worldPosition = _currentHitPointWorld;
				_mainModificatorCSO->insertPathPointsEndStart();
			}
			else {
				_contourToModify = NULL;
			}
		}
		else {
			_isCurrentlyEditing = false;
			_contourToModify = NULL;
		}

	} else
		if (phase == EVENT_MOTION){ // During interaction add points to the contour

			if (_isCurrentlyEditing){

				const float distToEnd = _getScreenDistance(slicelist,
					_mainModificatorCSO->getLastSeedPoint()->worldPosition,
					_currentHitPointWorld);

				const int   dPrec    = 2; // fixed: points must be 2 pixels apart
				const float drawPrec = static_cast<float>(dPrec*dPrec);

				if (distToEnd >= drawPrec){
					// just add more points and smooth them with splineApproximation
					_mainModificatorCSO->appendSeedAndPathPoint(_currentHitPointWorld);
					CSOGeneratePathPoints::fillAllPathPointsSplineApproximation(_mainModificatorCSO, 1);
				}

                // notify to repaint
				notificationFlag |= CSOList::NOTIFICATION_REPAINT;
			}
		} else
			if (phase == EVENT_RELEASE){ // Finished interaction

				if (_isCurrentlyEditing){

					// Check for enough points in the contour
					if (_mainModificatorCSO->numSeedPoints() > 2){

							// Normals of the original and modificator CSO planes
							Vector3 modifyNormal, csoNormal;
							if (_mainModificatorCSO->isInPlane(modifyNormal) &&  // check modificator inPlane
								!CSOMath::isSelfIntersecting(_mainModificatorCSO) &&  // check not selfIntersecting
								_contourToModify->isInPlane(csoNormal) // check original contour inPlane
								)
							{

								// Obtain the world to voxel matrix from the current slice image
								ml::Matrix4 worldToVoxelMatrix;
								FillWorldToVoxelMatrixFromSliceList(slicelist, worldToVoxelMatrix);

								// Compute the bounding boxes
								CSOBoundingBox modifyBBVoxel = _mainModificatorCSO->getVoxelBoundingBox(worldToVoxelMatrix);
								modifyBBVoxel.augment(0.5); // add additional border
								const CSOBoundingBox& csoBBVoxel = _contourToModify->getVoxelBoundingBox(worldToVoxelMatrix);

								// Check if the modification contour intersects the bounding box of the original contour
								// and that they are in the same plane
								bool isOke = false;
								if (modifyBBVoxel.intersects(csoBBVoxel) && fabs(csoNormal.dot(modifyNormal)) > 0.999 )
								{
									isOke = true;
								}

								// Obtain all the points in the modification contour
								std::vector<Vector3> modifyPoints;
								_mainModificatorCSO->fillPathPointCoordinatesFlattened(modifyPoints);

								// Filter the modification curve if needed
								if(_monotonicFilteringFld->getBoolValue()) {
									this->MonotonicFilter(slicelist, modifyPoints, MonotonicFilterModes(_monotonicFilterModeFld->getEnumValue()));
								}

								//const unsigned int numModificationPoints = modifyPoints.size();

								Vector3 firstModPos = modifyPoints[0];	// Copy the first modification point
								const float originalZValue = modifyPoints[0][2]; // Copy the original z-value

								// Obtain the rotation from the the plane normal to the z-Plane
								Rotation rotToZPlane(modifyNormal, Vector3(0,0,1)); // rotation to the z-plane

								ProjectPointsForward(modifyPoints, firstModPos, rotToZPlane);

								// Check that the modification contour does not intersect another contour
								if(isOke && _discardIntersectingContoursFld->getBoolValue()) {


									// Loop over all the CSOs in the list
									const unsigned int numCSOs = _csoList->numCSO();

									for(unsigned int cso_index = 0; cso_index < numCSOs && isOke; ++cso_index) {

										// get the current CSO
										CSO* currentCSO = _csoList->getCSOAt(cso_index);

										// skip check if the contour to modify
										if(
											currentCSO == _contourToModify ||
											currentCSO == _mainModificatorCSO
											)
										{
											continue;
										}

										// Check if the bounding boxes intersect
										const CSOBoundingBox& currentBox = currentCSO->getVoxelBoundingBox(worldToVoxelMatrix);
										if(!modifyBBVoxel.intersects(currentBox) ) {
											continue;
										}

										std::vector<Vector3> flattendPoints;
										currentCSO->fillPathPointCoordinatesFlattened(flattendPoints);

										std::vector<Vector3> flattendPointsProjected(flattendPoints);
										ProjectPointsForward(flattendPointsProjected, firstModPos, rotToZPlane);

										isOke = !ContoursIntersect(flattendPointsProjected, modifyPoints);

									}

								}

								// Is the contour valid to modify
								if(isOke) {

									// Obtain all the points in the original contour
									std::vector<Vector3> originalPoints;
									_contourToModify->fillPathPointCoordinatesFlattened(originalPoints);

									// Project the original points on the z-Plane
									ProjectPointsForward(originalPoints, firstModPos, rotToZPlane);


									// Find the closest start and end indices
                                    int closestIndexStart, closestIndexEnd;
									std::set<int> allIndices;
									bool crossesZero =FindClosestStartEndIndices(modifyPoints, originalPoints, closestIndexStart, closestIndexEnd,allIndices);

									// swap the start and end if needed
									// allows drawing start-to-end or end-to-start
									if(
										 crossesZero && closestIndexEnd > closestIndexStart ||
										!crossesZero && closestIndexStart > closestIndexEnd
										) {
										std::swap(closestIndexStart, closestIndexEnd);
										std::reverse(modifyPoints.begin(), modifyPoints.end());
									}
									++closestIndexEnd; // increment end index

									// Fill a the newpoints vector using the start and end indices
									const unsigned int numOriginalPoints = originalPoints.size();
									const unsigned int numModifyPoints = modifyPoints.size();

									std::vector<Vector3> newPoints;
									newPoints.reserve(numOriginalPoints + numModifyPoints);

									std::set<int>::const_iterator index_it = allIndices.begin();
									std::set<int>::const_iterator index_end = allIndices.end();
									//while(index_it != index_end) {
									//	newPoints.push_back(originalPoints.at(*index_it++));
									//}
									//index_it = allIndices.begin();

									unsigned int origin_point_index = 0;
									while(origin_point_index < numOriginalPoints && index_it != index_end) {
										// if smaller than index it add points
										if(origin_point_index < *index_it) {
											newPoints.push_back(originalPoints.at(origin_point_index));
										} else {
											// if equal increment both
											++index_it;
										}
										++origin_point_index;
									}

									// add modification contours
									newPoints.insert(newPoints.end(), modifyPoints.begin(), modifyPoints.end());

									// add remaining points
									while(++origin_point_index < numOriginalPoints) {
										newPoints.push_back(originalPoints.at(origin_point_index));
									}



									//newPoints.insert(newPoints.end(), originalPoints.begin(), originalPoints.begin() + closestIndexStart);
									//
									//if(closestIndexEnd < originalPoints.size()) {
									//	newPoints.insert(newPoints.end(), originalPoints.begin() + closestIndexEnd, originalPoints.end());
									//}

                                    // Re-project these points back to the original orientation
									rotToZPlane.conjugate(); // to rotate back
									ProjectPointsBackwards(newPoints, originalZValue, firstModPos, rotToZPlane);

                                    // Update the CSO
									bool contourWasClosed = _contourToModify->isClosed();
									_contourToModify->setInsertRemoveSeedPoint(); // Keep track for undo/redo
									_contourToModify->removeAllSeedAndPathPoints();
									for(std::vector<Vector3>::const_iterator it = newPoints.begin(); it != newPoints.end(); ++it) {
										_contourToModify->appendSeedAndPathPoint(*it);
									}
									if(contourWasClosed){
										//_contourToModify->insertPathPointsEndStart();
										_contourToModify->setIsClosed(contourWasClosed);
									}
									CSOGeneratePathPoints::fillAllPathPointsLinear(_contourToModify, 1);
									_contourToModify->pathChanged();

									// Set the correct notificationFlag
									notificationFlag |= CSOList::NOTIFICATION_CSO_FINISHED;
									notificationFlag |= CSOList::NOTIFICATION_GROUP_FINISHED;
								}
							}

						}
					}

					// remove temporary CSO without undo/redo
					_csoList->removeCSO(_mainModificatorCSO,   false);
					_mainModificatorCSO   = NULL;

					_isCurrentlyEditing = false;

					notificationFlag |= CSOList::NOTIFICATION_REPAINT;
				}


			hasDoneSomething = (notificationFlag > CSOList::NOTIFICATION_NONE);
			if(hasDoneSomething) {
				_csoList->notifyObservers(notificationFlag);
			}

			return hasDoneSomething;
}


bool LISTCSOProcessor::needsMemoryImage()
{
	ML_TRACE_IN_TIME_CRITICAL("bool LISTCSOProcessor::needsMemoryImage()");

	return false;
}

//////////////////////////////////////////////////////////////////////////

bool LISTCSOProcessor::isCurrentlyGenerating()
{
	ML_TRACE_IN_TIME_CRITICAL("bool LISTCSOProcessor::isCurrentlyGenerating()");

	return false; // this processor never generates any CSO
}

//////////////////////////////////////////////////////////////////////////

bool LISTCSOProcessor::isCurrentlyEditing()
{
	ML_TRACE_IN_TIME_CRITICAL("bool LISTCSOProcessor::isCurrentlyEditing()");

	return _isCurrentlyEditing;
}

//////////////////////////////////////////////////////////////////////////

bool LISTCSOProcessor::couldCloseCSO()
{
	ML_TRACE_IN_TIME_CRITICAL("bool LISTCSOProcessor::couldCloseCSO()");

	return true;
}

//////////////////////////////////////////////////////////////////////////

void LISTCSOProcessor::resetInteractionState()
{
	ML_TRACE_IN_TIME_CRITICAL("void LISTCSOProcessor::resetInteractionState()");

	if (_mainModificatorCSO != NULL){
		_csoList->removeCSO(_mainModificatorCSO, false);
	}
	//if (_helperModificatorCSO != NULL){
	//	_csoList->removeCSO(_helperModificatorCSO, false);
	//}

	_mainModificatorCSO = NULL;
	//_helperModificatorCSO      = NULL;

	_isCurrentlyEditing = false;
}

//////////////////////////////////////////////////////////////////////////

void LISTCSOProcessor::triggerSetMouseCursor(SoView2D* view2d, bool shouldSetMouseCursor)
{
	ML_TRACE_IN_TIME_CRITICAL("void LISTCSOProcessor::triggerSetMouseCursor()");

	if (shouldSetMouseCursor){
		SoViewerElement::setCursor(view2d->getAction()->getState(), SoViewerProxy::CROSS_FREEFORM_CURSOR); // no own cursor form yet
	}
}


float LISTCSOProcessor::_getScreenDistance(View2DSliceList* slicelist, const Vector3& worldPos1, const Vector3& worldPos2)
{
	ML_TRACE_IN_TIME_CRITICAL("float LISTCSOProcessor::_getScreenDistance()");

	Vector2f devPos1; // point1 device coords
	Vector2f devPos2; // point2 device coords
    this->_getScreenPosition(slicelist, worldPos1, devPos1);
	this->_getScreenPosition(slicelist, worldPos2, devPos2);

	return (devPos1[0]-devPos2[0])*(devPos1[0]-devPos2[0]) + (devPos1[1]-devPos2[1])*(devPos1[1]-devPos2[1]); // squared dist in device coordinates
}

void LISTCSOProcessor::FillWorldToVoxelMatrixFromSliceList( View2DSliceList* slicelist, Matrix4& matrix )
{
	ML_TRACE_IN("bool LISTCSOProcessor::_computeCrossingsAndPerformSplit()");



	// compute bounding box of temp CSO
	SbMatrix w2VMat;
	slicelist->getInputImage()->getWorldToVoxelMatrix(w2VMat);


	matrix = Matrix4(w2VMat[0][0], w2VMat[1][0], w2VMat[2][0], w2VMat[3][0],
		w2VMat[0][1], w2VMat[1][1], w2VMat[2][1], w2VMat[3][1],
		w2VMat[0][2], w2VMat[1][2], w2VMat[2][2], w2VMat[3][2],
		w2VMat[0][3], w2VMat[1][3], w2VMat[2][3], w2VMat[3][3]);
}

void LISTCSOProcessor::MonotonicFilter(View2DSliceList* slicelist, std::vector<Vector3>& points, MonotonicFilterModes _mode )
{
	// If not enough points do nothing
	if(points.size() < 2) {
		return;
	}

	// The dimension to check corresponds to the enum value of the mode
	// MonotonicFilterX: dim = 0
	// MonotonicFilterY: dim = 1
	unsigned int dim = _mode;

	// Reverse the order of the points if needed
	bool isReversed = false;
	const Vector3& startp = points[0];
	Vector2f startDevP; this->_getScreenPosition(slicelist,startp, startDevP);

	const Vector3& endp = points[points.size() - 1];
	Vector2f endDevP; this->_getScreenPosition(slicelist,endp, endDevP);

	if(endDevP[dim] < startDevP[dim]) {
		std::reverse(points.begin(), points.end());
		isReversed = true;
	}

	// Copy correct points to the new points vector
	std::vector<Vector3> newPoints;

	newPoints.push_back(points.at(0));
	Vector2f lastDevPost; this->_getScreenPosition(slicelist,newPoints.back(), lastDevPost);

	for(unsigned int i = 1; i < points.size(); ++i) {
		Vector2f currentDevPos; this->_getScreenPosition(slicelist,points.at(i),currentDevPos);
		if(currentDevPos[dim] >= lastDevPost[dim]){
			newPoints.push_back(points.at(i));
			lastDevPost = currentDevPos;
		}
	}

	// Finally reverse the newPoints if needed
	if(isReversed) {
		std::reverse(newPoints.begin(), newPoints.end());
	}

	// Swap the new and the old points
	std::swap(points, newPoints);
}

void LISTCSOProcessor::_getScreenPosition( View2DSliceList* slicelist, const Vector3& worldPos1, Vector2f& devPos1)
{
	ML_TRACE_IN_TIME_CRITICAL("float LISTCSOProcessor::_getScreenPosition()");

	float posVX1=0, posVY1=0, posVZ1=0; // position voxel pos1
	slicelist->getInputImage()->mapWorldToVoxel(worldPos1[0], worldPos1[1], worldPos1[2], posVX1,posVY1,posVZ1);
	slicelist->mapVoxelToDevice(posVX1,posVY1,posVZ1, devPos1[0],devPos1[1]);

}

void LISTCSOProcessor::ProjectPointsForward( std::vector<Vector3> &_points, const Vector3& _rotationCenter, Rotation &_rotation )
{
	const unsigned int numOriginalPoints = static_cast<unsigned int>(_points.size());

	for (unsigned int i = 0; i < numOriginalPoints; i++){
		_points[i] = _points[i] - _rotationCenter;
		_points[i] = _rotation.rotate(_points[i]);
		_points[i] = _points[i] + _rotationCenter;

		_points[i][2] = 0; // project to z-plane
	}
}

bool LISTCSOProcessor::FindClosestStartEndIndices( const std::vector<Vector3> &_modifyPoints, const std::vector<Vector3> &_originalPoints, int& _closestIndexStart, int& _closestIndexEnd, std::set<int>& _allIndices )
{
	_allIndices.clear();

	const unsigned int numModPoints = _modifyPoints.size();
	std::vector<std::pair<int, double> > modifyIndexToClosestPointIndex;
	modifyIndexToClosestPointIndex.assign(numModPoints, std::make_pair(-1, DBL_MAX));

	const unsigned int numOriginalPoints = _originalPoints.size();
	for(unsigned int i = 0; i < numOriginalPoints; ++i) {
		const Vector3& currentPoint = _originalPoints.at(i);

		for(unsigned int mod_index =0; mod_index < numModPoints; ++mod_index) {
			const Vector3& modPoint = _modifyPoints.at(mod_index);
			std::pair<int, double>& modDistance = modifyIndexToClosestPointIndex.at(mod_index);

			double dist = (modPoint[1] - currentPoint[1])*(modPoint[1] - currentPoint[1]);
			dist += (modPoint[0] - currentPoint[0])*(modPoint[0] - currentPoint[0]);

			if(dist < modDistance.second) {
				modDistance.second = dist;
				modDistance.first = i;
			}
		}
	}

	_closestIndexStart = modifyIndexToClosestPointIndex.at(0).first;
	_closestIndexEnd = modifyIndexToClosestPointIndex.at(numModPoints - 1).first;


	int centralIndex = modifyIndexToClosestPointIndex.at(numModPoints/2).first;
	bool startToCentralIsPositive = centralIndex >= _closestIndexStart;
	bool centralToEndIsPositive = _closestIndexEnd >= centralIndex;
	bool crossesZero = startToCentralIsPositive != centralToEndIsPositive;

	int start = _closestIndexStart;
	int end = _closestIndexEnd;
	if(start > end) {std::swap(start, end);	}

	if(crossesZero) {
		for(int i =0; i <= start; ++i) {
			_allIndices.insert(i);
		}
		for(int i= end; i < numOriginalPoints; ++i) {
			_allIndices.insert(i);
		}
	}
	else {
		for(int i = start;i <= end; ++i) {
			_allIndices.insert(i);
		}
	}
	return crossesZero;
}

void LISTCSOProcessor::ProjectPointsBackwards( std::vector<Vector3> &_points, const float _originalZValue, const Vector3& _rotationCenter, Rotation &_rotation )
{
	const unsigned int numPoints = static_cast<unsigned int>(_points.size());
	for (unsigned int j = 0; j < numPoints; j++) {
		_points[j][2] = _originalZValue; // project back

		_points[j] = _points[j] - _rotationCenter;
		_points[j] = _rotation.rotate(_points[j]);
		_points[j] = _points[j] + _rotationCenter;
	}
}


bool LISTCSOProcessor::ContoursIntersect(const std::vector<Vector3> &_points1, const std::vector<Vector3> &_points2)
{
	const unsigned int numP1 = _points1.size() - 1;
	const unsigned int numP2 = _points2.size() - 1;
	bool dummy;
	for(unsigned int point_index = 0; point_index < numP1; ++point_index) {
		const Vector3& projectedPoint1 = _points1.at(point_index);
		const Vector3& projectedPoint2 = _points1.at(point_index + 1);

		// loop over the modification points
		Vector3 dummyIntersectionPoint;
		for(unsigned int mod_index = 0; mod_index < numP2; ++mod_index) {
			const Vector3& firstModPoint = _points2.at(mod_index);
			const Vector3& secondModPoint = _points2.at(mod_index + 1);

#ifndef ML_VERSION_2
			double distance = CSOMath::computeSegmentSegmentDistance(projectedPoint1, projectedPoint2, firstModPoint, secondModPoint, dummyIntersectionPoint );
#else
			double distance = CSOGeometry::computeSegmentSegmentDistance(projectedPoint1, projectedPoint2, firstModPoint, secondModPoint, dummyIntersectionPoint, dummy);
#endif
			if(distance < 1e-10) {
				return true;
			}
		}
	}

	return false;
}


ML_END_NAMESPACE

