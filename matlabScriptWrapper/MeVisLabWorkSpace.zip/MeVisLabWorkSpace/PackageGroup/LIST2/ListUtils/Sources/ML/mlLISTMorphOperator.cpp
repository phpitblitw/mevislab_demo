/*
// -----------------------------------------------------------------------
// 
// Copyright (c) 2001-2010, MeVis Medical Solutions AG, Bremen, Germany
// 
// This file is an example code file distributed with the MeVisLab SDK 
// software from MeVis Medical Solutions AG. The contents of this example 
// file may be used, distributed and modified without limitations.
// 
// THIS FILE IS DISTRIBUTED IN THE HOPE THAT IT WILL BE USEFUL, BUT IT IS 
// PROVIDED 'AS-IS' FOR USE AT OWN RISK, WITHOUT ANY EXPRESSED OR IMPLIED 
// WARRANTY, WITHOUT EVEN THE IMPLIED WARRANTY OF MERCHANTABILITY OR 
// FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT SHALL MEVIS MEDICAL 
// SOLUTIONS AG OR THE AUTHORS BE HELD LIABLE FOR ANY DAMAGES ARISING FROM 
// THE USE OF THIS FILE.
// 
*/
//----------------------------------------------------------------------------------
//! This is ane example module to demonstrate how to
//! process all pages of one or more images.
//!
//! \file    mlProcessAllPagesExample.cpp
//! \author  Wolf Spindler
//! \date    2003-08-29
//!
//! This module demonstrates how one or more (input) images
//! can be scanned sequentially using the
//! \code
//
//    processAllPages(outIndex)
//
//  \endcode
//! method of the ML class Module.
//!
//! That method starts the normal page based image processing
//! for all input or output pages of the module (which is usually
//! done only on demand).
//!
//! Internally all pages of the output image with index \c outIndex
//! are requested like from a connected module.
//! So a normal image processing takes place with the following changes:
//! - If \c outIndex is -1 then a temporary output image with index
//!   \c outIndex is created. The properties for the temporary output image
//!   are copied from the input image \c inIndex. If \c outIndex is positive
//!   it must specify a legal module output index. \c inIndex must be -1 in
//!   that case.
//! - If \c outIndex is negative then in \c calculateOutputSubImage the output 
//!   subimages must NOT be written since not data is collected for them
//!   to improve performance for pure input scan algorithms.
//! - The output index \c outIndex is passed to \c calculateOutputSubImage (even
//!   if it's negative). On negative values you can see that the output
//!   must not be written.
//!    
//! The return value will ML_RESULT_OK on successful operation, otherwise
//! a code describing the error.
//!
//! For a more detailed documentation of standard module methods please 
//! refer to mlAddExample.h or to a newly created BASIC_ADD module.
//!
//! Note: This module does not handle data types larger than MLdouble correctly.
//! 
//----------------------------------------------------------------------------------

#ifndef __mlLISTMorphOperator_H
#include "mlLISTMorphOperator.h"
#endif

ML_START_NAMESPACE

  ML_MODULE_CLASS_SOURCE(LISTMorphOperator, Module);

  //-------------------------------------------------------------------------------
  // Constructor, initialize fields, create two inputs and one output. 
  // Fields are 
  //
  // - two fields to start page processing, one for input page processing
  //   and one for output page processing,
  // - a status field to show results
  // - four output fields for statistical information.
  //
  //-------------------------------------------------------------------------------
  LISTMorphOperator::LISTMorphOperator(): Module(2,1)
  {
    // Disable notification handling in handleNotification while fields are not valid.
    handleNotificationOff();

    // Create two notify fields to start page processing.
   _processIn0PagesFld = getFieldContainer()->addNotify("processIn0Pages");
   _processOutPagesFld = getFieldContainer()->addNotify("processOutPages");

    // Status output field.
    _statusFld        = getFieldContainer()->addString("status"   );

    // Output fields for statistical information.
    _numVoxelFld      = getFieldContainer()->addInt   ("numVoxel" );
    _voxelSumFld      = getFieldContainer()->addDouble("voxelSum" );
    _minFld           = getFieldContainer()->addDouble("minimum"  );
    _maxFld           = getFieldContainer()->addDouble("maximum"  );

    // Set field values to default.
    _resetFieldInfos("Result is invalid");

    // Reenable notification handling.
    handleNotificationOn();
  }

  LISTMorphOperator::~LISTMorphOperator()
  {
	//m_outputImg.free();
  }

  //-------------------------------------------------------------------------------
  //! Reset field values after module load or clone to be sure that no old stuff is loaded.
  //-------------------------------------------------------------------------------
  void LISTMorphOperator::activateAttachments()
  {
    _resetFieldInfos("Result is invalid");

    // Don't forget to execute super class stuff.
    Module::activateAttachments();
  }

  //-------------------------------------------------------------------------------
  //! Reset fields to default (i.e. invalid) information.
  //-------------------------------------------------------------------------------
  void LISTMorphOperator::_resetFieldInfos(std::string message)
  {
    // Reset fields to default (i.e. invalid) information.
    _numVoxelFld->setIntValue   (0);
    _voxelSumFld->setDoubleValue(0);
    _minFld     ->setDoubleValue(MLDataTypeMax(MLdoubleType));
    _maxFld     ->setDoubleValue(MLDataTypeMin(MLdoubleType));
    _statusFld  ->setStringValue(message);
  }


  //-------------------------------------------------------------------------------
  //! handleNotification: 
  //!  - Resets statistical information fields on changes of any input
  //!  - starts page processing if \c _processIn0PagesFld or 
  //!    \c _processOutPagesFld is activated.
  //-------------------------------------------------------------------------------
  void LISTMorphOperator::handleNotification(Field *f)
  {
    // If input 0 or 1 change then reset status string and statistical
    // information fields. Also clear output image.
    if ((getInputImageField(0)==f) || (getInputImageField(1)==f)){
      _resetFieldInfos("Result is invalid");
      getOutputImageField(0)->touch();
    }

    // ----------------------------------------------------------------
    // USAGE TYPE 1:
    // ----------------------------------------------------------------
    // Process all non writable pages of temporary output -1.
    if (_processIn0PagesFld==f){
      // Reset previous state.
      _resetFieldInfos("calculating...");

      // Process all (non writable )pages of temporary output -1. The output copies
      // the properties from input 0
      MLErrorCode err = processAllPages(-1);

      // Valid scan results?
      if ((ML_RESULT_OK==err) && (_minFld->getDoubleValue() <= _maxFld->getDoubleValue())){
        // Yes, touch result fields. Note that during calculations
        // notifications are never processed by the ML. So we do it
        // here once after the processing call.
        _numVoxelFld->touch();
        _voxelSumFld->touch();
        _minFld     ->touch();
        _maxFld     ->touch();
        _statusFld  ->setStringValue("Okay");
      }
      else{
        // Reset output fields and set error status.
        _resetFieldInfos(MLGetErrorCodeDescription(err));
      }
    }
    
    // ----------------------------------------------------------------
    // USAGE TYPE 2:
    // ----------------------------------------------------------------
    // Process all writable pages of output image 0. 
    if (_processOutPagesFld==f){
      // Process all pages of output image 0. This is usually an unnecessary
      // operation since appended modules request missing pages anyway. It is
      // useful e.g. to put as many pages of the output image into the cache as
      // possible or to get process all calculation results. Since properties 
      // are copied from input 0 and updated normally by calculateOutputImageProperties we 
      // cannot specify an input to copy properties from. So we must pass -1
      // as second parameter. This might be a feature in the future.
      _statusFld->setStringValue("calculating...");
      MLErrorCode err = processAllPages(0);
      if (ML_RESULT_OK==err){
        _statusFld->setStringValue("Okay");
      }
      else{
        // Reset output fields and set error status.
        _resetFieldInfos(MLGetErrorCodeDescription(err));
      }
    }
  }

  void LISTMorphOperator::calculateOutputImageProperties(int outIndex, PagedImage* outImage)
  {
    if (outIndex<0) {
      // Example to modify output page size for temporary image of processAllPages(-1)
      // outImage->setPageExtent(ImageVector(40,40,1,1,1,1));

      // Example to request input sub images in different format.
      // outImage->setInputSubImageDataType(0, MLfloatType);
    }
  }

  //-------------------------------------------------------------------------------
  // Implement the calls of the right template code for the current image data type.
  //-------------------------------------------------------------------------------
  ML_CALCULATEOUTPUTSUBIMAGE_NUM_INPUTS_2_CPP(LISTMorphOperator);

  //-------------------------------------------------------------------------------
  // Implement both types of page processing, once to get statistical information
  // about input pages and once calculate normal output pages.
  //-------------------------------------------------------------------------------
  template <typename DATATYPE> 
  void LISTMorphOperator::calculateOutputSubImage(TSubImage<DATATYPE> *outSubImg,
	  int outIndex,
	  TSubImage<DATATYPE> *inSubImg0,
	  TSubImage<DATATYPE> *inSubImg1)
  {

	  // Clamp page box to valid image regions since pages can reach outside the image.
	  SubImageBox box = SubImageBox::intersect(inSubImg0->getBox(), getInputImage(0)->getBoxFromImageExtent());

	  // Initialize statistical information buffers from previously processed pages.
	  int    num    = _numVoxelFld->getIntValue();
	  double sum    = _voxelSumFld->getDoubleValue();
	  double minVal = _minFld     ->getDoubleValue();
	  double maxVal = _maxFld     ->getDoubleValue();

	  if (outIndex < 0){
		  ImageVector in_ext = inSubImg0->getImageExtent();
		  ImageVector pp(0,0,0,0,0,0);
		  m_outputImg.free();
		  m_outputImg.setDataType(inSubImg0->getDataType());
		  m_outputImg.setImageExtent(ImageVector(in_ext.x,in_ext.y,in_ext.z,1,1,1));
		  m_outputImg.allocate(ML_FATAL_MEMORY_ERROR);
		  unsigned int* outputimage = NULL;
		  outputimage = (unsigned int*)m_outputImg.getImagePointer(pp);

		  // Scan all voxels in both input subimages which have identical
		  // extents (as specified in calculateInputSubImageBox).
		  ImageVector p = box.v1;
		  //for (p.u = box.v1.u;   p.u <= box.v2.u;  p.u++){
		  //	  for (p.t = box.v1.t;   p.t <= box.v2.t;  p.t++){
		  //		  for (p.c = box.v1.c;   p.c <= box.v2.c;  p.c++){
		  for (p.z = box.v1.z;  p.z <= box.v2.z;  p.z++){
			  for (p.y = box.v1.y;  p.y <= box.v2.y;  p.y++){

				  //---------------------------------------------------------------------
				  // Look for the output index we process. If we have a -1 then
				  // we have no valid output page and we cannot write it therefore.
				  // This is caused by \c processAllPages(-1,0) to scan the input
				  // subimage data, e.g. for statistical information.
				  // A value >=0 indicates a normal page request or a call from
				  // \c processAllPages(0) to calculate normal output pages.
				  //---------------------------------------------------------------------

				  //---------------------------------------------------------------------
				  // Calculate statistical information from input pages.
				  // This is caused by \c processAllPages(-1) to scan the input
				  // subimage data, e.g. for statistical information. The output page
				  // exists as a data structure, but it contains no data.
				  // So the output data is invalid, and we cannot write it!
				  // Only the input subimages are valid to be read.
				  //---------------------------------------------------------------------
				  // Calculate first voxel position in x row.
				  p.x = box.v1.x;

				  // Get pointers to first voxels in x-rows of both input subimages.
				  DATATYPE* i0P = inSubImg0->getImagePointer(p); 
				  DATATYPE* i1P = inSubImg1->getImagePointer(p); 

				  // Iterate over all voxels in input lines.
				  for (;  p.x <= box.v2.x;  p.x++){

					  // Count and sum up voxel from image 0 if
					  // corresponding voxel in image 1 is non zero.
					  if (*i1P){ ++num; sum+=*i0P; }

					  // Update min/max values.
					  if (*i0P < minVal){ minVal = *i0P; }
					  if (*i0P > maxVal){ maxVal = *i0P; }

					  *(outputimage + p.z * box.v2.x * box.v2.y + p.y*box.v2.x) = *i0P + *i1P;

					  // Move pointers forward in both input images.
					  ++i0P;
					  ++i1P;
				  }
				  //---------------------------------------------------------------------
				  // This is caused by \c processAllPages(0,-1) to calculate normal
				  // output pages or by any other normal page request at the output.
				  // In this case the output data is naturally VALID, we calculate 
				  // the output page as usually in any other normal image processing.
				  // Here we simply copy input 0 data into the output page.
				  //---------------------------------------------------------------------
				  //outSubImg->copySubImage(m_outputImg);
			  }
		  }
	  }
	  //		  }
	  //	  }
	  //}
	  else if(outIndex < 0)
	  {
		  outSubImg->copySubImage(m_outputImg);
	  }

	  // Update the statistical field values processed from input subimages.
	  if (outIndex < 0){
		  _numVoxelFld->setIntValue   (num);
		  _voxelSumFld->setDoubleValue(sum);
		  _minFld     ->setDoubleValue(minVal);
		  _maxFld     ->setDoubleValue(maxVal);
	  }
  }



	  ML_END_NAMESPACE
