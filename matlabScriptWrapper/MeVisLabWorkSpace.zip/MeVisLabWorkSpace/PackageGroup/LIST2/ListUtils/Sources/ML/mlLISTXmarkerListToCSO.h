//----------------------------------------------------------------------------------
//! The ML module class LISTXmarkerListToCSO.
/*!
// \file    mlLISTXmarkerListToCSO.h
// \author  gyyang
// \date    2011-12-30
//
// 
*/
//----------------------------------------------------------------------------------


#ifndef __mlLISTXmarkerListToCSO_H
#define __mlLISTXmarkerListToCSO_H


// Local includes
#include "LISTUtilsSystem.h"

// ML includes
#include <mlModuleIncludes.h>
#include "CSOBase/CSOList.h"
#include "mlXMarkerList.h"

ML_START_NAMESPACE


//! 
class LISTUTILS_EXPORT LISTXmarkerListToCSO : public Module
{
public:

  //! Constructor.
  LISTXmarkerListToCSO ();

  //! Handles field changes of the field \p field.
  virtual void handleNotification (Field *field);

  void ConvertXmarkerListToCSOList();

private:

  NotifyField* m_updateField;
  BoolField *m_AutoUpdateField;
	
	
  BaseField* m_inputXmarkerListField;
  BaseField* m_outputCSOListField;

  XMarkerList* m_inputXmarkerList;
  CSOList m_ouputCSOList;

  IntField* m_inputContourTypeField;//type 1: all contours are paralle in Z direction; type 2: contours defined by markers' type value

  IntField* m_SliceIntervalStepFiled;//output one CSO contour every m_SliceIntervalStep slices

  // Implements interface for the runtime type system of the ML.
  ML_MODULE_CLASS_HEADER(LISTXmarkerListToCSO)
};


ML_END_NAMESPACE

#endif // __mlLISTXmarkerListToCSO_H

