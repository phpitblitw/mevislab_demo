//----------------------------------------------------------------------------------
//! The ML module class LISTXmarkerListToCSO.
/*!
// \file    mlLISTXmarkerListToCSO.cpp
// \author  gyyang
// \date    2011-12-30
//
// 
*/
//----------------------------------------------------------------------------------

// Local includes
#include "mlLISTXmarkerListToCSO.h"

#include "CSOTools/CSOGeneratePathPoints.h"


ML_START_NAMESPACE

//! Implements code for the runtime type system of the ML
ML_MODULE_CLASS_SOURCE(LISTXmarkerListToCSO, Module);

//----------------------------------------------------------------------------------
//! Constructor
//----------------------------------------------------------------------------------
LISTXmarkerListToCSO::LISTXmarkerListToCSO ()
: Module(0, 0)
{
	ML_TRACE_IN("LISTXmarkerListToCSO::LISTXmarkerListToCSO ()");

	// Suppress calls of handleNotification on field changes to
	// avoid side effects during initialization phase.
	handleNotificationOff();

	m_updateField = getFieldContainer()->addNotify("update");

	m_AutoUpdateField = getFieldContainer()->addBool("autoUpdate");
	m_AutoUpdateField->setBoolValue(false);
	
	m_inputContourTypeField = getFieldContainer()->addInt("ContourType");
	m_inputContourTypeField->setIntValue(1);

	m_SliceIntervalStepFiled = getFieldContainer()->addInt("ZSliceStep");
	m_SliceIntervalStepFiled->setIntValue(1);


	m_inputXmarkerListField = getFieldContainer()->addBase("inputXmarkerList");
	m_outputCSOListField = getFieldContainer()->addBase("outputCSOList");
	


	// Reactivate calls of handleNotification on field changes.
	handleNotificationOn();



	// Activate inplace data buffers for output outIndex and input inIndex.
	// setOutputImageInplace(outIndex, inIndex);

	// Activate page data bypass from input inIdx to output outIdx.
	// Note that the module must still be able to calculate the output image.
	// setBypass(outIndex, inIndex);

	// Activate parallel execution of calculateOutputSubImage.
	// setThreadSupport(supportMode);
	// with supportMode =
	//   NO_THREAD_SUPPORT                 //! The module is not thread safe at all.
	//   CALC_OUTSUBIMAGE_ON_STD_TYPES     //! calculateOutputSubImage can be called in parallel for scalar voxel types.
	//   CALC_OUTSUBIMAGE_ON_CARRIER_TYPES //! calculateOutputSubImage can be called in parallel for carrier voxel types.
	//   CALC_OUTSUBIMAGE_ON_ALL_TYPES     //! calculateOutputSubImage can be called in parallel for all voxel types.
	// Warning: You should be familiar with multithreading before activating this feature.

	// Specify whether the module can only process standard scalar voxel types or
	// also registered voxel types (Vector2, Matrix2, complexf, etc.)
	// setVoxelDataTypeSupport(permittedTypes);
	// with permittedTypes =
	//   ONLY_STANDARD_TYPES               //! Only standard scalar voxels are supported.
	//   FULLY_OPERATIONAL                 //! Scalar and registered voxels types are supported.
	//   MINIMUM_OPERATIONAL               //! Scalar and registered voxel types are supported.
	//                                     //! Voxel operators are not used by algorithm.
	//
	// See ML Programming Guide, "Configuring Image Processing Behaviour of the Module"
	// for further details.
}

//----------------------------------------------------------------------------------
//! Handle field changes of the field field.
//----------------------------------------------------------------------------------
void LISTXmarkerListToCSO::handleNotification (Field *field)
{
	ML_TRACE_IN("LISTXmarkerListToCSO::handleNotification ()");

	if (m_inputXmarkerListField == field)
	{
		Base* inputBase = m_inputXmarkerListField->getBaseValue();
		if(inputBase && ML_BASE_IS_A(inputBase,XMarkerList)) {
			m_inputXmarkerList = static_cast<XMarkerList*>(inputBase);
		}
		else
			m_inputXmarkerList = NULL;
	}

	if (m_updateField == field || m_AutoUpdateField->getBoolValue() == true)
	{
		ConvertXmarkerListToCSOList();
		m_outputCSOListField->setBaseValue(&m_ouputCSOList);
		m_outputCSOListField->touch();
	}


	// Handle changes of module parameters and input image fields here.
}

void LISTXmarkerListToCSO::ConvertXmarkerListToCSOList()
{
	m_ouputCSOList.removeAllCSO();
	int slicenum = 0;
	int slicestep = m_SliceIntervalStepFiled->getIntValue();
	if (slicestep <= 0)
		slicestep = 1;
	double zpos = -1;
	int contouridx = -1;
	int contourtype = m_inputContourTypeField->getIntValue();
	int ptnum = 0;
	std::vector<Vector3> ptlist;
	for(XMarkerList::const_iterator markerIt = m_inputXmarkerList->begin(); markerIt != m_inputXmarkerList->end(); ++markerIt) 
	{
		const XMarker& marker = *markerIt;

		if (ptnum == 0)
		{
			Vector3 pt;
			pt[0] = marker.pos[0];
			pt[1] = marker.pos[1];
			zpos = pt[2] = marker.pos[2];
			if (contourtype == 2)
				contouridx = marker.type;
			ptlist.push_back(pt);
			ptnum++;
		}
		else if ((contourtype == 1 && fabs(marker.pos[2] - zpos) < 1e-5) || (contourtype == 2 && marker.type == contouridx))
		{
			Vector3 pt;
			pt[0] = marker.pos[0];
			pt[1] = marker.pos[1];
			zpos = pt[2] = marker.pos[2];
			ptlist.push_back(pt);
			ptnum++;
		}
		else
		{
			if (slicenum % slicestep == 0)
			{
				CSO* currentCSO = m_ouputCSOList.addCSO(ptlist, true, true);
				CSOGeneratePathPoints::fillAllPathPointsSpline(currentCSO, 1);
				if (contourtype == 1)
				{
					currentCSO->setIsInPlane(true);
					currentCSO->setPlaneNormal(Vector3(0,0,1));
				}
				else if (contourtype == 2)
				{
					currentCSO->computePlaneNormal();
					currentCSO->setIsInPlane(false);
				}
				currentCSO->setMarkerMode(0);
				currentCSO->setType("FreehandProcessor");
				currentCSO->setSubType("SUB_TYPE_FREEHAND_CLOSED");
				currentCSO->setColor(Vector3(1.0,0.0,0.0));	
				bool state = currentCSO->getEditableState();
			}
			slicenum++;
			ptlist.clear();
			
			Vector3 pt;
			pt[0] = marker.pos[0];
			pt[1] = marker.pos[1];
			zpos = pt[2] = marker.pos[2];
			if (contourtype == 2)
				contouridx = marker.type;
			ptlist.push_back(pt);
			ptnum++;
		}
	}
	CSO* currentCSO = m_ouputCSOList.addCSO(ptlist, true, true);
	CSOGeneratePathPoints::fillAllPathPointsSpline(currentCSO, 1);
	if (contourtype == 1)
	{
		currentCSO->setIsInPlane(true);
		currentCSO->setPlaneNormal(Vector3(0,0,1));
	}
	else if (contourtype == 2)
	{
		currentCSO->computePlaneNormal();
		currentCSO->setIsInPlane(false);
	}
	currentCSO->setMarkerMode(0);
	currentCSO->setType("FreehandProcessor");
	currentCSO->setSubType("SUB_TYPE_FREEHAND_CLOSED");
	currentCSO->setColor(Vector3(1.0,0.0,0.0));	
}

ML_END_NAMESPACE

