//----------------------------------------------------------------------------------
//! The ML module class ListUtils.
/*!
// \file    mlListUtils.cpp
// \author  gyyang
// \date    2011-12-30
//
// 
*/
//----------------------------------------------------------------------------------

// Local includes
#include "mlListUtils.h"


ML_START_NAMESPACE

//! Implements code for the runtime type system of the ML
ML_MODULE_CLASS_SOURCE(ListUtils, Module);

//----------------------------------------------------------------------------------
//! Constructor
//----------------------------------------------------------------------------------
ListUtils::ListUtils ()
  : Module(0, 0)
{
  ML_TRACE_IN("ListUtils::ListUtils ()");

  // Suppress calls of handleNotification on field changes to
  // avoid side effects during initialization phase.
  handleNotificationOff();

  // Reactivate calls of handleNotification on field changes.
  handleNotificationOn();



  // Activate inplace data buffers for output outIndex and input inIndex.
  // setOutputImageInplace(outIndex, inIndex);

  // Activate page data bypass from input inIdx to output outIdx.
  // Note that the module must still be able to calculate the output image.
  // setBypass(outIndex, inIndex);

  // Activate parallel execution of calculateOutputSubImage.
  // setThreadSupport(supportMode);
  // with supportMode =
  //   NO_THREAD_SUPPORT                 //! The module is not thread safe at all.
  //   CALC_OUTSUBIMAGE_ON_STD_TYPES     //! calculateOutputSubImage can be called in parallel for scalar voxel types.
  //   CALC_OUTSUBIMAGE_ON_CARRIER_TYPES //! calculateOutputSubImage can be called in parallel for carrier voxel types.
  //   CALC_OUTSUBIMAGE_ON_ALL_TYPES     //! calculateOutputSubImage can be called in parallel for all voxel types.
  // Warning: You should be familiar with multithreading before activating this feature.

  // Specify whether the module can only process standard scalar voxel types or
  // also registered voxel types (Vector2, Matrix2, complexf, etc.)
  // setVoxelDataTypeSupport(permittedTypes);
  // with permittedTypes =
  //   ONLY_STANDARD_TYPES               //! Only standard scalar voxels are supported.
  //   FULLY_OPERATIONAL                 //! Scalar and registered voxels types are supported.
  //   MINIMUM_OPERATIONAL               //! Scalar and registered voxel types are supported.
  //                                     //! Voxel operators are not used by algorithm.
  //
  // See ML Programming Guide, "Configuring Image Processing Behaviour of the Module"
  // for further details.
}

//----------------------------------------------------------------------------------
//! Handle field changes of the field field.
//----------------------------------------------------------------------------------
void ListUtils::handleNotification (Field *field)
{
  ML_TRACE_IN("ListUtils::handleNotification ()");

  // Handle changes of module parameters and input image fields here.
}

ML_END_NAMESPACE

