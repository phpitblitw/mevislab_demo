//----------------------------------------------------------------------------------
//! Project global and OS specific declarations.
/*!
// \file    LISTUtilsSystem.h
// \author  gyyang
// \date    2011-12-30
*/
//----------------------------------------------------------------------------------


#ifndef __LISTUtilsSystem_H
#define __LISTUtilsSystem_H


// DLL export macro definition
#ifdef WIN32
#ifdef LISTUTILS_EXPORTS
// Use the LISTUTILS_EXPORT macro to export classes and functions
#define LISTUTILS_EXPORT __declspec(dllexport)
#else
// If included by external modules, exported symbols are declared as import symbols
#define LISTUTILS_EXPORT __declspec(dllimport)
#endif

#else
// No export declarations are necessary for non-Windows systems
#define LISTUTILS_EXPORT
#endif


#endif // __LISTUtilsSystem_H


