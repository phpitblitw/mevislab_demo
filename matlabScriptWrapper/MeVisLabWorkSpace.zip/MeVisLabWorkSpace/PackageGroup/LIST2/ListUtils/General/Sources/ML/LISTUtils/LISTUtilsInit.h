//----------------------------------------------------------------------------------
//! Dynamic library and runtime type system initialization.
/*!
// \file    LISTUtilsInit.h
// \author  gyyang
// \date    2011-12-30
*/
//----------------------------------------------------------------------------------


#ifndef __LISTUtilsInit_H
#define __LISTUtilsInit_H


ML_START_NAMESPACE

//! Calls init functions of all modules to add their types to the runtime type
//! system of the ML.
int LISTUtilsInit ();

ML_END_NAMESPACE

#endif // __LISTUtilsInit_H


