//----------------------------------------------------------------------------------
//! The ML module class ListUtils.
/*!
// \file    mlListUtils.h
// \author  gyyang
// \date    2011-12-30
//
// 
*/
//----------------------------------------------------------------------------------


#ifndef __mlListUtils_H
#define __mlListUtils_H


// Local includes
#include "LISTUtilsSystem.h"

// ML includes
#include <mlModuleIncludes.h>

ML_START_NAMESPACE


//! 
class LISTUTILS_EXPORT ListUtils : public Module
{
public:

  //! Constructor.
  ListUtils ();

  //! Handles field changes of the field \p field.
  virtual void handleNotification (Field *field);

private:



  // Implements interface for the runtime type system of the ML.
  ML_MODULE_CLASS_HEADER(ListUtils)
};


ML_END_NAMESPACE

#endif // __mlListUtils_H

